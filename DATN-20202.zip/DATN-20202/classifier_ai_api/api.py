from rest_framework import generics
from rest_framework.parsers import JSONParser
from django.http import JsonResponse, HttpResponse
from repository.models import *
from .serializers import ConfigSerializer
from django.core import serializers
from rest_framework.utils import json
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework import status


class ConfigApiView(generics.ListCreateAPIView):
    serializer_class = ConfigSerializer
    parser_classes = [JSONParser]

    def post(self, request, *args, **kwargs):
        cmd = request.query_params.get('cmd')
        print('asdf')
        if cmd == 'insert_config':
            config = EPS_AIConfig.objects.create()
            request_data = request.data
            print(request_data)
            if request_data['insert_database'] == 1:
                config.name_db = request_data['name_db']
                config.ip = request_data['ip']
                config.port = request_data['port']
                config.username_db = request_data['username_db']
                config.password_db = request_data['password_db']
                config.insert_database = request_data['insert_database']
                config.save()
            elif request_data['insert_api'] == 1:
                config.username_api = request_data['username_api']
                config.password_api = request_data['password_api']
                config.insert_api = request_data['insert_api']
                config.url_signup = request_data['url_signup']
                config.url = request_data['url']
                config.save()
        print(config)
        return Response({'status': 200})

    def get(self, request, *args, **kwargs):

        return JsonResponse({'done':1})



