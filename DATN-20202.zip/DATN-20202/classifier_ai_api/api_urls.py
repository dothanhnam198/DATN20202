from django.urls import path
from .api import ConfigApiView


urlpatterns = [
     path('', ConfigApiView.as_view()),
]