from rest_framework import serializers
from repository.models import *


class ConfigSerializer(serializers.ModelSerializer):

    class Meta:
        models = EPS_AIConfig
        fields = '__all__'

