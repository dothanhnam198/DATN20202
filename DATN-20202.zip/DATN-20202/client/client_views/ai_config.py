from django.shortcuts import render 
from django.views.generic import TemplateView, DetailView, ListView
from django.template.response import TemplateResponse
from repository.models import *


def save_ai_config_view(request):
    context = {}
    return render(request, "ai_config/ai_config.html", context)