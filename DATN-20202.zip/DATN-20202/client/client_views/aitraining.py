from django.shortcuts import render
from django.views.generic import TemplateView, DetailView, ListView
from django.template.response import TemplateResponse
from repository.models import *


def ai_training_view(request):
    context = {}
    return render(request,"ai_training/ai_training.html")


def create_ai_training_view(request):
    context = {}
    return render(request, "ai_training/create.html", context)


def get_aitraining_view(request,pk):
    context = {}
    return render(request, "ai_training/edit.html", context)

# class AITrainingEditView(DetailView):
#     model = EPS_AITrain
#     template_name = 'ai_training/edit.html'
#     context_object_name = 'ai_training'
#
#     def get_object(self, queryset=None):
#         return EPS_AITrain.objects.get(pk=self.kwargs['pk'])