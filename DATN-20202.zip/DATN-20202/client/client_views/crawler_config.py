from django.shortcuts import render 
from django.views.generic import TemplateView, DetailView, ListView
from django.template.response import TemplateResponse
from repository.models import *


def crawler_process_view(request):
    context = {}
    return render(request, "history_crawlerprocess/crawler_process.html", context)


def save_crawler_config_view(request):
    context = {}
    return render(request, "crawler_config/crawler_config.html", context)