from django.shortcuts import render
from django.views.generic import TemplateView, DetailView, ListView
from django.template.response import TemplateResponse
from repository.models import *
from haystack.indexes import SearchIndex
from haystack.query import SearchQuerySet,SQ

def get_product_crawled_view(request,pk):
    context = {}
    product = Product_Crawled.objects.get(id=pk)
    context['product'] = product
    return render(request, "san_pham_thu_thap/dien_thoai/details.html", context)

