from django.shortcuts import render 
from django.views.generic import TemplateView, DetailView, ListView
from django.template.response import TemplateResponse
from repository.models import *


def config_view(request):
    context = {}
    return render(request, 'scrapy_config/config.html', context)