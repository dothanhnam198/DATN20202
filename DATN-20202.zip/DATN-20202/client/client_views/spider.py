from django.shortcuts import render
from django.views.generic import TemplateView, DetailView, ListView
from django.template.response import TemplateResponse
from repository.models import *


# class SpiderEditView(DetailView):
#     model = EPS_CrawlerSpider
#     context_object_name = 'spider'
#     template_name = 'spider/edit_spider.html'
#
#     def get_object(self, queryset=None):
#         return EPS_CrawlerSpider.objects.get(pk=self.kwargs['pk'])

def get_spider_view(request,pk):
    context = {}
    return render(request, "spider/edit_spider.html", context)

class SpiderListView(ListView):
    model = EPS_CrawlerSpider
    template_name = 'spider/spider_list.html'
    context_object_name = 'spiders'
    queryset = EPS_CrawlerSpider.objects.all()

    def get_queryset(self):
        spiders = EPS_CrawlerSpider.objects.all().order_by('-id')
        return spiders


def create_spider_view(request):
    context = {}
    return render(request, "spider/create_spider.html", context)


def save_spider_xpath_view(request, pk):
    context = {}
    obj = EPS_CrawlerSpider.objects.create(id=pk)
    print(obj.id)
    context['xpath'] = obj
    return render(request, "spider/save_spider_xpath.html", context)

class SpiderEditView2(DetailView):
    model = EPS_CrawlerSpider2
    template_name = 'spider2/edit_spider.html'
    context_object_name = 'spider'

    def get_object(self, queryset=None):
        return EPS_CrawlerSpider2.objects.get(pk=self.kwargs['pk'])


class SpiderListView2(ListView):
    model = EPS_CrawlerSpider2
    template_name = 'spider2/spider_list.html'
    context_object_name = 'spiders'
    queryset = EPS_CrawlerSpider2.objects.all()

    def get_queryset(self):
        spiders = EPS_CrawlerSpider2.objects.all().order_by('-id')
        return spiders

def create_spider_view2(request):
    context = {}
    return render(request, "spider2/create_spider.html", context)


def save_spider_xpath_view2(request, pk):
    context = {}
    obj = EPS_CrawlerSpider2.objects.create(id=pk)
    print(obj.id)
    context['xpath'] = obj
    return render(request, "spider2/save_spider_xpath.html", context)

class TestCORS(TemplateView):

    def get(self, request, *args, **kwargs):
        response = TemplateResponse(request, 'testcors.html')
        return response