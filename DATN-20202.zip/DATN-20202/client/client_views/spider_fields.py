from django.shortcuts import render
from repository.models import *


def list_spider_field_view(request):
    context = {}
    return render(request, "spiderfields/list.html", context)


def create_spider_field_view(request):
    context = {}
    return render(request, "spiderfields/create.html", context)


def edit_spider_field_view(request, pk):
    context = {}
    return render(request, "spiderfields/edit.html", context)