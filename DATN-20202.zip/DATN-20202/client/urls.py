from django.urls import path, include
from client.client_views.spider import *
from client.client_views.spider_fields import *
from client.client_views.aitraining import *
from client.client_views.ai_config import *
from client.client_views.auth import *
from client.client_views.crawler_config import *
from client.client_views.scrappy_config import *
from client.client_views.product_crawled import get_product_crawled_view
from users.views import password_reset_view, password_reset_confirm_view
from client.views import *
urlpatterns = [
    path('', SpiderListView.as_view()),
    path('2', SpiderListView2.as_view()),
    path('dbapiconfig', config_view),
    path('spider/create', create_spider_view),
    path('spider/create2', create_spider_view2),
    path('edit/<int:pk>', get_spider_view),
    path('edit2/<int:pk>', SpiderEditView2.as_view()),
    # path('save_xpath', create_spider_xpath_view),
    path('save_xpath/<int:pk>', save_spider_xpath_view),
    path('save_xpath2/<int:pk>', save_spider_xpath_view2),
    path('testcors', TestCORS.as_view()),
    path('crawlerconfig', save_crawler_config_view),
    path('aiconfig', save_ai_config_view),
    path('aitrain', ai_training_view),
    path('aitraining/create', create_ai_training_view),
    path('aitraining/edit/<int:pk>', get_aitraining_view),
    path('crawlerprocess', crawler_process_view),
    path('login/', LoginView.as_view()),
    path('logout/', LogoutView.as_view()),
    path('register/', registration_view),
    path('password_reset', password_reset_view),
    path('password_reset_confirm/', password_reset_confirm_view),
    path('spiderfields', list_spider_field_view),
    path('spiderfields/create', create_spider_field_view),
    path('spiderfields/edit/<int:pk>', edit_spider_field_view),
    path('dienthoai', dienthoai_view),
    path('dienthoai/edit/<int:pk>', get_dienthoai_view),
    path('dauthau', tivi_view),
    path('tivi/edit/<int:pk>', get_tivi_view),
    path('tulanh', tulanh_view),
    path('tulanh/edit/<int:pk>', get_tulanh_view),
    path('chungcu', chungcu_view),
    path('chungcu/edit/<int:pk>', get_chungcu_view),
    path('nharieng', nharieng_view),
    path('nharieng/edit/<int:pk>', get_nharieng_view),
    path('test',test),
    path('product/<int:pk>', get_product_crawled_view)

]

