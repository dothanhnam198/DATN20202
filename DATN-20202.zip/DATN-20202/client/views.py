from django.shortcuts import render
from django.views.generic import TemplateView, DetailView, ListView
from django.template.response import TemplateResponse
from repository.models import *

def dienthoai_view(request):
    context = {}
    return render(request, "san_pham_thu_thap/dien_thoai/list_dienthoai.html", context)


def get_dienthoai_view(request,pk):
    context = {}
    return render(request, "san_pham_thu_thap/dien_thoai/edit_dienthoai.html", context)


def tivi_view(request):
    context = {}
    return render(request, "san_pham_thu_thap/ti_vi/list_ti_vi.html", context)


def get_tivi_view(request,pk):
    context = {}
    return render(request, "san_pham_thu_thap/ti_vi/edit_ti_vi.html", context)


def tulanh_view(request):
    context = {}
    return render(request, "san_pham_thu_thap/tu_lanh/list_tu_lanh.html", context)


def get_tulanh_view(request,pk):
    context = {}
    return render(request, "san_pham_thu_thap/tu_lanh/edit_tu_lanh.html", context)


def chungcu_view(request):
    context = {}
    return render(request, "san_pham_thu_thap/chung_cu/list_chung_cu.html", context)


def get_chungcu_view(request,pk):
    context = {}
    return render(request, "san_pham_thu_thap/chung_cu/edit_chung_cu.html", context)


def nharieng_view(request):
    context = {}
    return render(request, "san_pham_thu_thap/nha_rieng/list_nha_rieng.html", context)


def get_nharieng_view(request,pk):
    context = {}
    return render(request, "san_pham_thu_thap/nha_rieng/edit_nha_rieng.html", context)


def test(request):
    context = {}
    product = Product_Crawled.objects.all().order_by('id')[0:3]
    product2 = Product_Crawled.objects.all().order_by('id')[0:6]
    category = EPS_Category.objects.all()
    context['product'] = product
    context['product2'] = product2
    context['category'] = category
    return render(request,"san_pham_thu_thap/dien_thoai/list.html",context)