# -*- coding: utf-8 -*-
import numpy as np
from sys import getsizeof
from random import randint
import os
import io
import json
import pickle
import zlib
import nltk.data
from pyvi import ViTokenizer
from sklearn.svm import LinearSVC
from sklearn import svm, preprocessing, neighbors
from sklearn.neighbors import KNeighborsClassifier
from gensim import corpora, matutils
from sklearn.metrics import classification_report, accuracy_score
import datetime
import sklearn
from sklearn import metrics
from repository.models import EPS_AIModel
from sklearn.decomposition import PCA
    import matplotlib.pyplot as plt
import math
from matplotlib.colors import ListedColormap
from repository.models import EPS_AIModel, upload_location
from django.db.models.fields.files import FieldFile

class FileReader(object):
    def __init__(self, filePath, encoder=None):
        self.filePath = filePath
        # self.encoder = encoder if encoder != None else 'utf-16le'
        self.encoder = encoder if encoder != None else 'utf-8'

    def read(self):
        with open(self.filePath, 'r', encoding="utf-8", errors='ignore') as f:
            s = f.read()
        return s

    def readBytes(self):
        with open(self.filePath, 'rb') as f:
            s = f.read()
        return s

    def content(self):
        s = self.read()
        # return s.decode(self.encoder)
        return s

    def read_json(self):
        with open(self.filePath) as f:
            s = json.load(f)
        return s

    def read_stopwords(self):
        # with open(self.filePath) as f:
        with open(self.filePath, 'r', encoding="utf-8", errors='ignore') as f:
            stopwords = set([w.strip().replace(' ', '_') for w in f.readlines()])
        return stopwords

    def read_stopwords_from_string(self, string_stopwords):
        stopwords = set([w.strip().replace(' ', '_') for w in string_stopwords.split('\r\n')])
        return stopwords

    def load_dictionary(self):
        return corpora.Dictionary.load_from_text(self.filePath)


class FileStore(object):
    def __init__(self, filePath, data=None):
        self.filePath = filePath
        self.data = data

    def store_json(self):
        with open(self.filePath, 'w') as outfile:
            json.dump(self.data, outfile)

    def store_dictionary(self, dict_words):
        dictionary = corpora.Dictionary(dict_words)
        dictionary.filter_extremes(no_below=20, no_above=0.3)
        dictionary.save_as_text(self.filePath)

    def save_pickle(self, obj):
        outfile = open(self.filePath, 'wb')
        fastPickler = pickle.Pickler(outfile, pickle.HIGHEST_PROTOCOL)
        fastPickler.fast = 1
        fastPickler.dump(obj)
        outfile.close()
        if False:
            f = open(self.filePath, 'rb')
            data_test = zlib.compress(f.read(), 1)
            f.close()
            f = open(self.filePath, 'wb')
            f.write(data_test)
            f.close()

    def read_pickle(self):
        try:
            f = open(self.filePath, 'rb')
            data = f.read()
            f.close()
            # 11s
            data = zlib.decompress(data, 15, len(data))
            binary_stream = io.BytesIO()
            binary_stream.write(data)
            binary_stream.seek(0)
            # 1s
            unpickler = pickle.Unpickler(binary_stream)
            # 2p
            est = unpickler.load()
            return est
        except:
            f = open(self.filePath, 'rb')
            # 1s
            unpickler = pickle.Unpickler(f)
            # 2p
            est = unpickler.load()
            f.close()
            return est


class DataLoader(object):
    def __init__(self, dataPath):
        self.dataPath = dataPath

    def __get_files(self):
        folders = [self.dataPath + folder + '/' for folder in os.listdir(self.dataPath)]
        class_titles = os.listdir(self.dataPath)
        files = {}
        for folder, title in zip(folders, class_titles):
            files[title] = [folder + f for f in os.listdir(folder)]
        self.files = files

    def get_json(self):
        self.__get_files()
        data = []
        for topic in self.files:
            rand = randint(100, 150)
            i = 0
            for file in self.files[topic]:
                content = FileReader(filePath=file).content()
                data.append({
                    'category': topic,
                    'content': content
                })
                if i == rand:
                    break
                else:
                    i += 1
        return data


# lọc text khỏi các stopword thành các word có ý nghĩa, ví dụ tiếng_việt...
class NLP(object):
    def __init__(self, text=None, stopwords=None, special_characters='0123456789%@$.,=+-!;/()*"&^:#|\n\t\''):
        self.text = text
        # self.__set_stopwords()
        self.stopwords = stopwords
        self.special_characters = special_characters

    # def __set_stopwords(self):
    #    self.stopwords = FileReader(settings.STOP_WORDS).read_stopwords()

    def segmentation(self):
        return ViTokenizer.tokenize(self.text)

    def split_words(self):
        text = self.segmentation()
        try:
            # return [x.strip(settings.SPECIAL_CHARACTER).lower() for x in text.split()]
            return [x.strip(self.special_characters).lower() for x in text.split()]
        except TypeError:
            return []

    def get_words_feature(self):
        split_words = self.split_words()
        return [word for word in split_words if word.encode('utf-8') not in self.stopwords]


# tạo hoặc load dicitionary, tách bag of word rồi tính vector
class FeatureExtraction(object):
    def __init__(self, dictionaryPath, data, stopwords=None, special_characters='0123456789%@$.,=+-!;/()*"&^:#|\n\t\''):
        self.data = data
        self.dictionaryPath = dictionaryPath
        self.stopwords = stopwords
        self.special_characters = special_characters

    def __build_dictionary(self):
        print('Building dictionary')
        dict_words = []
        i = 0
        for text in self.data:
            i += 1
            print("Step {} / {}".format(i, len(self.data)))
            words = NLP(text=text['content'], stopwords=self.stopwords,
                        special_characters=self.special_characters).get_words_feature()
            dict_words.append(words)
        FileStore(filePath=self.dictionaryPath).store_dictionary(dict_words)

    def __load_dictionary(self):
        if os.path.exists(self.dictionaryPath) == False:
            self.__build_dictionary()
        self.dictionary = FileReader(self.dictionaryPath).load_dictionary()

    def __build_dataset(self):
        self.features = []
        self.labels = []
        i = 0
        for d in self.data:
            i += 1
            print("Step {} / {}".format(i, len(self.data)))
            self.features.append(self.get_dense(d['content']))
            self.labels.append(d['category'])

    def get_dense(self, text):
        self.__load_dictionary()
        words = NLP(text, stopwords=self.stopwords, special_characters=self.special_characters).get_words_feature()
        # Bag of words
        vec = self.dictionary.doc2bow(words)
        dense = list(matutils.corpus2dense([vec], num_terms=len(self.dictionary)).T[0])
        return dense

    def get_data_and_label(self):
        self.__build_dataset()
        return self.features, self.labels


# json, dic, estimator luu tru
class Classifier(object):
    def __init__(self, features_train=None, labels_train=None, features_test=None, labels_test=None,
                 estimator=None):
        self.features_train = features_train
        self.features_test = features_test
        self.labels_train = labels_train
        self.labels_test = labels_test
        self.estimator = estimator

    def training(self):
        self.estimator.fit(self.features_train, self.labels_train)
        self.__training_result()
        return self.__training_result()

    def graph_detail(self, ai_model, count_label, le):
        y_true, y_pred = self.labels_test, self.estimator.predict(self.features_test)
        result = classification_report(y_true, y_pred, output_dict=True)
        y_true2, y_pred2 = self.labels_train, self.estimator.predict(self.features_train)
        result2 = classification_report(y_true2, y_pred2, output_dict=True)
        sum_data_test_each_class = []
        sum_data_train_each_class = []
        precision_each_class = []
        for arg in le.classes_:
            sum_data_test_each_class.append(result[str(arg)]['support'])
            precision_each_class.append(result[str(arg)]['precision'])
            sum_data_train_each_class.append(result2[str(arg)]['support'])
        sum_data_test_each_class = np.array(sum_data_test_each_class)
        sum_data_train_each_class = np.array(sum_data_train_each_class)
        classes = np.arange(count_label)
        plt.barh(classes,sum_data_train_each_class,height=0.2,color='r', label='Train')
        plt.barh(classes,sum_data_test_each_class,height=0.1,color= 'b', label='Test')
        plt.legend(loc='best')
        plt.yticks(classes, le.classes_)
        plt.ylabel(('Số lượng nhãn phân loại {}').format(count_label))
        plt.xlabel('Số lượng dữ liệu')
        plt.title(('Biểu đồ đánh giá kết quả train của {} \n Ngày train {}').format(ai_model.name,datetime.datetime.now()))
        for x in classes:
            precision = str("{:.2f}").format(precision_each_class[x] * 100) + '%'
            plt.text(sum_data_train_each_class[x],x, precision,va='center')
        plt.savefig("static/graphs/{}.png".format(ai_model.name))
        ai = EPS_AIModel.objects.get(filename=ai_model.filename)
        ai.image_plot = upload_location(ai, ai_model.name)
        ai.save()


    def save_model(self, filePath):
        if True:
            self.features_train = None
            self.features_test = None
            self.labels_train = None
            self.labels_test = None
        FileStore(filePath=filePath).save_pickle(obj=self)

    # def __training_result1(self, count_label):
    #     y_true, y_pred = self.labels_train, self.estimator.predict(self.features_train)
    #     a = len(y_pred)
    #     for x in range(len(y_pred)):
    #         print("Kết quả dự đoán: ", y_pred[x], "Kết quả thực tế: ", y_true[x])
    #     print(classification_report(y_true, y_pred))
    #     print(accuracy_score(y_true, y_pred))
    #     result1 = classification_report(y_true, y_pred, output_dict=True)
    #     print(result1['0']['support'])
    #     sum_data_train_each_class = []
    #     for arg in range(count_label):
    #         sum_data_train_each_class.append(result1[str(arg)]['support'])
    #     return sum_data_train_each_class

    def __training_result(self):
        y_true, y_pred = self.labels_test, self.estimator.predict(self.features_test)
        a =len(y_pred)
        for x in range(len(y_pred)):
            print("Kết quả dự đoán: ", y_pred[x], "Kết quả thực tế: ", y_true[x])
        print(classification_report(y_true, y_pred))
        print(accuracy_score(y_true, y_pred))
        result = classification_report(y_true, y_pred,output_dict=True)
        return result

    def save_result(self, filename):
        y_true, y_pred = self.labels_test, self.estimator.predict(self.features_test)
        ai_model = EPS_AIModel.objects.get(filename=filename)
        ai_model.result = classification_report(y_true, y_pred)
        ai_model.save()

    def predict(self, features_test):
        y_pred = self.estimator.predict(features_test)
        return y_pred


def Training(ai_model,fileModelPath, dictionaryPath, data_train, stopwords,
             special_characters='0123456789%@$.,=+-!;/()*"&^:#|\n\t\''):
    features_train, labels_train = FeatureExtraction(dictionaryPath=dictionaryPath, data=data_train,
                                                     stopwords=stopwords,
                                                     special_characters=special_characters).get_data_and_label()
    features_train = np.array(features_train)
    labels_train = np.array(labels_train)
    le = preprocessing.LabelEncoder()
    labels_train_transformed = le.fit_transform(labels_train)
    x_train, x_test, y_train, y_test = sklearn.model_selection.train_test_split(features_train, labels_train,
                                                                                test_size=0.2)
    count_label = le.classes_.shape[0]
    print(count_label)
    count_features_train = features_train.shape[0]
    model = model_train(ai_model.filename, x_train)
    est = Classifier(features_train=x_train, features_test=x_test, labels_train=y_train,
                         labels_test=y_test, estimator=model)
    est.training()
    est.save_result(ai_model.filename)
    est.graph_detail(ai_model,count_label,le)
    est.save_model(filePath=fileModelPath)


def Training_all(fileModelPath, dictionaryPath, data_train, stopwords,
             special_characters='0123456789%@$.,=+-!;/()*"&^:#|\n\t\''):
    features_train, labels_train = FeatureExtraction(dictionaryPath=dictionaryPath, data=data_train,
                                                     stopwords=stopwords,
                                                     special_characters=special_characters).get_data_and_label()
    features_train = np.array(features_train)
    labels_train = np.array(labels_train)
    le = preprocessing.LabelEncoder()
    labels_train_transformed = le.fit_transform(labels_train)
    x_train, x_test, y_train, y_test = sklearn.model_selection.train_test_split(features_train, labels_train,
                                                                                test_size=0.2)
    count_label = le.classes_.shape[0]
    print(count_label)
    count_features_train = features_train.shape[0]
    all_model = EPS_AIModel.objects.all()
    results = []
    model = None
    est = None
    classes = np.arange(count_label)
    plt.figure(1)
    list_model = []
    for ai_model in all_model:
        list_model.append(ai_model.filename)
        model = model_train(ai_model.filename, x_train)
        est = Classifier(features_train=x_train, features_test=x_test, labels_train=y_train,
                             labels_test=y_test, estimator=model)
        training_result = est.training()
        result_each_model = []
        for arg in le.classes_:
            result_each_class = training_result[str(arg)]['precision'] * 100
            result_each_model.append(result_each_class)
        results.append(result_each_model)
    width = 0.1
    results = np.array(results)
    smt = 0
    for result in results:
        plt.bar(classes + width*smt, result, width=width, label=list_model[smt])
        smt +=1
    plt.legend(loc='best')
    plt.xticks(classes + width*smt*0.5, le.classes_,rotation='vertical'     )
    plt.xlabel(('Số lượng nhãn phân loại {}').format(count_label))
    plt.ylabel('Độ chính xác')
    plt.title('Biểu đồ so sanh {} model \n Ngày train {}'.format(len(list_model),datetime.datetime.now()))
    # Tweak spacing to prevent clipping of tick-labels
    plt.subplots_adjust(bottom=0.3)
    plt.savefig("static/graphs/bieudososanh.png")


def model_train(filename, x_train):
    if filename == 'svm-rbf.pk':
        model = svm.SVC(kernel="rbf")
    elif filename == 'svm-linear.pk':
        model = svm.SVC(kernel="linear")
    elif filename == 'svm-poly.pk':
        model = svm.SVC(kernel="poly")
    elif filename == 'svm-sigmoid.pk':
        model = svm.SVC(kernel="sigmoid")
    elif filename == 'knn.pk':
        # có 2 option trong model KNN là weights='uniform' hoặc 'distance':
        # uniform hoạt động làm cho các điểm K trong n_neighbors bằng nhau
        # distance hoạt động làm cho model chọn các điểm K gần nhất
        # weights mặc định bằng 'uniform'
        n_neighbors = math.sqrt(len(x_train))/2
        model = KNeighborsClassifier(n_neighbors=int(n_neighbors),weights='uniform')
    elif filename == 'linear_svc_model.pk':
        model = LinearSVC(random_state=0)
    return model


def Predict(classifier, dictionaryPath, data_test, stopwords,
            special_characters='0123456789%@$.,=+-!;/()*"&^:#|\n\t\''):
    #
    features_test, labels_test = FeatureExtraction(dictionaryPath=dictionaryPath, data=data_test, stopwords=stopwords,
                                                   special_characters=special_characters).get_data_and_label()
    # 1s
    predict = classifier.predict(features_test)
    print(datetime.datetime.now())
    print(predict)
    return predict


def Gen_Dictionary(dictionaryPath, data_train, stopwords, special_characters='0123456789%@$.,=+-!;/()*"&^:#|\n\t\''):
    dict_words = []
    i = 0
    for text in data_train:
        i += 1
        print("Step {} / {}".format(i, len(data_train)))
        words = NLP(text=text['content'], stopwords=stopwords,
                    special_characters=special_characters).get_words_feature()
        dict_words.append(words)
    dictionary = corpora.Dictionary(dict_words)
    dictionary.filter_extremes(no_below=20, no_above=0.3)
    dictionary.save_as_text(dictionaryPath)

# doc tu DB: stopwords, data => json
# doc tu file: dictionary, model
# Training(fileModelPath='trained_model/linear_svc_model.pk', dictionaryPath=dictionaryPath, data_train=data_train, data_test=data_test, stopwords=stopwords,special_characters=settings.SPECIAL_CHARACTER)
# predict=Predict(classifier=est, dictionaryPath=dictionaryPath, data_test=data_train, stopwords=stopwords, special_characters=settings.SPECIAL_CHARACTER)
# strDic = Gen_Dictionary(data_train = data_train, stopwords = stopwords, special_characters = settings.SPECIAL_CHARACTER)
#