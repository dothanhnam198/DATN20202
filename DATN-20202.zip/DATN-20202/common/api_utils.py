import requests
from requests import HTTPError
import xml.etree.ElementTree as ET

class APIUtil:
    # lưu token cho các API khác
    api_token = ''
    # lưu url
    api_url = 'http://localhost/EPS.CSDLGIA.Services.WebAPI/'
    siteapi_code = 'OCR_API'

    # gọi API login
    @classmethod
    def loginAPI(cls, url_login, username, password):
        data = {'username': username, 'password': password, 'grant_type': 'password'}
        headers = {'Content-Type': 'application/x-www-form-urlencoded', 'Data-Type': 'Json', 'SITE-CODE': cls.siteapi_code}
        try:
            response = requests.post(url_login, data, headers=headers)
            try:
                jsonRet = response.json()
                cls.api_token = jsonRet['auth_token']
                return jsonRet
            except:
                return ''
        except HTTPError as http_err:
            print(f'HTTP error occurred: {http_err}')  # Python 3.6
        except Exception as err:
            return f'Other error occurred: {err}'
            print(f'Other error occurred: {err}')  # Python 3.6
        else:
            pass
        return ''

    # gọi API GET
    @classmethod
    def getAPI(cls, url, query, token=None, header=None):
        if not header:
            if token is None:
                token = cls.api_token
            headers = {'Content-Type': 'application/json', 'Data-Type': 'Json',
                   'Authorization': 'Token {0}'.format(token)}
        try:
            response = requests.get(url, params=query, headers=headers)
            try:
                return response.json()
            except:
                return response.content.decode('utf-8')
        except HTTPError as http_err:
            print(f'HTTP error occurred: {http_err}')  # Python 3.6
        except Exception as err:
            print(f'Other error occurred: {err}')  # Python 3.6
        else:
            pass
        return ''

    # gọi API POST
    @classmethod
    def postAPI(cls, url, data, token=None, header=None):
        if not header:
            if token is None:
                token = cls.api_token
            headers = {'Data-Type': 'Json', 'Authorization': 'Token {0}'.format(token)}
        try:
            response = requests.post(url, data=data, headers=headers)
            try:
                return response.json()
            except:
                return response.content.decode('utf-8')
        except HTTPError as http_err:
            return f'HTTP error occurred: {http_err}'  # Python 3.6
        except Exception as err:
            return f'Other error occurred: {err}'  # Python 3.6
        else:
            pass
        return ''


"""
<items>
    <item1>
        <title></title>
        <price></price>
    </item1>
</items>
"""
