import psycopg2
import cx_Oracle
import pyodbc

class OracleUtils():
    def open(self, ip, port, database, username, password):
        # self.connection = cx_Oracle.connect(username, password,
        #                                     cx_Oracle.makedsn(host=ip, port=port, service_name=database))
        self.connection = cx_Oracle.connect(username, password, ip + ':' + str(port) + '/' + database)
        self.cur = self.connection.cursor()

    def close(self):
        self.cur.close()
        self.connection.close()

    def execute(self, query):
        self.cur.execute(query)
        self.connection.commit()


class PostgresUtils():
    def open(self, ip, port, database, username, password):
        self.connection = psycopg2.connect(user=username, password=password, host=ip, port=port, dbname=database)
        self.cur = self.connection.cursor()

    def close(self):
        self.cur.close()
        self.connection.close()

    def execute(self, query):
        self.cur.execute(query)
        self.connection.commit()


class SQLServerUtils():
    def open(self, ip, port, database, username, password):
        self.connection = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+ip+';DATABASE='+database+';UID='+username+';PWD='+ password)
        self.cur = self.connection.cursor()
        print("OK OK OK OK")
    def close(self):
        self.cur.close()
        self.connection.close()

    def execute(self, query):
        self.cur.execute(query)
        self.connection.commit()

