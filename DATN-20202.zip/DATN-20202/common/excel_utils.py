import io
import xlsxwriter
from django.utils.translation import ugettext


def WriteToExcel(data):
    output = io.BytesIO()
    workbook = xlsxwriter.Workbook(output)
    worksheet_s = workbook.add_worksheet("Summary")

    # excel styles
    header = workbook.add_format({
        'bg_color': '#F7F7F7',
        'color': 'black',
        'align': 'center',
        'valign': 'top',
        'border': 1
    })
    cell = workbook.add_format({
        'align': 'left',
        'valign': 'top',
        'text_wrap': True,
        'border': 1
    })
    cell_center = workbook.add_format({
        'align': 'center',
        'valign': 'top',
        'border': 1
    })

    # write header
    worksheet_s.write(0, 0, ugettext("Tên danh mục"), header)
    worksheet_s.write(0, 1, ugettext("Id danh mục"), header)
    worksheet_s.write(0, 2, ugettext("Địa chỉ gốc"), header)
    worksheet_s.write(0, 3, ugettext("Nội dung sản phẩm"), header)

    # column widths
    category_name_col_width = 15
    content_train_col_width = 55
    url_col_width = 30

    # add data to the table
    for idx, data in enumerate(data):
        row = 1 + idx

        worksheet_s.write_string(row, 0, data.category_name, cell)
        if len(data.category_name) > category_name_col_width:
            category_name_col_width = len(data.category_name)

        worksheet_s.write_number(row, 1, data.category_id, cell_center)

        worksheet_s.write_string(row, 2, data.url, cell_center)
        if len(data.url) > url_col_width:
            url_col_width = len(data.url)

        content_train = data.content_train.replace('\r', '')
        worksheet_s.write_string(row, 3, content_train, cell)
        content_train_rows = compute_rows(content_train, content_train_col_width)
        worksheet_s.set_row(row, 15 * content_train_rows)

    # change column widths
    worksheet_s.set_column('A:A', category_name_col_width)  # Town column
    worksheet_s.set_column('B:B', 15)  # Town column
    worksheet_s.set_column('D:D', url_col_width)  # Observations column
    worksheet_s.set_column('C:C', content_train_col_width)  # Description column


    # close workbook
    workbook.close()
    xlsx_data = output.getvalue()
    return xlsx_data


def compute_rows(text, width):
    if len(text) < width:
        return 1
    phrases = text.replace('\r', '').split('\n')

    rows = 0
    for phrase in phrases:
        if len(phrase) < width:
            rows = rows + 1
        else:
            words = phrase.split(' ')
            temp = ''
            for idx, word in enumerate(words):
                temp = temp + word + ' '
                # check if column width exceeded
                if len(temp) > width:
                    rows = rows + 1
                    temp = '' + word + ' '
                # check if it is not the last word
                if idx == len(words) - 1 and len(temp) > 0:
                    rows = rows + 1
    return rows

def handle_uploaded_file(f):
    upload_folder = 'uploads/' + str(f.name)
    with open(upload_folder, 'wb+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)