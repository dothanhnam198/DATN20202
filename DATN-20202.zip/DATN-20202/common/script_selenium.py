#https://www.programcreek.com/python/example/100023/selenium.webdriver.Remote

from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
import time
import cv2
# import django
# django.setup()
# from repository.models import DauThau
def get_browser():
    if True:
        options = webdriver.ChromeOptions()
        options.add_argument("no-sandbox")
        options.add_argument("--disable-gpu")
        options.add_argument("--window-size=800,600")
        options.add_argument("--disable-dev-shm-usage")
        options.set_headless()
        host = '10.0.0.56'
        browser = webdriver.Remote(
            command_executor="http://10.0.0.56:4444/wd/hub",
            desired_capabilities=DesiredCapabilities.CHROME,
            options=options,
        )
        #driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds( desired_time ));
    return browser 
	
driver = get_browser()
driver.set_window_size(1804, 2896)
driver.maximize_window()
time.sleep(5)
print( driver.get_window_size())

def getElementAttribute(el, value):
    if el:
        return el.get_attribute(value)
    else:
        return None
def getElementOutHTML(el):
    if el:
        return el.get_attribute('outerHTML')
    else:
        return None
def getElementInHTML(el):
    if el:
        return el.get_attribute('innerHTML')
    else:
        return None
def findElementHasClass(driver, css, value):
    if driver:
        list_page = driver.find_elements_by_css_selector(css)
        for i in range(len(list_page)):
            link_page = list_page[i]
            if link_page.get_attribute("class") == value:
                return (i, list_page[i])
        return (None, None)
    else:
        return (None, None)

def findElementHasText(driver, css, value):
    if driver:
        list_page = driver.find_elements_by_css_selector(css)
        for i in range(len(list_page)):
            link_page = list_page[i]
            if (value is None or value == '') or (value.lower() in link_page.text.lower()):
                return (i, list_page[i])
        return (None, None)
    else:
        return (None, None)

def findElementHasHtml(driver, css, value):
    if driver:
        list_page = driver.find_elements_by_css_selector(css)
        for i in range(len(list_page)):
            link_page = list_page[i]
            if (value is None or value == '') or (value.lower() in link_page.get_attribute('innerHTML').lower()):
                return (i, list_page[i])
        return (None, None)
    else:
        return (None, None)

def GoPageList(driver):
    try:
        actions = ActionChains(driver)
        end_of_page = False
        while end_of_page == False:
            print(driver.execute_script("$('div#popup_this .b-close').click();")) #close dialog for element clickable
            driver.implicitly_wait(10)
            driver.save_screenshot("screenshot_page.png")
            driver.implicitly_wait(1)
            DoPageList(driver)
            list_page = driver.find_elements_by_css_selector('ul.pagination li')
            for i in range(len(list_page)):
                link_page = list_page[i]
                print('link_page', i)
                if link_page.get_attribute("class") == 'active':
                    if i+1 >= len(list_page):
                        end_of_page = True
                        break
                    link_page = list_page[i+1]
                    driver.implicitly_wait(1)
                    driver.implicitly_wait(1)
                    #print(driver.execute_script("arguments[0].click();", link_page))
                    #actions.move_to_element(link_page).click(link_page).perform()
                    #actions.move_to_element(link_page).perform()
                    try:
                        actions.move_to_element(link_page).perform()
                    except:
                        pass
                    driver.implicitly_wait(1)
                    #actions.click(link_page).perform()
                    driver.execute_script("arguments[0].click();", link_page)
                    #link_page.click()
                    driver.implicitly_wait(10)
                    driver.implicitly_wait(1)
                    driver.save_screenshot("screenshot_page_click_"+str(i)+".png")
                    driver.implicitly_wait(1)
                    break
    except:
        import traceback
        print(str(traceback.format_exc()))
        driver.save_screenshot("screenshot_page_loi.png")
def DoPageList(driver):
    try:
        actions = ActionChains(driver)
        list_hs = driver.find_elements_by_css_selector('table.table-dau-thau a')
        for i in range(len(list_hs)):
            print('So HST: ', len(list_hs))
            link_hs = list_hs[i]
            print('link_hs', i, link_hs.text)
            if i >20:
                break
            # action.moveToElement(link_hs).click().perform()
            # ActionChains(driver).move_to_element(link_hs).click(link_hs).perform()
            try:
                actions.move_to_element(link_hs).perform()
            except:
                pass
            driver.implicitly_wait(1)
            driver.implicitly_wait(10)
            driver.implicitly_wait(1)
            driver.implicitly_wait(1)
            #actions.click(link_hs).perform()
            driver.execute_script("arguments[0].click();", link_hs)

            DoPageIframe(driver)

            driver.back()
            #print(driver.execute_script("window.history.back();"))
            driver.implicitly_wait(10)

            list_hs = driver.find_elements_by_css_selector('table.table-dau-thau a')
            #driver.back()

    except:
        import traceback
        print(str(traceback.format_exc()))
        driver.save_screenshot("screenshot_hs_loi.png")

def DoPageIframe(driver):
    try:
        actions = ActionChains(driver)
        driver.implicitly_wait(10)
        driver.implicitly_wait(1)
        driver.save_screenshot("screenshot_hs_click_" + str(i) + ".png")
        driver.implicitly_wait(1)

        found = WebDriverWait(driver, 2).until(
            # EC.element_to_be_clickable((By.ID, "detailFrameResize"))
            EC.frame_to_be_available_and_switch_to_it((By.ID, "detailFrameResize"))
        )

        json = []

        jsonItem = {}

        (iTableTTLQ, tableTTLQ) = findElementHasHtml(driver, 'table', u'>THÔNG TIN LIÊN QUAN ĐẾN ĐẤU THẦU<')

        (_, tableGIAHAN) = findElementHasHtml(tableTTLQ, 'table', u'Gia hạn: ')
        giaHan = findElementHasHtml(tableGIAHAN, 'td.txt2', '')
        if giaHan:
            print(giaHan.text)
            jsonItem['GIA_HAN'] = giaHan.text
        else:
            jsonItem['GIA_HAN'] = ''

        for property in configJSONElement:
            jsonItem[property.property_name] = ''
            element = None

            element_tree = property.element_tree
            if element_tree.level_0_css != '':
                _, element = findElementHasHtml(driver, element_tree.level_0_css, element_tree.level_0_value)
            if element_tree.level_1_css != '':
                _, element = findElementHasHtml(element, element_tree.level_1_css, element_tree.level_1_value)
            if element_tree.level_2_css != '':
                _, element = findElementHasHtml(element, element_tree.level_2_css, element_tree.level_2_value)
            if element_tree.level_3_css != '':
                _, element = findElementHasHtml(element, element_tree.level_3_css, element_tree.level_3_value)
            if element:
                _, element = findElementHasHtml(element, property.element_css, '')
                if element:
                    jsonItem[property.property_name] = element.text

            json.push(jsonItem)

            jsonItem = {}


        """
        
        (iTableTTC, tableTTC) = findElementHasHtml(driver, 'table', u'>THÔNG TIN CHUNG<')
        (iTableTGT, tableTGT) = findElementHasHtml(driver, 'table', u'>THAM GIA DỰ THẦU<')
        (iTableMT, tableMT) = findElementHasHtml(driver, 'table', u'>MỞ THẦU<')
        (iTableDBDT, tableDBDT) = findElementHasHtml(driver, 'table', u'>BẢO ĐẢM DỰ THẦU<')
        
        getElementAttribute
        getElementOutHTML
        getElementInHTML
        findElementHasClass
        findElementHasText
        findElementHasHtml
        """

        driver.switch_to.default_content()
        pass
    except:
        import traceback
        print(str(traceback.format_exc()))

def clickElement(driver, el, css=''):
    try:
        driver.execute_script("arguments[0].click();", el)
        driver.implicitly_wait(100)
    except:
        try:
            el.click()
            driver.implicitly_wait(2)
        except:
            try:
                actions = ActionChains(driver)
                actions.move_to_element(el).perform()
                driver.implicitly_wait(2)
                actions.click(el).perform()
                driver.implicitly_wait(2)
            except:
                import traceback
                print(str(traceback.format_exc()))
    if not True: #debug/test
        driver.save_screenshot("screenshot_click_"+str(el).replace('<','').replace('>','').replace('"','')+".png")
        driver.implicitly_wait(30)

def crawlWeb(driver, configWeb):
    try:
        driver.get(configWeb['web_url'])
        driver.save_screenshot("screenshot_00.png")
        driver.implicitly_wait(10)

        actions = ActionChains(driver)
        end_of_page = False
        while end_of_page == False:
            if configWeb['js_first']:
                driver.execute_script(configWeb['js_first'])  # close dialog for element clickable
            driver.implicitly_wait(10)
            driver.save_screenshot("screenshot_page.png")
            driver.implicitly_wait(1)

            crawlPage(driver, configWeb)

            def enteredPage(driver, css):
                print(css)
                _, el = findElementHasHtml(driver, css, '')
                print(el)
                print(configWeb['page_stop_no_contains'] +'    ' + getElementOutHTML(el))
                try:
                    if configWeb['page_stop_no_contains'] not in getElementOutHTML(el):
                        return el
                    else:
                        return None
                except:
                    import traceback
                    print(str(traceback.format_exc()))
                    return el

            if configWeb['page_next_class'] != '':
                next_page = driver.find_elements_by_css_selector(configWeb['page_next_class'])
                if len(next_page) > 0:
                    if configWeb['page_stop_no_contains'] and configWeb['page_stop_no_contains'] not in getElementOutHTML(next_page[0]):
                        end_of_page = True
                        break
                    else:
                        clickElement(driver, next_page[0])
                        driver.implicitly_wait(500)
                        print('found')
                        found = False
                        while found == False:
                            xx = enteredPage(driver, configWeb['page_next_class'])
                            print('xxx ', xx)
                            if xx is not None:
                                found = True
                        print(found)

                        driver.implicitly_wait(10000)
                        driver.save_screenshot("screenshot_page_click_next" + ".png")
                        driver.implicitly_wait(10)
            else:
                list_page = driver.find_elements_by_css_selector(configWeb['page_list_css'])
                print('So trang: ', len(list_page))
                for i in range(len(list_page)):
                    link_page = list_page[i]
                    print('link_page', i)
                    if configWeb['page_current_class'] in link_page.get_attribute("class"):
                        if i + 1 >= len(list_page):
                            end_of_page = True
                            break
                        link_page = list_page[i + 1]
                        if configWeb['page_stop_no_contains']:
                            if configWeb['page_stop_no_contains'] not in getElementOutHTML(link_page):
                                end_of_page = True
                                break
                        print('next page: ', getElementOutHTML(link_page))
                        driver.implicitly_wait(2)

                        clickElement(driver, link_page)
                        driver.implicitly_wait(500)

                        driver.implicitly_wait(10)
                        driver.save_screenshot("screenshot_page_click_" + str(i) + ".png")
                        driver.implicitly_wait(10)
                        break
    except:
        import traceback
        print(str(traceback.format_exc()))
        driver.save_screenshot("screenshot_page_loi.png")

def check_exits_by_xpath(driver,xpath):
    try:
        end_next_page = driver.find_element_by_xpath(xpath)
        next_page = driver.find_elements_by_xpath("//section[2]/div[@class='container']/div[@class='row']/div[@class='col-md-9 d-fix-right-7']/div[@class='m-t-20']/div[@class='tab-content h-home-tab-content']/div[@id='tab2']/div[@class='l-box-paging']/nav[@class='clearfix']/ul[@class='pagination']/li[last()]/a")
        if end_next_page.text == next_page[0].text:
            return True
        else:
            return False
    except Exception as e:
        return False

def crawlPage_Nam_version(driver,url):
    try:
        driver.get(url)
        elements = WebDriverWait(driver, 20).until(
            EC.visibility_of_all_elements_located((By.XPATH, "//div[@id='tab2']/table[@class='table h-home-table h-home-table-3']/tbody/tr/td[@class='h-tbl-border']/p[1]/strong[@class='text-up color-1 ellipsis-content-1row']/a[@class='container-tittle']")))
        for element in elements:
            href = element.get_attribute('href')
            # mo trang chi tiet
            driver.execute_script("window.open('"+href+"');")
            # chuyen trang chi tiet
            driver.switch_to_window(driver.window_handles[1])

            # boc tach

            thong_tin_chung = WebDriverWait(driver, 20).until(
                EC.visibility_of_element_located((By.XPATH, "//section[2]/div[@class='container']/div[@class='row']/div[@class='col-md-9 m-t-10 d-fix-right-5']/div[@class='d-box-wrap m-b-20'][1]/div[@class='d-box-new']")))

            # tham_gia_du_thau = WebDriverWait(driver, 20).until(
            #     EC.visibility_of_element_located((By.XPATH,
            #                                       "//section[2]/div[@class='container']/div[@class='row']/div[@class='col-md-9 m-t-10 d-fix-right-5']/div[@class='d-box-wrap m-b-20'][2]/div[@class='d-box-new']")))
            # mo_thau = WebDriverWait(driver, 20).until(
            #     EC.visibility_of_element_located((By.XPATH,
            #                                       "//section[2]/div[@class='container']/div[@class='row']/div[@class='col-md-9 m-t-10 d-fix-right-5']/div[@class='d-box-wrap m-b-20'][3]/div[@class='d-box-new']")))
            # dam_bao_du_thau = WebDriverWait(driver, 20).until(
            #     EC.visibility_of_element_located((By.XPATH,
            #                                       "//section[2]/div[@class='container']/div[@class='row']/div[@class='col-md-9 m-t-10 d-fix-right-5']/div[@class='d-box-wrap m-b-20'][4]/div[@class='d-box-new']")))
            # defaults = {
            #     'thong_tin_chung': thong_tin_chung.text,
            #     'tham_gia_du_thau': tham_gia_du_thau.text,
            #     'mo_thau': mo_thau.text,
            #     'dam_bao_du_thau': dam_bao_du_thau.text,
            # }
            model = DauThau.objects.update_or_create(
                thong_tin_chung=thong_tin_chung.text,
                # tham_gia_du_thau=tham_gia_du_thau.text,
                # mo_thau=mo_thau.text,
                # dam_bao_du_thau=dam_bao_du_thau.text,
                # defaults=defaults
            )
            # model.thong_tin_chung = thong_tin_chung.text
            # model.tham_gia_du_thau = tham_gia_du_thau.text
            # model.mo_thau = mo_thau.text
            # model.dam_bao_du_thau = dam_bao_du_thau.text
            # model.save()

            driver.close()
            # ve trang chu
            driver.switch_to_window(driver.window_handles[0])
        next_page = "//section[2]/div[@class='container']/div[@class='row']/div[@class='col-md-9 d-fix-right-7']/div[@class='m-t-20']/div[@class='tab-content h-home-tab-content']/div[@id='tab2']/div[@class='l-box-paging']/nav[@class='clearfix']/ul[@class='pagination']/li[last()]/a"
        end_next_page = "//section[2]/div[@class='container']/div[@class='row']/div[@class='col-md-9 d-fix-right-7']/div[@class='m-t-20']/div[@class='tab-content h-home-tab-content']/div[@id='tab2']/div[@class='l-box-paging']/nav[@class='clearfix']/ul[@class='pagination']/li[@class='disabled']"
        is_exisited = check_exits_by_xpath(driver, end_next_page)
        if is_exisited ==True:
            driver.quit()
        else:
            next_page = WebDriverWait(driver, 20).until(
            EC.visibility_of_all_elements_located((By.XPATH, next_page)))
            next_page_url = next_page[0].get_attribute('href')
            # driver.execute_script("window.open('"+next_page_url+"');")
            # driver.switch_to_window(driver.window_handles[1])
            # mo trang tiep theo
            crawlPage_Nam_version(driver,next_page_url)

    except Exception as e:
        print(e)

def crawlPage(driver, configWeb):
    try:
        actions = ActionChains(driver)
        list_hs = driver.find_elements_by_css_selector(configWeb['page_detail_css'])
        print('So HST: ', len(list_hs))
        for i in range(len(list_hs)):
            link_hs = list_hs[i]
            if i >2:
                break

            clickElement(driver, link_hs)

            crawlPageDetail(driver, configWeb, i)

            if configWeb['page_detail_close_js']:
                driver.execute_script(configWeb['page_detail_close_js'])
                if configWeb['page_detail_iframe_css']:
                    found = WebDriverWait(driver, 2).until(
                        EC.invisibility_of_element_located((By.CSS_SELECTOR, configWeb['page_detail_iframe_css']))
                    )
                else:
                    driver.implicitly_wait(100)
            else:
                driver.back() #print(driver.execute_script("window.history.back();"))
            driver.implicitly_wait(100)

            list_hs = driver.find_elements_by_css_selector(configWeb['page_detail_css'])

    except:
        import traceback
        print(str(traceback.format_exc()))
        driver.save_screenshot("screenshot_hs_loi.png")
def crawlPageDetail(driver, configWeb, i):
    try:
        actions = ActionChains(driver)
        driver.implicitly_wait(10)
        driver.save_screenshot("screenshot_hs_click_" + str(i) + ".png")
        driver.implicitly_wait(10)

        if configWeb['page_detail_iframe_css']:
            found = WebDriverWait(driver, 2).until(
                EC.frame_to_be_available_and_switch_to_it((By.CSS_SELECTOR, configWeb['page_detail_iframe_css']))
            )

        json = []

        jsonItem = {}

        for property in configWeb['page_detail_property']:
            jsonItem[property['property_name']] = ''
            element = None

            element_tree = property['element_tree']
            try:
                if element_tree['level_0_css'] != '':
                    _, element = findElementHasHtml(driver, element_tree['level_0_css'], element_tree['level_0_value'])
                if element_tree['level_1_css'] != '':
                    _, element = findElementHasHtml(element, element_tree['level_1_css'], element_tree['level_1_value'])
                if element_tree['level_2_css'] != '':
                    _, element = findElementHasHtml(element, element_tree['level_2_css'], element_tree['level_2_value'])
                if element_tree['level_3_css'] != '':
                    _, element = findElementHasHtml(element, element_tree['level_3_css'], element_tree['level_3_value'])
                if element:
                    _, element = findElementHasHtml(element, property['element_css'], '')
                    if element:
                        jsonItem[property['property_name']] = element.text
            except:
                print('error css: ', property)

        print(jsonItem)

        configWeb['json_crawled'] = [*configWeb['json_crawled'], { configWeb['web_name']: jsonItem }]

        """
        
        (iTableTTC, tableTTC) = findElementHasHtml(driver, 'table', u'>THÔNG TIN CHUNG<')
        (iTableTGT, tableTGT) = findElementHasHtml(driver, 'table', u'>THAM GIA DỰ THẦU<')
        (iTableMT, tableMT) = findElementHasHtml(driver, 'table', u'>MỞ THẦU<')
        (iTableDBDT, tableDBDT) = findElementHasHtml(driver, 'table', u'>BẢO ĐẢM DỰ THẦU<')
        
        getElementAttribute
        getElementOutHTML
        getElementInHTML
        findElementHasClass
        findElementHasText
        findElementHasHtml
        """

        if configWeb['page_detail_iframe_css']:
            driver.switch_to.default_content()
        pass
    except:
        import traceback
        print(str(traceback.format_exc()))


#DAU THAU
configJSONElement = [
    {'property_name': 'CHU_Y', 'element_css': 'td.txt2', 'element_tree': {'level_0_css': 'table', 'level_0_value': u'>THÔNG TIN LIÊN QUAN ĐẾN ĐẤU THẦU<', 'level_1_css': 'table', 'level_1_value': u'>CHÚ Ý<', 'level_2_css': '', 'level_2_value': '', 'level_3_css': '', 'level_3_value': ''} }
    , {'property_name': 'TEN_KHLCNT', 'element_css': 'td:nth-child(2)', 'element_css': 'td.txt2', 'element_tree': {'level_0_css': 'table', 'level_0_value': u'>THÔNG TIN CHUNG<', 'level_1_css': 'tr', 'level_1_value': u'Tên KHLCNT', 'level_2_css': '', 'level_2_value': '', 'level_3_css': '', 'level_3_value': ''} }
    , {'property_name': 'BEN_MOI_THAU', 'element_css': 'td:nth-child(2)', 'element_tree': {'level_0_css': 'table', 'level_0_value': u'>THÔNG TIN CHUNG<', 'level_1_css': 'tr', 'level_1_value': u'Bên mời thầu', 'level_2_css': '', 'level_2_value': '', 'level_3_css': '', 'level_3_value': ''} }
    , {'property_name': 'CHU_DAU_TU', 'element_css': 'td:nth-child(2)', 'element_tree': {'level_0_css': 'table', 'level_0_value': u'>THÔNG TIN CHUNG<', 'level_1_css': 'tr', 'level_1_value': u'Chủ đầu tư', 'level_2_css': '', 'level_2_value': '', 'level_3_css': '', 'level_3_value': ''} }
]

configWeb = {'web_name': 'Thau'
    , 'web_url': 'http://muasamcong.mpi.gov.vn/goi-thau'
    , 'js_first': "$('div#popup_this .b-close').click();"
    , 'page_list_css': 'ul.pagination li', 'page_current_class': 'active', 'page_next_class': '', 'page_stop_no_contains': 'page-link'
    , 'page_detail_css': 'table.table-dau-thau a'
    , 'page_detail_iframe_css': 'detailFrameResize'
    , 'page_detail_property': configJSONElement
    , 'page_detail_close_js': ''
    , 'json_crawled': []
}

#TEST
# configJSONElement = [
#     {'property_name': 'TEN_DU_AN', 'element_css': 'td:nth-child(2)', 'element_tree': {'level_0_css': 'table.Vien_Bang', 'level_0_value': u'>Tên dự án<', 'level_1_css': 'tr', 'level_1_value': u'>Tên dự án<', 'level_2_css': '', 'level_2_value': '', 'level_3_css': '', 'level_3_value': ''} }
#     , {'property_name': 'TEN_GOI_THAU', 'element_css': 'td:nth-child(2)', 'element_tree': {'level_0_css': 'table.Vien_Bang', 'level_0_value': u'>Tên dự án<', 'level_1_css': 'tr', 'level_1_value': u'Tên gói thầu', 'level_2_css': '', 'level_2_value': '', 'level_3_css': '', 'level_3_value': ''} }
#     , {'property_name': 'CHU_DAU_TU', 'element_css': 'td:nth-child(2)', 'element_tree': {'level_0_css': 'table.Vien_Bang', 'level_0_value': u'>Tên dự án<', 'level_1_css': 'tr', 'level_1_value': u'Chủ đầu tư', 'level_2_css': '', 'level_2_value': '', 'level_3_css': '', 'level_3_value': ''} }
#     , {'property_name': 'GIA_DU_AN', 'element_css': 'td:nth-child(2)', 'element_tree': {'level_0_css': 'table.Vien_Bang', 'level_0_value': u'>Tên dự án<', 'level_1_css': 'tr', 'level_1_value': u'Giá gói thầu', 'level_2_css': '', 'level_2_value': '', 'level_3_css': '', 'level_3_value': ''} }
# ]
# configWeb = {'web_name': 'ThauHUE'
#     , 'web_url': 'https://dauthau.thuathienhue.gov.vn/'
#     , 'js_first': """$('input[id*="_btnKetQuaDauThau"]').click();"""
#     , 'page_list_css': 'div.DauThau_PhanTrang_Bang a', 'page_current_class': '', 'page_next_class': 'a.DauThau_PhanTrang_Trang:last-of-type', 'page_stop_no_contains': 'javascript:sendDauThau'
#     , 'page_detail_css': 'td.DauThau_CotXemChiTiet a'
#     , 'page_detail_iframe_css': 'iframe.fancybox-iframe'
#     , 'page_detail_property': configJSONElement
#     , 'page_detail_close_js': """$('div.fancybox-type-iframe a.fancybox-close').click();"""
#     , 'json_crawled': []
# }
json_crawled = {
    'thong_tin_chung':'',
    'tham_gia_du_thau': '',
    'mo_thau': '',

}
if False:
    driver.get('http://muasamcong.mpi.gov.vn/goi-thau?bid_target=bid&aujusted_limited=0&date_type=PUBLIC_DT&datetimestart=26/03/2021&datetimesend=02/04/2021')
    driver.save_screenshot("screenshot_00.png")
    driver.implicitly_wait(10)
    print(driver.execute_script("$('div#popup_this .b-close').click();"))  # close dialog for element clickable
    driver.implicitly_wait(30)
    driver.save_screenshot("screenshot_00_1.png")
    GoPageList(driver)
else:
    crawlPage_Nam_version(driver, "http://muasamcong.mpi.gov.vn/web/guest/lua-chon-nha-thau")
    print(configWeb['json_crawled'])
   
driver.close()
#def crawlWEB(drive):
#    drive.get('http://muasamcong.mpi.gov.vn/web/guest/lua-chon-nha-thau')
    # param = {click page-next} chec
    # list trang
        # for
            # drive get each page
                # drive get detail
                    # crawl ...
