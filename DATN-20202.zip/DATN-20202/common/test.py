# import json
# import xml.etree.ElementTree as ET
# import requests
# import lxml.html
# from lxml import etree
# import pysolr
# from common.db_utils import SQLServerUtils,OracleUtils
# import time
# import datetime
# a = requests.get('https://mediamart.vn/tivi/lg/smart-tivi-4k-lg-49-inch-49nano86tna-nanocell-hdr.htm',verify=False)
# solr = pysolr.Solr('http://localhost:8983/solr/test3')
# # x = '{"":"?"}'
# #
# # print(type(x))
# #
# # # parse x:
# # y = json.loads(x)
# # print(type(y))
# # print(y)
# #
# # # the result is a Python dictionary:
# #
# # web_response = requests.get("https://www.geeksforgeeks.org/")
# #
# # print(web_response.text)
# # print(type(web_response.text))
# # element_tree = lxml.html.fromstring(web_response.text)
# #
# # root = etree.HTML(web_response.text)
# # tree = etree.ElementTree(root)
# # find_text = etree.XPath("//a[text()='C']")
# # for target in find_text(root):
# #     print(tree.getpath(target))
# #
# #
# # title = "//div[@class='leftSideBar']/ul[@class='leftBarList']/li[1]/a/text()"
# #
# # value = element_tree.xpath("//a[text()='C']")
# # print(value)
# # for item in value:
# #     print(item.text)
#
# # test = requests.get("https://batdongsan.com.vn/ban-can-ho-chung-cu/p2096")
# # print('aaa')
# # ten = 'test01'
# # a =  "N'%s'" % ten
# # print(a)
# # tinh ="24"
# # huyen ="213"
# # xa="07201"
# # dongia="333333"
# # thongso = '1 tang 1 ngu smt'
# link = datetime.datetime.now().strftime('%d-%m-%Y')
# # print(type(link))
# # db = OracleUtils()
# # db.open('10.0.0.7','1521','orclpdb','qlgia4','A1Qaz2wsx')
# # db.execute("insert into TH_INTE_HANG_HOA_DICH_VU_AI (TEN,DON_GIA,PHAN_LOAI,THONG_SO_KY_THUAT,LINK_SAN_PHAM,DA_DUYET,NGAY_TAO,NGUON_THONG_TIN,NGAY_THU_THAP) values (N'%s',N'%s',N'%s',N'%s',N'%s',0,sysdate,N'%s',TO_DATE('%s','DD-MM_YY'))"
# #                             % ('test22',
# #                                'test',
# #                                'test',
# #                                'test',
# #                                'test',
# #                                'test1',
# #                                link))
# # db.execute("UPDATE TH_INTE_HANG_HOA_DICH_VU_AI SET TEN = N'%s', DON_GIA=N'%s', PHAN_LOAI=N'%s',THONG_SO_KY_THUAT= N'%s', LINK_SAN_PHAM=N'%s',DA_DUYET=%s, NGAY_TAO=TO_DATE('%s','DD-MM-YY'),NGUON_THONG_TIN=N'%s'  WHERE ID=%s"
# #            % (
# #               'test122',
# #               'test1',
# #               'test1',
# #               'test1',
# #               'test1',
# #               1,
# #               link,
# #               'test1',
# #                 10
# #             ))
# # print('work')
# # from spider_api.api import run_crawler
# # from django.conf import settings
# # from multiprocessing import Process, Queue
# # from repository import crawler_service
# # from repository.models import EPS_CrawlerSpider
#
# # def run_spider():
# #     spider = EPS_CrawlerSpider.objects.all()
# #     spider.status = ''
# #     spider.is_finished = False
# #     spider.save()
# #     timestamp = round(time.time())
# #     q = Queue()
# #     p = Process(target=run_crawler, args=(q, timestamp, spider, settings))
# #     p.start()
# #     spider.pid = p.pid
# #     spider.save()
# #     crawler_service.insert(timestamp, p.pid, spider)
# #
# # def job():
# #     print('work')
# # schedule.every(10).seconds.do(job)
# #
# # while True:
# #     schedule.run_pending()
# #     time.sleep(1)
# #
# # if link == 'a':
# #     link = 'b'
# # print(link)
# # import os
# # os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'csdlgia2.settings')
# # import django
# # django.setup()
# # from django_celery_beat.models import PeriodicTask, CrontabSchedule
# from celery.schedules import crontab
# #
# # # # -- Inside the function you want to add task dynamically
# # schedule = CrontabSchedule.objects.create(minute='*/1')
# # #
# # task = PeriodicTask.objects.create(name='work',
# #                                     task='repository.tasks.work', crontab=schedule,)
# # task.save()
# # from repository.models import EPS_CrawlerSpider
# # CELERY_BEAT_SCHEDULE = {
# #     "work": {
# #         "task": "repository.tasks.add",
# #         'schedule': crontab(minute='*/1'),
# #         "args": (10,10),
# #     },
# # }
# # schedule = dict()
# # spiders = EPS_CrawlerSpider.objects.all().order_by('-id')[0:4]
# # key = []
# # value = []
# # for spider in spiders:
# #     task = dict()
# #     task['task'] = "repository.tasks.add"
# #     task['schedule'] = crontab(minute=spider.id)
# #     task['args'] = (spider.id,spider.id)
# #     value.append(task)
# #     key.append(spider.name)
# #     print(task)
# # schedule = dict(zip(key,value))
# # print(CELERY_BEAT_SCHEDULE)
# # # print(schedule)
# test= {'key1':'10','key2':'nam','key3':'tests'}
# item = {}
for value in range(0,2):
    item['fake'] += ' ' + value
print(item['fake'])