# -*- coding: utf-8 -*-

# Define your item pipelines here
#
from django.core.serializers.json import DjangoJSONEncoder

# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
# from classifiers.action import mock_classify
# from repository.action import insert
from django.core import serializers
from repository import *
import json
from datetime import datetime
import codecs
from repository.models import *
from scrapy.pipelines.files import FilesPipeline
from repository.ai_service import create_ai_train_by_scrapy
from repository.crawler_service import xmlfile
from repository.models import EPS_CrawlerSpider2,EPS_CrawlerSpider
from repository.crawler_service import get_process,insert_product_crawled

class CrawlersPipeline(object):

    def open_spider(self, spider):
        print('open_spider')
        try:
            spider.pipeline_process_item = self.process_item
            self.product_list = []
            self.data_train = []
            spider.spider_info.status = '<u>Bắt đầu CRAWL lúc ' + datetime.now().strftime('%d/%m/%Y %H:%M:%S') + '</u>'
            spider.spider_info.is_finished = False
            spider.spider_info.save()
        except Exception as e:
            import traceback
            print(traceback.format_exc())

    def close_spider(self, spider):
        print('close_spider')
        print(len(spider.data_train))
        if type(spider.spider_info) == EPS_CrawlerSpider2:
            if self.data_train == []:
                self.data_train = spider.data_train
                create_ai_train_by_scrapy(self.data_train, spider.spider_info)
        # if type(spider.spider_info) == EPS_CrawlerSpider:
        #     if self.product_list == []:
        #         self.product_list = spider.product_list
        #         try:
        #             xmlfile(self.product_list,spider)
        #         except Exception as e:
        #             import traceback
        try:
            # process = get_process(spider.key, spider.spider_info.id)
            # process.total_product_crawled = len(spider.product_list)
            # process.save()
            # if type(spider.spider_info) == EPS_CrawlerSpider:
            #     for product in spider.product_list:
            #         insert_product_crawled(product, spider.spider_info,process)
            with codecs.open(spider.file_json, 'w', encoding='utf8') as f:
                f.write(json.dumps(spider.product_list, ensure_ascii=False))
                f.close()
            # co stop spider
            #update status
            status = str(spider.spider_info.status).split('.....')
            if len(status) > 1:
                spider.spider_info.status = status[0] + status[2]
            spider.spider_info.status += '<br><u>Kết thúc CRAWL lúc ' + datetime.now().strftime('%d/%m/%Y %H:%M:%S') + '</u>'
            spider.spider_info.status = spider.spider_info.status.replace('<br><br>', '<br>')
            spider.spider_info.is_finished = True
            spider.spider_info.save()
        except Exception as e:
            import traceback
            print(traceback.format_exc())

        print('close_spider end')

    def process_item(self, item, spider):
        print('process_item')
        try:
            print(json.dumps(item))
            self.product_list.append({ 'Title': item['title'], 'Description': item['Description'], 'Price': item['price'] })
            print(len(self.product_list))
            yield item
        except Exception as e:
            import traceback
            print(traceback.format_exc())
            yield None
