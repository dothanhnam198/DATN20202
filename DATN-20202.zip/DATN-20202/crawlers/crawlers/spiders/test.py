import scrapy
from scrapy import Spider
from scrapy.spiders import CrawlSpider, Rule
from scrapy.selector import Selector
from scrapy.linkextractors import LinkExtractor
import json
import datetime
from urllib.parse import urlparse
import requests as rq
from crawlers.crawlers.items import CrawlersItem
from repository import *
from repository.crawler_service import get_unique_spiderfields, get_key_value_of_spiderfield
import time
import json
from scrapy import Spider
from scrapy.spiders import CrawlSpider, Rule
from scrapy.selector import Selector
from scrapy.linkextractors import LinkExtractor
from scrapy.http import FormRequest, Request
import traceback
from scrapy_splash import SplashRequest
from repository.models import EPS_CrawlerSpider
from repository.crawler_service import get_process,insert_product_crawled

class TestSpider(scrapy.Spider):

    def __init__(self, key, spider_info, file_json, **kwargs):
        self.key = key
        self.spider_info = spider_info
        self.name = spider_info.name
        self.allowed_domains = [spider_info.domain]
        self.start_urls = [spider_info.domain_url]
        self.file_json = file_json
        self.product_list = []
        self.data_train = []

        #parsed_uri = urlparse(self.start_urls[0])
        #result = '{uri.scheme}://{uri.netloc}'.format(uri=parsed_uri)
        #self.domain = result
        super(TestSpider, self).__init__(**kwargs)
        #cookies={}, headers=

    def start_requests(self):
        #print('start_requests ')
        #requests = list(super(CrawlerSpider, self).start_requests())
        requests = list()
        try:
            if self.spider_info.home_url:
                #xu ly home => cat => product by cat => detail
                requests += [Request(self.spider_info.home_url, callback=self.parseCategories, errback=self.errback_httpbin, dont_filter=True)]
            # xu ly product by cat => detail
            if self.spider_info.product_url:
                for url in self.spider_info.product_url.split('\r\n'):
                    if '*' in url:
                        for page in range(1,3):
                            url_paging = str(url).replace('*',str(page))
                            a = rq.get(url_paging)
                            value = self.readElement(a, self.spider_info.product_xpath_list_link)
                            if len(value) ==0:
                                break
                            requests += [Request(url_paging, callback=self.parseProducts, errback=self.errback_httpbin, dont_filter=True)]
                    else:
                        if self.spider_info.product_url_post_data:
                            if self.spider_info.product_url_category_id:
                                #query string, id 1..10
                                for category_id in self.spider_info.product_url_category_id.split('\r\n'):
                                #     if page:
                                #         for page in range(1, page + 1):
                                #             formdata = None
                                #             if '{' in self.spider_info.product_url_post_data:
                                #                 try:
                                #                     form = str(self.spider_info.product_url_post_data).replace('?',str(category_id))
                                #                     form = str(self.spider_info.product_url_post_data).replace('page',str(page))
                                #                     formdata = json.loads(form)
                                #                 except:
                                #                     self.log_spider('<font style="color:red">ERROR POST DATA trong ' + response.url)
                                #                     self.log_spider(self.spider_info.product_url_post_data)
                                #                     self.log_spider(traceback.format_exc() + '</font>')
                                #                     pass
                                #             else:
                                #                 if '?' in url:
                                #                     url += '&' + str(self.spider_info.product_url_post_data).replace('?', str(page))
                                #                 else:
                                #                     url += '?' + str(self.spider_info.product_url_post_data).replace('?', str(page))
                                #             requests += [FormRequest(url, formdata=formdata, callback=self.parseProducts, errback=self.errback_httpbin, dont_filter=True)]
                                    if '\n' in category_id:
                                        istart = int(category_id.split('\n')[0])
                                        istop = int(category_id.split('\n')[1])
                                        for icat in range(istart, istop + 1):
                                            formdata = None
                                            if '{' in self.spider_info.product_url_post_data:
                                                try:
                                                    formdata = json.loads(str(self.spider_info.product_url_post_data).replace('?', str(icat)))
                                                except:
                                                    self.log_spider('<font style="color:red">ERROR POST DATA trong ' + response.url)
                                                    self.log_spider(self.spider_info.product_url_post_data)
                                                    self.log_spider(traceback.format_exc() + '</font>')
                                                    pass
                                            else:
                                                if '?' in url:
                                                    url += '&' + str(self.spider_info.product_url_post_data).replace('?', str(icat))
                                                else:
                                                    url += '?' + str(self.spider_info.product_url_post_data).replace('?', str(icat))
                                            requests += [FormRequest(url, formdata=formdata, callback=self.parseProducts, errback=self.errback_httpbin, dont_filter=True)]
                                    else:
                                        formdata = None
                                        if '{' in self.spider_info.product_url_post_data:
                                            if '*' in self.spider_info.product_url_post_data:
                                                for page in range(0, 10):
                                                    try:
                                                        form = str(self.spider_info.product_url_post_data).replace('?',
                                                                                                                   str(
                                                                                                                       category_id))
                                                        form = form.replace('*', str(page))
                                                        formdata = json.loads(form)
                                                        a = rq.post(url, data=formdata)
                                                        value = self.readElement(a,self.spider_info.product_xpath_list_link)
                                                        if len(value) <= 1:
                                                            break
                                                    except:
                                                        self.log_spider(
                                                            '<font style="color:red">ERROR POST DATA trong ' + response.url)
                                                        self.log_spider(self.spider_info.product_url_post_data)
                                                        self.log_spider(traceback.format_exc() + '</font>')

                                                    requests += [
                                                        FormRequest(url, formdata=formdata, callback=self.parseProducts,
                                                                    errback=self.errback_httpbin, dont_filter=True)]
                                            else:
                                                try:
                                                    form = str(self.spider_info.product_url_post_data).replace('?',
                                                                                                           str(category_id))
                                                    formdata = json.loads(form)

                                                except:
                                                    self.log_spider('<font style="color:red">ERROR POST DATA trong ' + response.url)
                                                    self.log_spider(self.spider_info.product_url_post_data)
                                                    self.log_spider(traceback.format_exc() + '</font>')

                                                requests += [
                                                        FormRequest(url, formdata=formdata, callback=self.parseProducts,
                                                                    errback=self.errback_httpbin, dont_filter=True)]
                                        else:
                                            if '?' in url:
                                                url += '&' + str(self.spider_info.product_url_post_data).replace('?', category_id)
                                            else:
                                                url += '?' + str(self.spider_info.product_url_post_data).replace('?', category_id)
                                            requests += [FormRequest(url, formdata=formdata, callback=self.parseProducts,
                                                                    errback=self.errback_httpbin, dont_filter=True)]
                            else:
                                formdata = None
                                try:
                                    formdata = json.loads(self.spider_info.product_url_post_data.replace('?', ''))
                                except:
                                    pass
                                requests += [FormRequest(url,  formdata=formdata, callback=self.parseProducts, errback=self.errback_httpbin, dont_filter=True)]
                        else:
                            if self.spider_info.splash_request is True:
                                splash_args = {
                                    'html': 1,
                                    'timeout': 3600,
                                }
                                # script = """
                                # function main(splash)
                                #     splash:init_cookies(splash.args.cookies)
                                #     local url = splash.args.url
                                #     assert(splash:go(url))
                                #     assert(splash:wait(5))
                                #     return {
                                #         cookies = splash:get_cookies(),
                                #         html = splash:html()
                                #     }
                                # end
                                # """
                                script = self.spider_info.rendering_script
                                requests += [SplashRequest(url, endpoint="execute", cache_args=['lua_source'],headers={'X-My-Header': 'value'},callback=self.parseProducts,
                                                    args={'lua_source': script,"runjs": self.spider_info.interacting_page, 'splash_args':splash_args})]
                            else:
                                requests += [Request(url, callback=self.parseProducts, errback=self.errback_httpbin, dont_filter=True)]

            #for request in requests:
            #    self.log_spider(request.url)
            return requests
        except:
            self.log_spider('<font style="color:red">ERROR trong start_requests')
            self.log_spider(traceback.format_exc() + '</font>')
            return None

    def errback_httpbin(self, failure):
        # log all failures
        #print(repr(failure))
        self.log_spider('<font style="color:red">HTTP_ERROR trong ' + failure.request.url + str(failure) + '</font>')

    def log_spider(self, msg):
        # print(msg)
        self.spider_info.status += '<br>' + str(msg)
        self.spider_info.status = self.spider_info.status.replace('<br><br>', '<br>')
        self.spider_info.save()

    def readElement(self, element_response, xpath_css):
        value = None
        product = None
        try:
            product = Selector(element_response)
        except:
            product = element_response
        try:
            value = product.xpath(xpath_css)
        except:
            pass
        if value is None:
            try:
                value = product.css(xpath_css)
            except:
                if value is None:
                    pass
                else:
                    self.log_spider('<font style="color:red">ERROR trong readElement ' + xpath_css)
                    self.log_spider(traceback.format_exc() + '</font>')
        return value

    def extractElement(self, elements):
        try:
            if elements is None:
                return ''
            else:
                return ''.join(elements.getall())
        except:
            import traceback
            self.log_spider('<font style="color:red">ERROR trong extractElement')
            self.log_spider(traceback.format_exc() + '</font>')
            return ''

    def parseCategories(self, response):
        #print('parseCategories '+response.url)
        try:
            categories = self.readElement(response, self.spider_info.category_xpath_list_link)
            if categories is None or len(categories) == 0:
                self.log_spider('<font style="color:red">ERROR xpath category list trong ' + response.url)
                self.log_spider(self.spider_info.category_xpath_list_link + '</font>')
                self.log_spider(response.text)
            for category in categories:
                url = self.extractElement(category)
                if not 'http://' in url and not 'https://' in url:
                    url = self.spider_info.domain_url + url
                if url:
                    yield Request(url, callback=self.parseProducts, errback=self.errback_httpbin)
                    yield {}
        except Exception as e:
            import traceback
            self.log_spider('<font style="color:red">ERROR trong parseCategories')
            print(traceback.format_exc() + '</font>')
            yield None

    def parseProducts(self, response):
        #print('parseProducts '+response.url)

        # script = self.spider_info.rendering_script
        # script = """
        #         function main(splash)
        #         splash:init_cookies(splash.args.cookies)
        #     assert(splash:autoload(splash.args.jquery))
        #     splash:go(splash.args.url)
        #     local pages = splash:html()
        #     local page_index = splash.args.runjs
        #         local i=2
        #         local pcount = splash:evaljs(string.format(page_index .. ".length",i+1))
        #         print(pcount)
        #         while pcount > 0 do
        #         page = string.format(page_index .. "[0].click()",i)
        #         splash:runjs(page)
        #         splash:wait(1.5)
        #         pcount = splash:evaljs(string.format(page_index .. '.length',i+1))
        #         print(page)
        #         print(pcount)
        #         pages = pages .. splash:html()
        #         i=i+1
        #         end
        #         return {
        #             html = pages,
        #             url = splash:url(),
        #         }
        #     end
        # """
        script = self.spider_info.rendering_script
        jquery = "http://10.0.0.56:9003/static/jquery-2.1.3.minLUA.js"
        try:
            products = self.readElement(response, self.spider_info.product_xpath_list_link)
            self.log_spider(str(len(products)) + ' ' + response.url.replace(self.spider_info.domain_url, '').replace(self.spider_info.domain, '').replace('http://', '').replace('https://', '').replace('www.', ''))
            if products is None or len(products) == 0:
                self.log_spider('<font style="color:red">ERROR xpath product list trong ' + response.url)
                self.log_spider(self.spider_info.product_xpath_list_link + '</font>')
                # self.log_spider(response.text)
            # if self.spider_info.splash_request is True:
            #     yield SplashRequest(
            #         url=response.url,
            #         callback=self.parseProducts, endpoint="execute",
            #         args={"lua_source": script, "runjs": self.spider_info.interacting_page, "jquery": jquery, "html":1,"timeout":3600}
            #     )
            print('xxxx' + str(len(products)))
            for product in products:
                url = self.extractElement(product)
                # if url[0] is not '/':
                #     url = '/' + url
                # xử lý trường hợp path
                if not 'http://' in url and not 'https://' in url:
                    absolute_path = self.spider_info.domain_url + url
                    if len(self.readElement(rq.get(absolute_path,verify=False),self.spider_info.product_xpath_detail_description)) >0 :
                        url = absolute_path
                    else:
                        path = self.spider_info.domain_url.replace((response.url.split('/')[-1]),'')
                        url = path + url
                    yield Request(url, callback=self.parseProductDetail, errback=self.errback_httpbin)
                else:
                    yield Request(url, callback=self.parseProductDetail, errback=self.errback_httpbin)
        except Exception as e:
            import traceback
            self.log_spider('<font style="color:red">ERROR trong parseProducts')
            self.log_spider(traceback.format_exc() + '</font>')
            yield None

    def parseProductDetail(self, response):
        #print('parseProductDetail '+response.url)
        try:
            data = {}
            item = {}
            process = get_process(self.key, self.spider_info.id)

            if type(self.spider_info) == EPS_CrawlerSpider:
                fields = get_unique_spiderfields(self.spider_info.pk)
                keys,values = get_key_value_of_spiderfield(fields)
                elements = []
                item['fake_comparing'] = ''
                for value in values:
                    a = self.extractElement(self.readElement(response,value))
                    if len(a) ==0:
                        a = 'null'
                    elements.append(a)
                    item['fake_comparing'] += a + ' '
                # newitem = dict(zip(tuple(keys),tuple(elements)))
                # item.update(newitem)
            item['process'] = process.id
            item['title'] = self.extractElement(self.readElement(response, self.spider_info.product_xpath_detail_name))
            item['price'] = self.extractElement(self.readElement(response, self.spider_info.product_xpath_detail_price))
            item['category'] = self.extractElement(self.readElement(response, self.spider_info.product_xpath_detail_category))
            item['specification'] = self.extractElement(self.readElement(response, self.spider_info.product_xpath_detail_specification))
            item['description'] = self.extractElement(self.readElement(response, self.spider_info.product_xpath_detail_description))
            item['image_link'] = self.extractElement(self.readElement(response, self.spider_info.product_xpath_detail_image_link))

            #print(self.readElement(response, 'div.boxArticle .area_article *:not(script)::text').extract())
            #print(self.readElement(response, 'ul.breadcrumb li:nth-of-type(2) a::text').get())

            if not 'http://' in item['image_link'] and not 'https://' in item['image_link']:
                item['image_link'] = self.spider_info.domain_url + item['image_link']
            item['link'] = response.url
            item['date_crawl'] =datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            data['category'] = item['category']
            data['content_train'] = item['title'] + '\r\n' + item['specification'] + '\r\n' + item['description']
            data['link'] = item['link']
            data['title'] = item['title']
            self.data_train.append(data)
            self.product_list.append(item)

            status = str(self.spider_info.status).split('.....')
            if len(status) > 1:
                self.spider_info.status = status[0] + status[2]
            self.log_spider('.....<font style="color:blue">' + str(item['title']) + '</font>' + '.....')
            return item
        except Exception as e:
            import traceback
            self.log_spider('<font style="color:red">ERROR trong parseProductDetail')
            self.log_spider(traceback.format_exc() + '</font>')
            yield {}


