"""csdlgia2 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, re_path, include
from rest_framework.authtoken.views import obtain_auth_token
from django.conf.urls.static import static
from django.conf import settings
from spider_api.views import SpiderListView
from spider_api.api import *
from rest_framework.routers import DefaultRouter
from repository.ai_service import download_file
from django.views.generic.base import RedirectView
from django.contrib.staticfiles.storage import staticfiles_storage
from haystack.views import SearchView

router = DefaultRouter()
router.register(r'spider', SpiderViewSet)
router.register(r'spider2', SpiderViewSet2)
router.register(r'ai_training', AITrainingViewSet)
router.register(r'crawler_process', CrawlerProcessViewSet)
router.register(r'spider_fields', SpiderFieldsViewSet)



urlpatterns = [
    path('search/', include('haystack.urls')),
    path('admin/', admin.site.urls),
    path(
        'favicon.ico',
        RedirectView.as_view(url=staticfiles_storage.url('favicon.ico'))
    ),
    path(
        '/favicon.ico/',
        RedirectView.as_view(url=staticfiles_storage.url('favicon.ico'))
    ),
    # path('', include('spider_api.urls')),
    re_path(r'^jet/', include('jet.urls', 'jet')),
    path('', include('client.urls')),
    path('api/spider/', include('spider_api.api_urls')),
    path('api/config/', include('dbapi_api.api_urls')),
    path('api/ai/', include('classifier_ai_api.api_urls')),
    path('spider/', include('spider_api.urls')),
    path('sanpham/', include('spider_api.urls')),
    path(r'apilist/', include(router.urls)),
    path('api/users/', include('users.api.api_urls', 'account_api')),
    path('api/api-token-auth/', obtain_auth_token, name='api_token_auth'),
    path('<str:filename>/', download_file)

]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
