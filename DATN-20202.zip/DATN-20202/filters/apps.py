from django.apps import AppConfig


class FiltersConfig(AppConfig):
    name = 'filters'
