from django.contrib import admin
from .models import *
# Register your models here.

class EPS_DBAPIConfig_Admin(admin.ModelAdmin):
    list_display = ['type_db', 'ip', 'name_db', 'url_signin', 'url']
    list_filter = (
        ('type_db'),
    )
    search_fields = ['name_db', 'url', ]

admin.site.register(EPS_DBAPIConfig, EPS_DBAPIConfig_Admin)


class EPS_AIConfig_Admin(admin.ModelAdmin):
    list_display = ['modelAI', 'specification_characters']

admin.site.register(EPS_AIConfig, EPS_AIConfig_Admin)

class EPS_Category_Admin(admin.ModelAdmin):
    list_display = ['category_name']
    list_filter = (
        ('category_name'),
    )
    search_fields = ['category_name' ]

admin.site.register(EPS_Category, EPS_Category_Admin)

class EPS_AIModel_Admin(admin.ModelAdmin):
    list_display = ['name', 'filename', 'result','image_plot', 'is_deactive', 'updated_at', 'created_at']

admin.site.register(EPS_AIModel, EPS_AIModel_Admin)

class EPS_AITrain_Admin(admin.ModelAdmin):
    list_display = ['category_name', 'is_test_data', 'is_trained', 'is_deactive']
    list_filter = (
        ('is_test_data'),
        ('category_name'),
        ('is_trained'),
        ('is_deactive'),
    )
    search_fields = ['content_train', 'url', ]
    ordering = ('-updated_at', '-created_at')

admin.site.register(EPS_AITrain, EPS_AITrain_Admin)

class EPS_CrawlerSpider_Admin(admin.ModelAdmin):
    list_display = ['name', 'domain', 'home_url', 'category_xpath_list_link', 'product_url', 'product_xpath_list_link', 'is_deactive', 'created_at', 'pid','interacting_page','splash_request', 'is_finished', 'status']
    list_filter = (
        ('domain'),
        ('is_deactive'),
        ('is_finished'),
    )
    search_fields = ['name', 'status', ]
    ordering = ('-created_at',)

admin.site.register(EPS_CrawlerSpider, EPS_CrawlerSpider_Admin)


class EPS_CrawlerSpider2_Admin(admin.ModelAdmin):
    list_display = ['name', 'category_name', 'domain', 'home_url', 'category_xpath_list_link', 'product_url', 'product_xpath_list_link', 'is_deactive', 'created_at', 'pid', 'is_finished', 'status']
    list_filter = (
        ('domain'),
        ('is_deactive'),
        ('is_finished'),
    )
    search_fields = ['name', 'status', ]
    ordering = ('-created_at',)

admin.site.register(EPS_CrawlerSpider2, EPS_CrawlerSpider2_Admin)

class EPS_CrawlerConfig_Admin(admin.ModelAdmin):
    list_display = ['delay_time', 'concurrent_request', 'concurrent_request_per_domain', 'concurrent_request_per_ip', 'is_bypassAI']

admin.site.register(EPS_CrawlerConfig, EPS_CrawlerConfig_Admin)

class EPS_CrawlerProcess_Admin(admin.ModelAdmin):
    list_display = ['spider', 'timestamp', 'created_at', 'finished_at', 'total_runtime', 'pid', 'is_running', 'status']
    list_filter = (
        ('spider'),
        ('is_running'),
    )
    search_fields = ['status', ]
    ordering = ('-created_at',)

admin.site.register(EPS_CrawlerProcess, EPS_CrawlerProcess_Admin)


class EPS_SpiderField_Admin(admin.ModelAdmin):
    list_display = ['spider', 'name', 'selector']
    list_filter = (
        ('spider'),
        ('name'),
    )
    search_fields = ['name', ]
    ordering = ('-name',)

admin.site.register(EPS_SpiderField, EPS_SpiderField_Admin)
