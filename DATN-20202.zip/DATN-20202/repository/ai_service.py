import django
django.setup()
from .models import *
import datetime
from common.ai_utils import *
from django.http import HttpResponse
import mimetypes
import io
from repository.crawler_service import xmlfile,insert_product_crawled
from common.excel_utils import WriteToExcel
from common.db_utils import *

def insert(insert_data):
    spider_item = EPS_CrawlerSpider.objects.create()
    spider_item.title = insert_data['title']
    spider_item.price = insert_data['price']
    spider_item.description = insert_data['description']
    spider_item.url = insert_data['url']
    spider_item.crawled_at = datetime.now()
    spider_item.save()


def update(id, update_data):
    spider_item = EPS_CrawlerSpider.objects.get(pk=id)
    spider_item.title = update_data['title']
    spider_item.price = update_data['price']
    spider_item.description = update_data['description']
    spider_item.url = update_data['url']
    spider_item.save()


def get(id):
    return EPS_AIConfig.objects.get(pk=id)


def update_ai_config(id, info):
    config = EPS_AIConfig.objects.get(pk=id)
    config.modelAI_id = info['modelAI_id']
    config.stopwords = info['stopwords']
    config.specification_characters = info['specification_characters']
    config.dictination_json = info['dictination_json']

    config.save()
    return config


def get_ai_config(id):
    return EPS_AIConfig.objects.get(pk=id)


def insert_ai_train(info):
    new_pattern = EPS_AITrain()
    new_pattern.is_test_data = info['is_test_data']
    new_pattern.category_name = info['category_name']
    new_pattern.category_id = info['category_id']
    new_pattern.content_train = info['content_train']
    new_pattern.url = info['url']
    new_pattern.is_trained = info['is_trained']
    new_pattern.is_deactive = info['is_deactive']
    new_pattern.created_at = info['created_at']
    new_pattern.updated_at = info['updated_at']

    new_pattern.save()
    return new_pattern


def update_ai_train(id, info):
    pattern = EPS_AITrain.objects.get(pk=id)
    pattern.is_test_data = info['is_test_data']
    pattern.category_name = info['category_name']
    pattern.category_id = info['category_id']
    pattern.content_train = info['content_train']
    pattern.url = info['url']
    pattern.is_trained = info['is_trained']
    pattern.is_deactive = info['is_deactive']
    pattern.created_at = pattern.created_at
    pattern.updated_at = info['updated_at']
    pattern.save()
    return pattern


def get_ai_train(id):
    return EPS_AITrain.objects.get(pk=id)


def create_ai_train_by_scrapy(data_train, spider):
    for obj in data_train:
        if EPS_AITrain.objects.filter(url=obj['link']).count() == 0:
            new_ai_train = EPS_AITrain()
            new_ai_train.is_test_data = False
            new_ai_train.category_name = spider.category_name
            new_ai_train.category_id = spider.category_id
            new_ai_train.content_train = obj['content_train']
            new_ai_train.url = obj['link']
            new_ai_train.is_trained = False
            new_ai_train.is_deactive = False
            new_ai_train.created_at = datetime.datetime.now()
            new_ai_train.save()
        else:
            pass
    return ''


def train_ai_classifier_product(product_train, id):
    data_train = []
    # data_test = []
    for train in product_train:
        data_train.append({
                    'category': str(train['category_name']),
                    'content': str(train['content_train'])
                })
    # for test in product_test:
    #     data_test.append({
    #                 'category': str(test['category_name']),
    #                 'content': str(test['content_train'])
    #             })
    # data_train = data_train[:350]
    # data_test = data_test[:250]
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    uploadFolder = os.path.join(BASE_DIR, 'uploads')

    ai_config = EPS_AIConfig.objects.all().first()
    ai_model = EPS_AIModel.objects.get(pk=id)
    print(ai_config)
    if ai_config.modelAI:
        dictionaryPath = os.path.join(uploadFolder, 'dictionary.txt')
        stopwords = FileReader(filePath='').read_stopwords_from_string(ai_config.stopwords)
        print(stopwords)
        print(ai_config.specification_characters)
        log = Training(ai_model=ai_model,fileModelPath=os.path.join(uploadFolder, ai_config.modelAI.filename), dictionaryPath=dictionaryPath,
                 data_train=data_train, stopwords=stopwords,
                 special_characters=ai_config.specification_characters)
        return log
    return ''


def training_all(product_train):
    data_train = []
    # data_test = []
    for train in product_train:
        data_train.append({
                    'category': str(train['category_name']),
                    'content': str(train['content_train'])
                })
    # for test in product_test:
    #     data_test.append({
    #                 'category': str(test['category_name']),
    #                 'content': str(test['content_train'])
    #             })
    # data_train = data_train[:350]
    # data_test = data_test[:250]
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    uploadFolder = os.path.join(BASE_DIR, 'uploads')

    ai_config = EPS_AIConfig.objects.all().first()
    print(ai_config)
    if ai_config.modelAI:
        dictionaryPath = os.path.join(uploadFolder, 'dictionary.txt')
        stopwords = FileReader(filePath='').read_stopwords_from_string(ai_config.stopwords)
        print(stopwords)
        print(ai_config.specification_characters)
        log = Training_all(fileModelPath=os.path.join(uploadFolder, ai_config.modelAI.filename), dictionaryPath=dictionaryPath,
                 data_train=data_train, stopwords=stopwords,
                 special_characters=ai_config.specification_characters)
        return log
    return ''


def update_product(products, spider):
    try:
        def findall(v, k, z):
            if type(v) == type({}):
                for k1 in v:
                    if v[k1] == k:
                        v[k1] = z
                    v[k1] = findall(v[k1], k, z)
            return v

        spider.status += '<br><u>Bắt đầu AI lúc ' + datetime.datetime.now().strftime('%d/%m/%Y %H:%M:%S') + '</u>'
        spider.status = spider.status.replace('<br><br>', '<br>')
        spider.save()

        BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        uploadFolder = os.path.join(BASE_DIR, 'uploads')

        ai_config = EPS_AIConfig.objects.all().first()
        dbapi_config = EPS_DBAPIConfig.objects.all().first()

        if ai_config.modelAI:
            dictionaryPath = os.path.join(uploadFolder, 'dictionary.txt')
            stopwords = FileReader(filePath='').read_stopwords_from_string(ai_config.stopwords)
            # 3p
            est = FileStore(filePath=os.path.join(uploadFolder, ai_config.modelAI.filename)).read_pickle()
            product_list = []
            for product in products:
                data_train = [{
                    'category': str(product['category']),
                    'content': str(product['title'])+' '+str(product['specification'])+' '+str(product['description'])
                }]

                predict = Predict(classifier=est, dictionaryPath=dictionaryPath, data_test=data_train, stopwords=stopwords, special_characters=ai_config.specification_characters)

                product['category_ai'] = str(predict[0])
                if product['category_ai'] == 'smartphone':
                    product['category_ai'] = 'Điện thoại'
                elif product['category_ai'] == 'ti vi':
                    product['category_ai'] = 'Tivi'
                elif product['category_ai'] == 'may giat':
                    product['category_ai'] = 'Máy giặt'
                elif product['category_ai'] =='dieu hoa':
                    product['category_ai'] ='Điều hòa'
                elif product['category_ai'] == 'laptop':
                    product['category_ai'] = 'Laptop'
                else:
                    pass
                product_list.append(product)
                category = EPS_Category.objects.get(category_name=product['category_ai'])
                insert_product_crawled(product,spider,category)


                status = str(spider.status).split('.....')
                if len(status) > 1:
                    spider.status = status[0] + status[2]
                spider.status += '<br>' + str(
                    '.....<font style="color:blue">DB/API: ' + str(product['title']) + '</font>' + '.....')
                spider.status = spider.status.replace('<br><br>', '<br>')
                spider.save()
            if type(spider) == EPS_CrawlerSpider:
                try:
                    xmlfile(product_list,spider)
                except Exception as e:
                    import traceback
        spider.status += '<br><u>Kết thúc AI lúc ' + datetime.datetime.now().strftime(
            '%d/%m/%Y %H:%M:%S') + '</u>'
        spider.status = spider.status.replace('<br><br>', '<br>')
        spider.save()
    except:
        import traceback
        print('<font style="color:red">ERROR trong DBAPI.update_product')
        print(str(traceback.format_exc()) + '</font>')


def download_file(request, filename):
    # fill these variables with real values
    response = HttpResponse
    data = EPS_AITrain.objects.all().order_by('created_at')[0:5]
    try:
        fl = WriteToExcel(data)
        response = HttpResponse(content_type='application/vnd.ms-excel')
        response.write(fl)
        response['Content-Disposition'] = "attachment; filename=Dulieumau.xlsx"
        return response
    except FileNotFoundError:
        pass
    return HttpResponse('FileNotFoundError')


