from django.apps import AppConfig

class RepositoryConfig(AppConfig):
    name = 'repository'
