import django
django.setup()
from .models import *
from datetime import datetime
from django.utils.dateparse import parse_date
from django.utils import timezone
import xml.etree.ElementTree as ET
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
import time
def insert(timestamp, pid, spider):
    # do something to insert
    #EPS_CrawlerProcess.objects.all().delete()
    new_process = EPS_CrawlerProcess.objects.create()
    new_process.timestamp = timestamp
    new_process.pid = pid
    new_process.created_at = datetime.now(tz=timezone.utc)
    new_process.is_running = True
    new_process.spider = spider
    new_process.save()
    return new_process

def get_process(timestamp, spider):
    # do something to insert
    #EPS_CrawlerProcess.objects.all().delete()
    process = EPS_CrawlerProcess.objects.get(spider=spider,timestamp=timestamp)
    return process

def stop_process(timestamp, spider):
    process = EPS_CrawlerProcess.objects.filter(timestamp=timestamp).first()
    if process is not None:
        process.is_running = False
        process.finished_at = datetime.now(tz=timezone.utc)
        t1=datetime.strptime(str(process.finished_at).split('.')[0], '%Y-%m-%d %H:%M:%S')
        t2=datetime.strptime(str(process.created_at).split('.')[0], '%Y-%m-%d %H:%M:%S')
        process.total_runtime = (t1-t2).total_seconds()
        process.is_running = False
        process.status = spider.status
        process.save()


def insert_config(info):
    new_config = EPS_CrawlerConfig.objects.create()
    new_config.delay_time = info['delay_time']
    new_config.concurrent_request = info['concurrent_request']
    new_config.concurrent_request_per_domain = info['concurrent_request_per_domain']
    new_config.concurrent_request_per_ip = info['concurrent_request_per_ip']
    new_config.user_agent = info['user_agent']
    new_config.proxy_ip = info['proxy_ip']
    new_config.request_header = info['request_header']
    new_config.is_bypassAI = info['is_bypassAI']

    new_config.save()
    return new_config


def update_config(id, info):
    config = EPS_CrawlerConfig.objects.get(pk=id)
    config.delay_time = info['delay_time']
    config.concurrent_request = info['concurrent_request']
    config.concurrent_request_per_domain = info['concurrent_request_per_domain']
    config.concurrent_request_per_ip = info['concurrent_request_per_ip']
    config.user_agent = info['user_agent']
    config.proxy_ip = info['proxy_ip']
    config.request_header = info['request_header']
    config.is_bypassAI = info['is_bypassAI']

    config.save()
    return config


def get_crawler_config(id):
    return EPS_CrawlerConfig.objects.get(pk=id)


def insert_spider(insert_data):
    new_spider = EPS_CrawlerSpider.objects.create()
    new_spider.name = insert_data['name']
    new_spider.domain = insert_data['domain']
    new_spider.domain_url = insert_data['domain_url']
    new_spider.home_url = insert_data['home_url']
    new_spider.category_xpath_list_link = insert_data['category_xpath_list_link']
    new_spider.product_url = insert_data['product_url']
    new_spider.product_url_post_data = insert_data['product_url_post_data']
    new_spider.product_url_category_id = insert_data['product_url_category_id']
    new_spider.product_xpath_list_link = insert_data['product_xpath_list_link']
    new_spider.product_xpath_detail_name = insert_data['product_xpath_detail_name']
    new_spider.product_xpath_detail_price = insert_data['product_xpath_detail_price']
    new_spider.product_xpath_detail_category = insert_data['product_xpath_detail_category']
    new_spider.product_xpath_detail_specification = insert_data['product_xpath_detail_specification']
    new_spider.product_xpath_detail_description = insert_data['product_xpath_detail_description']
    new_spider.product_xpath_detail_image_link = insert_data['product_xpath_detail_image_link']
    new_spider.interacting_page = insert_data['interacting_page']
    new_spider.timeout_splash = insert_data['timeout_splash']
    new_spider.splash_request = insert_data['splash_request']
    new_spider.rendering_script = insert_data['rendering_script']
    new_spider.day_of_week = insert_data['day_of_week']
    new_spider.hour = insert_data['hour']
    new_spider.minute = insert_data['minute']

    new_spider.save()
    return new_spider


def update_spider(id, insert_data):
    spider = EPS_CrawlerSpider.objects.get(pk=id)
    spider.name = insert_data['name']
    spider.domain = insert_data['domain']
    spider.domain_url = insert_data['domain_url']
    spider.home_url = insert_data['home_url']
    spider.category_xpath_list_link = insert_data['category_xpath_list_link']
    spider.product_url = insert_data['product_url']
    spider.product_url_post_data = insert_data['product_url_post_data']
    spider.product_url_category_id = insert_data['product_url_category_id']
    spider.product_xpath_list_link = insert_data['product_xpath_list_link']
    spider.product_xpath_detail_name = insert_data['product_xpath_detail_name']
    spider.product_xpath_detail_price = insert_data['product_xpath_detail_price']
    spider.product_xpath_detail_category = insert_data['product_xpath_detail_category']
    spider.product_xpath_detail_specification = insert_data['product_xpath_detail_specification']
    spider.product_xpath_detail_description = insert_data['product_xpath_detail_description']
    spider.product_xpath_detail_image_link = insert_data['product_xpath_detail_image_link']
    spider.interacting_page = insert_data['interacting_page']
    spider.timeout_splash = insert_data['timeout_splash']
    spider.splash_request = insert_data['splash_request']
    spider.rendering_script = insert_data['rendering_script']
    spider.day_of_week = insert_data['day_of_week']
    spider.hour = insert_data['hour']
    spider.minute = insert_data['minute']
    spider.save()
    return spider


def get_spider(id):
    return EPS_CrawlerSpider.objects.get(pk=id)


def insert_spider_field(inser_data):
    new_spider = EPS_SpiderField()
    new_spider.name = inser_data['name']
    new_spider.spider_id = inser_data['spider']
    new_spider.selector = inser_data['selector']
    new_spider.key_in_json = inser_data['key_in_json']
    new_spider.is_inactive = inser_data['is_inactive']

    new_spider.save()
    return new_spider


def update_spider_field(id, inser_data):
    spider = EPS_SpiderField.objects.get(pk=id)
    owner_spider = EPS_CrawlerSpider.objects.get(pk=inser_data['spider'])
    spider.name = inser_data['name']
    spider.spider = owner_spider
    spider.selector = inser_data['selector']
    spider.key_in_json = inser_data['key_in_json']
    spider.is_inactive = inser_data['is_inactive']
    spider.save()
    return spider


def get_unique_spiderfields(id):
    spider_id = id
    unique_fields = EPS_SpiderField.objects.filter(spider_id=spider_id)
    fields = []
    for item in unique_fields:
        data = {}
        data['name'] = item.name
        data['selector'] = item.selector
        data['key_in_json'] = item.key_in_json
        data['is_inactive'] = item.is_inactive
        fields.append(data)
    return fields


def get_key_value_of_spiderfield(fields):
    key = []
    value = []
    for item in fields:
        key.append(item['key_in_json'])
        value.append(item['selector'])
    return key, value


def get_spider_with_xpath(id):
    spider = EPS_CrawlerSpider.objects.get(pk=id)
    xpath = EPS_CrawlerSpider.objects.filter(spider_id=id).first()
    if xpath:
        result = {
            "id": spider.id,
            "name": spider.name,
            "domain_url": spider.domain_url,
            "xpath": {
                "id": xpath.id,
                "product_xpath_list_link": xpath.product_xpath_list_link,
                "product_xpath_detail_name": xpath.product_xpath_detail_name,
                "product_xpath_detail_price": xpath.product_xpath_detail_price,
                "product_xpath_detail_category": xpath.product_xpath_detail_category,
                "product_xpath_detail_specification": xpath.product_xpath_detail_specification,
                "product_xpath_detail_description": xpath.product_xpath_detail_description,
                "product_xpath_detail_image_link": xpath.product_xpath_detail_image_link
            }
        }
    else:
        result = {
            "id": spider.id,
            "name": spider.name,
            "domain_url": spider.domain_url,
            "xpath": None
        }
    return result


def insert_spider2(insert_data):
    new_spider = EPS_CrawlerSpider2.objects.create()
    new_spider.name = insert_data['name']
    new_spider.category_name = insert_data['category_name']
    new_spider.category_id = insert_data['category_id']
    new_spider.domain = insert_data['domain']
    new_spider.domain_url = insert_data['domain_url']
    new_spider.home_url = insert_data['home_url']
    new_spider.category_xpath_list_link = insert_data['category_xpath_list_link']
    new_spider.product_url = insert_data['product_url']
    new_spider.product_url_post_data = insert_data['product_url_post_data']
    new_spider.product_url_category_id = insert_data['product_url_category_id']
    new_spider.product_xpath_list_link = insert_data['product_xpath_list_link']
    new_spider.product_xpath_detail_name = insert_data['product_xpath_detail_name']
    new_spider.product_xpath_detail_price = insert_data['product_xpath_detail_price']
    new_spider.product_xpath_detail_category = insert_data['product_xpath_detail_category']
    new_spider.product_xpath_detail_specification = insert_data['product_xpath_detail_specification']
    new_spider.product_xpath_detail_description = insert_data['product_xpath_detail_description']
    new_spider.product_xpath_detail_image_link = insert_data['product_xpath_detail_image_link']

    new_spider.save()
    return new_spider


def update_spider2(id, insert_data):
    spider = EPS_CrawlerSpider2.objects.get(pk=id)
    spider.name = insert_data['name']
    spider.category_name = insert_data['category_name']
    spider.category_id = insert_data['category_id']
    spider.domain = insert_data['domain']
    spider.domain_url = insert_data['domain_url']
    spider.home_url = insert_data['home_url']
    spider.category_xpath_list_link = insert_data['category_xpath_list_link']
    spider.product_url = insert_data['product_url']
    spider.product_url_post_data = insert_data['product_url_post_data']
    spider.product_url_category_id = insert_data['product_url_category_id']
    spider.product_xpath_list_link = insert_data['product_xpath_list_link']
    spider.product_xpath_detail_name = insert_data['product_xpath_detail_name']
    spider.product_xpath_detail_price = insert_data['product_xpath_detail_price']
    spider.product_xpath_detail_category = insert_data['product_xpath_detail_category']
    spider.product_xpath_detail_specification = insert_data['product_xpath_detail_specification']
    spider.product_xpath_detail_description = insert_data['product_xpath_detail_description']
    spider.product_xpath_detail_image_link = insert_data['product_xpath_detail_image_link']
    spider.save()
    return spider


def get_spider2(id):
    return EPS_CrawlerSpider2.objects.get(pk=id)


def get_spider2_with_xpath(id):
    spider = EPS_CrawlerSpider2.objects.get(pk=id)
    xpath = EPS_CrawlerSpider2.objects.filter(spider_id=id).first()
    if xpath:
        result = {
            "id": spider.id,
            "name": spider.name,
            "category_name": spider.category_name,
            "category_id": spider.category_id,
            "domain_url": spider.domain_url,
            "xpath": {
                "id": xpath.id,
                "product_xpath_list_link": xpath.product_xpath_list_link,
                "product_xpath_detail_name": xpath.product_xpath_detail_name,
                "product_xpath_detail_price": xpath.product_xpath_detail_price,
                "product_xpath_detail_category": xpath.product_xpath_detail_category,
                "product_xpath_detail_specification": xpath.product_xpath_detail_specification,
                "product_xpath_detail_description": xpath.product_xpath_detail_description,
                "product_xpath_detail_image_link": xpath.product_xpath_detail_image_link
            }
        }
    else:
        result = {
            "id": spider.id,
            "name": spider.name,
            "domain_url": spider.domain_url,
            "xpath": None
        }
    return result


def insert2(timestamp, pid, spider):
    # do something to insert
    #EPS_CrawlerProcess.objects.all().delete()
    new_process = EPS_CrawlerProcess2.objects.create()
    new_process.timestamp = timestamp
    new_process.pid = pid
    new_process.created_at = datetime.now(tz=timezone.utc)
    new_process.is_running = True
    new_process.spider = spider
    new_process.save()
    return new_process


def stop_process2(timestamp, spider):
    process = EPS_CrawlerProcess2.objects.filter(timestamp=timestamp).first()
    if process is not None:
        process.is_running = False
        process.finished_at = datetime.now(tz=timezone.utc)
        t1=datetime.strptime(str(process.finished_at).split('.')[0], '%Y-%m-%d %H:%M:%S')
        t2=datetime.strptime(str(process.created_at).split('.')[0], '%Y-%m-%d %H:%M:%S')
        process.total_runtime = (t1-t2).total_seconds()
        process.is_running = False
        process.status = spider.status
        process.save()


def xmlfile(product_list,spider):
    items = ET.Element('items')
    i = 0
    attrib = {}
    print(len(product_list))
    for obj in product_list:
        x = 'item' + str(i)
        ele = items.makeelement(x, attrib)
        items.append(ele)
        for key, value in obj.items():
            ET.SubElement(items[i], key).text = value
        i += 1
    tree = ET.ElementTree(items)
    tree.write('uploads/{}.xml'.format(spider.name), encoding='utf8')


def insert_product_crawled(insert_data,spider,category):
    model = Product_Crawled()
    process= EPS_CrawlerProcess.objects.get(id=insert_data['process'])
    model.link = insert_data['link']
    model.title = insert_data['title']
    model.price = insert_data['price']
    model.image_link = insert_data['image_link']
    model.description = insert_data['description']
    model.specification = insert_data['specification']
    model.spider = spider
    model.process = process
    model.category = category
    model.fake_comparing = insert_data['fake_comparing']
    model.created_at = datetime.now()
    model.is_approved = False
    model.save()
    return model



def get_browser():
    if True:
        options = webdriver.ChromeOptions()
        options.add_argument("no-sandbox")
        options.add_argument("--disable-gpu")
        options.add_argument("--window-size=800,600")
        options.add_argument("--disable-dev-shm-usage")
        options.set_headless()
        host = '10.0.0.56'
        browser = webdriver.Remote(
            command_executor="http://10.0.0.56:4444/wd/hub",
            desired_capabilities=DesiredCapabilities.CHROME,
            options=options,
        )
        # driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds( desired_time ));
    return browser

def log_spider(spider, msg):
    # print(msg)
    spider.status += '<br>' + str(msg)
    spider.status = spider.status.replace('<br><br>', '<br>')
    spider.save()
# driver = get_browser()
# driver.set_window_size(1804, 2896)
# driver.maximize_window()
# time.sleep(5)
def check_exits_by_xpath(driver,end_next_page,next_page):
    try:
        end_next_page = driver.find_element_by_xpath(end_next_page)
        next_page = driver.find_elements_by_xpath(next_page)
        if end_next_page.text == next_page[0].text:
            return True
        else:
            return False
    except Exception as e:
        return False


def crawlPage_by_selenium(driver,spider,next_page_url=None,data_crawled=None,i=0):
    try:
        if next_page_url is not None:
            driver.get(next_page_url)
        else:
            driver.get(spider.product_url)
        i +=1
        elements = WebDriverWait(driver, 20).until(
            EC.visibility_of_all_elements_located((By.XPATH, spider.product_xpath_list_link)))
        log_spider(spider,str(len(elements)) + ' /' + 'trang ' +str(i))

        if data_crawled is not None:
            data_crawled = data_crawled
        else:
            data_crawled = []
        for element in elements:
            href = element.get_attribute('href')
            # mo trang chi tiet
            driver.execute_script("window.open('"+href+"');")
            # chuyen trang chi tiet
            driver.switch_to_window(driver.window_handles[1])

            # boc tach
            item ={}
            thong_tin_chung = WebDriverWait(driver, 20).until(
                EC.visibility_of_element_located((By.XPATH, spider.product_xpath_detail_specification)))
            ten_LCNT = WebDriverWait(driver, 20).until(
                EC.visibility_of_element_located((By.XPATH, spider.product_xpath_detail_name)))
            # tham_gia_du_thau = WebDriverWait(driver, 20).until(
            #     EC.visibility_of_element_located((By.XPATH, spider.product_xpath_detail_price)))
            # mo_thau = WebDriverWait(driver, 20).until(
            #     EC.visibility_of_element_located((By.XPATH,spider.product_xpath_detail_specification)))
            # dam_bao_du_thau = WebDriverWait(driver, 20).until(
            #     EC.visibility_of_element_located((By.XPATH, spider.product_xpath_detail_description)))
            item['thong_tin_chung'] = thong_tin_chung.text
            item['ten_LCNT'] = ten_LCNT.text
            # item['tham_gia_du_thau'] = tham_gia_du_thau.text
            # item['mo_thau'] = mo_thau.text
            # item['dam_bao_du_thau'] = dam_bao_du_thau.text
            data_crawled.append(item)
            status = str(spider.status).split('.....')
            if len(status) > 1:
                spider.status = status[0] + status[2]
            log_spider(spider,'.....<font style="color:blue">' + str(item['ten_LCNT']) + '</font>' + '.....')
            defaults = {
                'thong_tin_chung': thong_tin_chung.text,
                'ten_LCNT': ten_LCNT.text
                # 'tham_gia_du_thau': tham_gia_du_thau.text,
                # 'mo_thau': mo_thau.text,
                # 'dam_bao_du_thau': dam_bao_du_thau.text,
            }
            model = DauThau.objects.update_or_create(
                thong_tin_chung=thong_tin_chung.text,
                # tham_gia_du_thau=tham_gia_du_thau.text,
                # mo_thau=mo_thau.text,
                # dam_bao_du_thau=dam_bao_du_thau.text,
                defaults=defaults
            )
            # model.thong_tin_chung = thong_tin_chung.text
            # model.tham_gia_du_thau = tham_gia_du_thau.text
            # model.mo_thau = mo_thau.text
            # model.dam_bao_du_thau = dam_bao_du_thau.text
            # model.save()

            driver.close()
            # ve trang chu
            driver.switch_to_window(driver.window_handles[0])
        next_page = spider.xpath_next_page
        end_next_page = spider.xpath_end_next_page
        is_exisited = check_exits_by_xpath(driver, end_next_page,next_page)
        if is_exisited ==True:
            driver.quit()
            spider.status += '<br><u>Kết thúc CRAWL lúc ' + datetime.now().strftime(
                '%d/%m/%Y %H:%M:%S') + '</u>'
            spider.status = spider.status.replace('<br><br>', '<br>')
            spider.is_finished = True
            spider.save()
            return data_crawled
        else:
            next_page = WebDriverWait(driver, 20).until(
            EC.visibility_of_all_elements_located((By.XPATH, next_page)))
            next_page_url = next_page[0].get_attribute('href')
            # driver.execute_script("window.open('"+next_page_url+"');")
            # driver.switch_to_window(driver.window_handles[1])
            # mo trang tiep theo
            crawlPage_by_selenium(driver,spider,next_page_url,data_crawled,i)

    except Exception as e:
        print(e)
        log_spider(spider,"Error: {error}".format(error=e))
        return "Error: {error}".format(error=e)