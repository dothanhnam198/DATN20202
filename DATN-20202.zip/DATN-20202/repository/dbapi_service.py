import django

django.setup()
from .models import *
import datetime
import json
import codecs
from common.api_utils import *
from common.db_utils import *

def insert(name, start_urls):
    new_spider = EPS_DBAPIConfig.objects.create()
    new_spider.name = name
    new_spider.start_urls = start_urls
    new_spider.save()
    return new_spider


def update(id, name, start_urls):
    spider = EPS_DBAPIConfig.objects.get(pk=id)
    spider.name = name
    spider.start_urls = start_urls
    spider.save()
    return spider


def get(id):
    return EPS_DBAPIConfig.objects.get(pk=id)


def update_product(products, spider):
    try:
        #replace gia tri cac thuoc tinh =, vi du: obj={'abc':'?'}, findall(obj, '?', 'xyz')
        def findall(v, k, z):
            if type(v) == type({}):
                for k1 in v:
                    if v[k1] == k:
                        v[k1] = z
                    v[k1] = findall(v[k1], k, z)
            return v

        spider.status += '<br><u>Bắt đầu UPDATE DB lúc ' + datetime.datetime.now().strftime('%d/%m/%Y %H:%M:%S') + '</u>'
        spider.status = spider.status.replace('<br><br>', '<br>')
        spider.save()

        dbapi_config = EPS_DBAPIConfig.objects.all().first()
        if dbapi_config.name_db:
            if dbapi_config.type_db == 1: #Oracle
                db = OracleUtils()
                db.open(dbapi_config.ip, dbapi_config.port, dbapi_config.name_db, dbapi_config.username_db, dbapi_config.password_db)

                #create table
                db.execute(
                    "create table CRAWL_PRODUCTS (id int, title nvarchar(500), price nvarchar(100), category nvarchar(100), specification nvarchar(MAX), description nvarchar(MAX), image_link nvarchar(500), link nvarchar(500), create_date datetime)")
                for product in products:
                    db.execute(
                        "insert into CRAWL_PRODUCTS values ((select MAX(id) from CRAWL_PRODUCTS)+1, '%s', '%s', '%s', '%s', '%s', '%s', '%s', getdate())" % (
                            product['title'],
                            product['price'],
                            product['category'],
                            product['specification'],
                            product['description'],
                            product['image_link'],
                            product['link']
                        ))

                    status = str(spider.status).split('.....')
                    if len(status) > 1:
                        spider.status = status[0] + status[2]
                    spider.status += '<br>' + str(
                        '.....<font style="color:blue">DB/API: ' + str(product['title']) + '</font>' + '.....')
                    spider.status = spider.status.replace('<br><br>', '<br>')
                    spider.save()

                db.close()

            if dbapi_config.type_db == 2:  # Postgres
                db = PostgresUtils()
                db.open(dbapi_config.ip, dbapi_config.port, dbapi_config.name_db, dbapi_config.username_db,
                        dbapi_config.password_db)

                #create table
                db.execute(
                    "create table CRAWL_PRODUCTS (id int, title nvarchar(500), price nvarchar(100), category nvarchar(100), specification nvarchar(MAX), description nvarchar(MAX), image_link nvarchar(500), link nvarchar(500), create_date datetime)")
                for product in products:
                    db.execute(
                        "insert into CRAWL_PRODUCTS values ((select MAX(id) from CRAWL_PRODUCTS)+1, '%s', '%s', '%s', '%s', '%s', '%s', '%s', getdate())" % (
                            product['title'],
                            product['price'],
                            product['category'],
                            product['specification'],
                            product['description'],
                            product['image_link'],
                            product['link']
                        ))

                    status = str(spider.status).split('.....')
                    if len(status) > 1:
                        spider.status = status[0] + status[2]
                    spider.status += '<br>' + str(
                        '<font style="color:blue">DB/API: ' + str(product['title']) + '</font>')
                    spider.status = spider.status.replace('<br><br>', '<br>')
                    spider.save()

                db.close()

            # elif int(dbapi_config.type_db) == 3:  # SQLSERVER
            #     db = SQLServerUtils()
            #     db.open(dbapi_config.ip, dbapi_config.port, dbapi_config.name_db, dbapi_config.username_db,
            #             dbapi_config.password_db)
            #
            #     #create table
            #     # db.execute(
            #     #     "create table CRAWL_PRODUCTS (id int, title nvarchar(500), price nvarchar(100), category nvarchar(100), specification nvarchar(MAX), description nvarchar(MAX), image_link nvarchar(500), link nvarchar(500), create_date datetime)")
            #     for product in products:
            #         db.execute(
            #             "insert into INTE_HANG_HOA_SAN_PHAM_2 values ((SELECT MAX(ID)+1FROM INTE_HANG_HOA_SAN_PHAM_2), N'%s',N'%s',N'%s',N'%s',N'%s',0,getdate())"
            #             % (product['title'],
            #                product['price'],
            #                product['category'],
            #                product['specification'],
            #                product['link'],
            #                ))
            #         print('work')
            #         status = str(spider.status).split('.....')
            #         if len(status) > 1:
            #             spider.status = status[0] + status[2]
            #         spider.status += '<br>' + str(
            #             '<font style="color:blue">DB/API: ' + str(product['title']) + '</font>')
            #         spider.status = spider.status.replace('<br><br>', '<br>')
            #         spider.save()
            #
            #     db.close()

        if dbapi_config.url:
            if dbapi_config.url_signin:
                api = APIUtil()
                result_login = api.loginAPI(dbapi_config.url_signin, dbapi_config.username_api, dbapi_config.password_api)
                # login api khong thanh cong se ket thuc updateDB
                if not result_login == '':
                    raise Exception("login api failed")
                spider.status += '<br>' + str('<font style="color:red">DB/API: ' + str(result_login) + '</font>')
                spider.status = spider.status.replace('<br><br>', '<br>')
                spider.save()
                for product in products:
                    try:
                        post_data = dbapi_config.post_data.replace('?', json.dumps(product))
                        post_data = json.loads(post_data) # ? / {'abc': ?} => 
                        print(post_data)
                        result_post = api.postAPI(dbapi_config.url, post_data)
                        # post api khong thanh cong se ket thuc updatedb
                        if not result_post == '' :
                            raise Exception('post api failed')
                        # spider.status += '<br>' + str('<font style="color:red">DB/API: ' + str(result_post) + '</font>')
                        # spider.status = spider.status.replace('<br><br>', '<br>')
                        # spider.save()
                        status = str(spider.status).split('.....')
                        if len(status) > 1:
                            spider.status = status[0] + status[2]
                        spider.status += '<br>' + str(
                            '.....<font style="color:blue">DB/API: ' + str(product['title']) + '</font>' + '.....')
                        spider.status = spider.status.replace('<br><br>', '<br>')
                        spider.save()
                    except Exception:
                        import traceback
                        spider.status += '<br>' + str('.....' + str(Exception) + '' + '.....')
                        break


        spider.status += '<br><u>Kết thúc UPDATE DB lúc ' + datetime.datetime.now().strftime('%d/%m/%Y %H:%M:%S') + '</u>'
        spider.status = spider.status.replace('<br><br>', '<br>')
        spider.save()
    except Exception:
        import traceback
        spider.status += '<br><u>Kết thúc UPDATE DB lúc ' + datetime.datetime.now().strftime(
            '%d/%m/%Y %H:%M:%S') + '</u>'
        spider.status = spider.status.replace('<br><br>', '<br>')
        spider.save()
        print('<font style="color:red">ERROR trong DBAPI.update_product')
        print(str(traceback.format_exc()) + '</font>')


def get_dienthoai(id):
    return DienThoai.objects.get(pk=id)


def insert_dienthoai(info):
    new_pattern = DienThoai()
    new_pattern.ten = info['ten']
    new_pattern.link = info['link']
    new_pattern.he_dieu_hanh = info['he_dieu_hanh']
    new_pattern.loai_man_hinh = info['loai_man_hinh']
    new_pattern.ram = info['ram']
    new_pattern.nhan_hieu = info['nhan_hieu']
    new_pattern.khuyen_mai = info['khuyen_mai']
    new_pattern.xuat_xu = info['xuat_xu']
    new_pattern.mo_ta = info['mo_ta']
    new_pattern.bao_hanh = info['bao_hanh']
    new_pattern.nam_san_xuat = info['nam_san_xuat']
    new_pattern.model = info['model']
    new_pattern.muc_gia = info['muc_gia']
    new_pattern.anh = info['anh']
    new_pattern.save()
    return new_pattern


def update_dienthoai(id, info):
    pattern = DienThoai.objects.get(pk=id)
    pattern.ten = info['ten']
    pattern.link = info['link']
    pattern.he_dieu_hanh = info['he_dieu_hanh']
    pattern.loai_man_hinh = info['loai_man_hinh']
    pattern.ram = info['ram']
    pattern.nhan_hieu = info['nhan_hieu']
    pattern.khuyen_mai = info['khuyen_mai']
    pattern.xuat_xu = info['xuat_xu']
    pattern.mo_ta = info['mo_ta']
    pattern.bao_hanh = info['bao_hanh']
    pattern.nam_san_xuat = info['nam_san_xuat']
    pattern.model = info['model']
    pattern.muc_gia = info['muc_gia']
    pattern.anh = info['anh']
    pattern.save()
    return pattern


def get_tivi(id):
    return Tivi.objects.get(pk=id)


def insert_tivi(info):
    new_pattern = Tivi()
    new_pattern.ten = info['ten']
    new_pattern.link = info['link']
    new_pattern.he_dieu_hanh = info['he_dieu_hanh']
    new_pattern.loai_man_hinh = info['loai_man_hinh']
    new_pattern.do_phan_giai = info['do_phan_giai']
    new_pattern.kich_co_man_hinh = info['kich_co_man_hinh']
    new_pattern.cong_nghe_am_thanh = info['cong_nghe_am_thanh']
    new_pattern.cong_nghe_hinh_anh = info['do_phan_giai']
    new_pattern.nhan_hieu = info['nhan_hieu']
    new_pattern.khuyen_mai = info['khuyen_mai']
    new_pattern.xuat_xu = info['xuat_xu']
    new_pattern.mo_ta = info['mo_ta']
    new_pattern.bao_hanh = info['bao_hanh']
    new_pattern.nam_san_xuat = info['nam_san_xuat']
    new_pattern.model = info['model']
    new_pattern.muc_gia = info['muc_gia']
    new_pattern.anh = info['anh']
    new_pattern.save()
    return new_pattern


def update_tivi(id, info):
    new_pattern = Tivi.objects.get(pk=id)
    new_pattern.ten = info['ten']
    new_pattern.link = info['link']
    new_pattern.he_dieu_hanh = info['he_dieu_hanh']
    new_pattern.loai_man_hinh = info['loai_man_hinh']
    new_pattern.do_phan_giai = info['do_phan_giai']
    new_pattern.kich_co_man_hinh = info['kich_co_man_hinh']
    new_pattern.cong_nghe_am_thanh = info['cong_nghe_am_thanh']
    new_pattern.cong_nghe_hinh_anh = info['do_phan_giai']
    new_pattern.nhan_hieu = info['nhan_hieu']
    new_pattern.khuyen_mai = info['khuyen_mai']
    new_pattern.xuat_xu = info['xuat_xu']
    new_pattern.mo_ta = info['mo_ta']
    new_pattern.bao_hanh = info['bao_hanh']
    new_pattern.nam_san_xuat = info['nam_san_xuat']
    new_pattern.model = info['model']
    new_pattern.muc_gia = info['muc_gia']
    new_pattern.anh = info['anh']
    new_pattern.save()
    return new_pattern


def get_tulanh(id):
    return Tulanh.objects.get(pk=id)


def insert_tulanh(info):
    new_pattern = Tulanh()
    new_pattern.ten = info['ten']
    new_pattern.link = info['link']
    new_pattern.dung_tich = info['dung_tich']
    new_pattern.cong_nghe = info['cong_nghe']
    new_pattern.Inverter = info['Inverter']
    new_pattern.nhan_hieu = info['nhan_hieu']
    new_pattern.khuyen_mai = info['khuyen_mai']
    new_pattern.xuat_xu = info['xuat_xu']
    new_pattern.mo_ta = info['mo_ta']
    new_pattern.bao_hanh = info['bao_hanh']
    new_pattern.nam_san_xuat = info['nam_san_xuat']
    new_pattern.model = info['model']
    new_pattern.muc_gia = info['muc_gia']
    new_pattern.anh = info['anh']
    new_pattern.save()
    return new_pattern


def update_tulanh(id, info):
    new_pattern = Tulanh.objects.get(pk=id)
    new_pattern.ten = info['ten']
    new_pattern.link = info['link']
    new_pattern.dung_tich = info['dung_tich']
    new_pattern.cong_nghe = info['cong_nghe']
    new_pattern.Inverter = info['Inverter']
    new_pattern.nhan_hieu = info['nhan_hieu']
    new_pattern.khuyen_mai = info['khuyen_mai']
    new_pattern.xuat_xu = info['xuat_xu']
    new_pattern.mo_ta = info['mo_ta']
    new_pattern.bao_hanh = info['bao_hanh']
    new_pattern.nam_san_xuat = info['nam_san_xuat']
    new_pattern.model = info['model']
    new_pattern.muc_gia = info['muc_gia']
    new_pattern.anh = info['anh']
    new_pattern.save()
    return new_pattern


def get_chungcu(id):
    return Chung_cu.objects.get(pk=id)


def insert_chungcu(info):
    new_pattern = Chung_cu()
    new_pattern.link = info['link']
    new_pattern.du_an = info['du_an']
    new_pattern.huong_cua_chinh = info['huong_cua_chinh']
    new_pattern.huong_ban_cong = info['huong_ban_cong']
    new_pattern.tang = info['tang']
    new_pattern.gia_dich_vu = info['gia_dich_vu']
    new_pattern.so_phong_ngu = info['so_phong_ngu']
    new_pattern.so_WC = info['so_WC']
    new_pattern.thanh_pho = info['thanh_pho']
    new_pattern.quan = info['quan']
    new_pattern.xa_phuong = info['xa_phuong']
    new_pattern.duong_pho = info['duong_pho']
    new_pattern.dia_chi = info['dia_chi']
    new_pattern.muc_gia = info['muc_gia']
    new_pattern.don_vi_tinh_gia = info['don_vi_tinh_gia']
    new_pattern.dien_tich = info['dien_tich']
    new_pattern.chieu_dai = info['chieu_dai']
    new_pattern.chieu_rong = info['chieu_rong']
    new_pattern.hinh_anh = info['hinh_anh']
    new_pattern.mo_ta = info['mo_ta']
    new_pattern.giay_to_phap_ly = info['giay_to_phap_ly']
    new_pattern.noi_that = info['noi_that']
    new_pattern.ngay_dang = info['ngay_dang']
    new_pattern.loai_gia = info['loai_gia']
    new_pattern.tinh_trang = info['tinh_trang']
    new_pattern.tien_coc = info['tien_coc']
    new_pattern.save()
    return new_pattern


def update_chungcu(id, info):
    new_pattern = Chung_cu.objects.get(pk=id)
    new_pattern.link = info['link']
    new_pattern.du_an = info['du_an']
    new_pattern.huong_cua_chinh = info['huong_cua_chinh']
    new_pattern.huong_ban_cong = info['huong_ban_cong']
    new_pattern.tang = info['tang']
    new_pattern.gia_dich_vu = info['gia_dich_vu']
    new_pattern.so_phong_ngu = info['so_phong_ngu']
    new_pattern.so_WC = info['so_WC']
    new_pattern.thanh_pho = info['thanh_pho']
    new_pattern.quan = info['quan']
    new_pattern.xa_phuong = info['xa_phuong']
    new_pattern.duong_pho = info['duong_pho']
    new_pattern.dia_chi = info['dia_chi']
    new_pattern.muc_gia = info['muc_gia']
    new_pattern.don_vi_tinh_gia = info['don_vi_tinh_gia']
    new_pattern.dien_tich = info['dien_tich']
    new_pattern.chieu_dai = info['chieu_dai']
    new_pattern.chieu_rong = info['chieu_rong']
    new_pattern.hinh_anh = info['hinh_anh']
    new_pattern.mo_ta = info['mo_ta']
    new_pattern.giay_to_phap_ly = info['giay_to_phap_ly']
    new_pattern.noi_that = info['noi_that']
    new_pattern.ngay_dang = info['ngay_dang']
    new_pattern.loai_gia = info['loai_gia']
    new_pattern.tinh_trang = info['tinh_trang']
    new_pattern.tien_coc = info['tien_coc']
    new_pattern.save()
    return new_pattern


def get_nharieng(id):
    return Nha_rieng.objects.get(pk=id)


def insert_nharieng(info):
    new_pattern = Nha_rieng()
    new_pattern.link = info['link']
    new_pattern.so_tang = info['so_tang']
    new_pattern.mat_tien = info['mat_tien']
    new_pattern.duong_o_to = info['duong_o_to']
    new_pattern.huong_nha = info['huong_nha']
    new_pattern.so_phong_ngu = info['so_phong_ngu']
    new_pattern.so_WC = info['so_WC']
    new_pattern.thanh_pho = info['thanh_pho']
    new_pattern.quan = info['quan']
    new_pattern.xa_phuong = info['xa_phuong']
    new_pattern.duong_pho = info['duong_pho']
    new_pattern.dia_chi = info['dia_chi']
    new_pattern.muc_gia = info['muc_gia']
    new_pattern.don_vi_tinh_gia = info['don_vi_tinh_gia']
    new_pattern.dien_tich = info['dien_tich']
    new_pattern.chieu_dai = info['chieu_dai']
    new_pattern.chieu_rong = info['chieu_rong']
    new_pattern.hinh_anh = info['hinh_anh']
    new_pattern.mo_ta = info['mo_ta']
    new_pattern.giay_to_phap_ly = info['giay_to_phap_ly']
    new_pattern.noi_that = info['noi_that']
    new_pattern.ngay_dang = info['ngay_dang']
    new_pattern.loai_gia = info['loai_gia']
    new_pattern.tinh_trang = info['tinh_trang']
    new_pattern.tien_coc = info['tien_coc']
    new_pattern.save()
    return new_pattern


def update_nharieng(id, info):
    new_pattern = Nha_rieng.objects.get(pk=id)
    new_pattern.link = info['link']
    new_pattern.so_tang = info['so_tang']
    new_pattern.mat_tien = info['mat_tien']
    new_pattern.duong_o_to = info['duong_o_to']
    new_pattern.huong_nha = info['huong_nha']
    new_pattern.so_phong_ngu = info['so_phong_ngu']
    new_pattern.so_WC = info['so_WC']
    new_pattern.thanh_pho = info['thanh_pho']
    new_pattern.quan = info['quan']
    new_pattern.xa_phuong = info['xa_phuong']
    new_pattern.duong_pho = info['duong_pho']
    new_pattern.dia_chi = info['dia_chi']
    new_pattern.muc_gia = info['muc_gia']
    new_pattern.don_vi_tinh_gia = info['don_vi_tinh_gia']
    new_pattern.dien_tich = info['dien_tich']
    new_pattern.chieu_dai = info['chieu_dai']
    new_pattern.chieu_rong = info['chieu_rong']
    new_pattern.hinh_anh = info['hinh_anh']
    new_pattern.mo_ta = info['mo_ta']
    new_pattern.giay_to_phap_ly = info['giay_to_phap_ly']
    new_pattern.noi_that = info['noi_that']
    new_pattern.ngay_dang = info['ngay_dang']
    new_pattern.loai_gia = info['loai_gia']
    new_pattern.tinh_trang = info['tinh_trang']
    new_pattern.tien_coc = info['tien_coc']
    new_pattern.save()
    return new_pattern