
from django.db import models
from django.utils.encoding import smart_text as smart_unicode
from django.utils.translation import ugettext_lazy as _
from django.db.models.signals import pre_save,post_save
from django_celery_beat.models import PeriodicTask,CrontabSchedule
from django.dispatch import receiver
from json import JSONEncoder
import json

from datetime import datetime

# Create your models here.

DAY_OF_WEEK_CHOICES = [
        ('1', 'Monday'),
        ('2', 'Tuesday'),
        ('3', 'Wednesday'),
        ('4', 'Thursday'),
        ('5', 'Friday'),
        ('6', 'Saturday'),
        ('0', 'Sunday'),
        ('7', 'Every Day')
]
    # WEB_TYPE = {
    #     ('0', 'Bất động sản'),
    #     ('1', 'Mặt hàng khác')
    # }
STATUS = [
        ('0', 'Khởi tạo'),
        ('1', 'Đang thu thập'),
        ('2', 'Hoàn Thành'),
        ('3', 'Lỗi'),
]

class EPS_CrawlerSpider(models.Model):

    # AUTO = {
    #     ('1', 'Chạy tự động theo nhóm'),
    #     ('0', 'Chạy độc lập')
    # }

    name = models.CharField(max_length=1000, blank=True, null=True, verbose_name=_("Tên Spider"))
    domain = models.CharField(max_length=100, blank=True, null=True, verbose_name=_("Tên domain (vd: www.btc.vn)"))
    domain_url = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("URL domain (vd: https://www.btc.vn/)"))
    home_url = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("không sử dụng nữa"))
    category_xpath_list_link = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("không sử dụng nữa"))
    product_url = models.CharField(max_length=1000, blank=True, null=True, verbose_name=_("URLs danh sách sản phẩm (1-n, xuống dòng)"))
    product_url_post_data = models.CharField(max_length=1000, blank=True, null=True, verbose_name=_("không sử dụng nữa"))
    product_url_category_id = models.CharField(max_length=1000, blank=True, null=True, verbose_name=_("không sử dụng nữa"))
    product_xpath_list_link = models.CharField(max_length=1000, blank=True, null=True, verbose_name=_("XPath tìm URL chi tiết sp từ danh sách sản phẩm"))
    product_xpath_detail_name = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("XPath tìm tên sản phẩm trong trang chi tiết (vd: a/h3/text())"))
    product_xpath_detail_price = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("XPath tìm giá tiền sản phẩm (vd: a/div[@class=\"price\"]/strong/text())"))
    product_xpath_detail_category = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("XPath tìm tên loại sản phẩm (vd: .breadcum/a(1)/h3/text())"))
    product_xpath_detail_specification = models.CharField(max_length=1000, blank=True, null=True, verbose_name=_("XPath tìm thông số kỹ thuật sản phẩm (1-n, xuống dòng)"))
    product_xpath_detail_description = models.CharField(max_length=1000, blank=True, null=True, verbose_name=_("XPath tìm mô tả sản phẩm (1-n, xuống dòng)"))
    product_xpath_detail_image_link = models.CharField(max_length=1000, blank=True, null=True, verbose_name=_("XPath tìm URL ảnh sản phẩm (vd: img/@src)"))
    # splash
    interacting_page = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("không sử dụng nữa"))
    timeout_splash = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("không sử dụng nữa"))
    splash_request = models.BooleanField(default=False, verbose_name=_("không sử dụng nữa"))
    rendering_script = models.TextField( blank=True, null=True, verbose_name=_("không sử dụng nữa"))
    # end splash
    # selenium
    selenium_request = models.BooleanField(default=False, verbose_name=_("Có sử dụng selenium"))
    xpath_next_page = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("XPath tìm nút sang trang")
                                       )
    xpath_end_next_page = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("XPath tìm nút kết thúc phân trang nếu có")
                                           )
    load_more_button = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("XPath tìm nút tải thêm ")
                                       )
    # end selenium
    is_deactive = models.BooleanField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    pid = models.CharField(max_length=100, blank=True, null=True)
    is_finished = models.CharField(max_length=2,choices=STATUS , default='0')
    status = models.TextField(blank=True, null=True)
    day_of_week = models.CharField(max_length=2, choices=DAY_OF_WEEK_CHOICES, default='1')
    hour = models.IntegerField(default=0, blank=True, null=True)
    minute = models.IntegerField(default=0, blank=True, null=True)
    # web_type = models.CharField(max_length=2, choices=WEB_TYPE, default='1')
    task = models.OneToOneField(PeriodicTask, on_delete=models.CASCADE, null=True, blank=True)
    # is_approved = models.CharField(max_length=2, choices=AUTO, default='1')

    def edit_task(self):
        crontab = CrontabSchedule.objects.get(id=self.task.crontab_id)
        crontab.minute = self.minute
        crontab.hour = self.hour
        if int(self.day_of_week) == 7:
            crontab.day_of_week = '*'
        crontab.day_of_week = self.day_of_week
        crontab.timezone = "Asia/Ho_Chi_Minh"
        crontab.save()

    def setup_task(self):
        crontab = CrontabSchedule()
        crontab.minute = self.minute
        crontab.hour = self.hour
        if int(self.day_of_week) == 7:
            crontab.day_of_week = '*'
        crontab.day_of_week = self.day_of_week
        crontab.timezone = "Asia/Ho_Chi_Minh"
        crontab.save()
        self.task = PeriodicTask.objects.create(
            name=self.name,
            task='crawl_web',
            crontab_id=crontab.id,
            args=json.dumps([self.id]),
        )
        self.save()

    def delete(self, *args, **kwargs):
        if self.task is not None:
            self.task.delete()
        return super(self.__class__, self).delete(*args, **kwargs)

    def __str__(self):
        if self.name is None:
            return ""
        else:
            return self.name

    class Meta:
        verbose_name = verbose_name_plural = _('Danh sách SPIDER')
        ordering = ['name', 'id']

@receiver(post_save,sender=EPS_CrawlerSpider)
def create_or_update_periodic_task(sender,instance,created,**kwargs):

    if created:
        instance.setup_task()
    else:
        if instance.task is not None:
            instance.task.enabled = instance.is_deactive
            instance.edit_task()


class EPS_CrawlerProcess(models.Model):
    timestamp = models.CharField(max_length=100, blank=True, null=True, verbose_name=_("Thời gian chạy"))
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True, verbose_name=_("Ngày chạy"))
    finished_at = models.DateTimeField(blank=True, null=True, verbose_name=_("Ngày kết thúc"))
    total_runtime = models.IntegerField(default=0, blank=True, null=True, verbose_name=_("Tổng thời gian chạy"))
    pid = models.CharField(max_length=100, blank=True, null=True, verbose_name=_("Process ID"))
    is_running = models.BooleanField(default=True, verbose_name=_("Spider đang chạy"))
    status = models.TextField(blank=True, null=True, verbose_name=_("Trạng thái"))
    spider = models.ForeignKey('EPS_CrawlerSpider', on_delete=models.CASCADE, blank=True, null=True, verbose_name=_("Spider chạy"))

    def __str__(self):
        if self.created_at is None:
            return ""
        else:
            return self.created_at.strftime('%d/%m/%Y')
    class Meta:
        verbose_name = verbose_name_plural = _('Lịch sử chạy Spider')
        ordering = ['-created_at']

class EPS_CrawlerProcess2(models.Model):
    timestamp = models.CharField(max_length=100, blank=True, null=True, verbose_name=_("Thời gian chạy"))
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True, verbose_name=_("Ngày chạy"))
    finished_at = models.DateTimeField(blank=True, null=True, verbose_name=_("Ngày kết thúc"))
    total_runtime = models.IntegerField(default=0, blank=True, null=True, verbose_name=_("Tổng thời gian chạy"))
    pid = models.CharField(max_length=100, blank=True, null=True, verbose_name=_("Process ID"))
    is_running = models.BooleanField(default=True, verbose_name=_("Spider đang chạy"))
    status = models.TextField(blank=True, null=True, verbose_name=_("Trạng thái"))
    spider = models.ForeignKey('EPS_CrawlerSpider2', on_delete=models.CASCADE, blank=True, null=True, verbose_name=_("Spider chạy"))

    def __str__(self):
        if self.created_at is None:
            return ""
        else:
            return self.created_at.strftime('%d/%m/%Y')
    class Meta:
        verbose_name = verbose_name_plural = _('Lịch sử chạy Spider2')
        ordering = ['-created_at']


class EPS_CrawlerConfig(models.Model):
    # DOWNLOAD_DELAY = 3
    delay_time = models.DecimalField(max_digits=5, decimal_places=2, default=0, blank=True, null=True, verbose_name=_("Độ trễ giữa các lần request"))
    # Configure maximum concurrent requests performed by Scrapy (default: 16)
    # CONCURRENT_REQUESTS = 32
    concurrent_request = models.IntegerField(default=32, blank=True, null=True, verbose_name=_("Số request đồng thời"))
    # The download delay setting will honor only one of:
    # CONCURRENT_REQUESTS_PER_DOMAIN = 16
    # CONCURRENT_REQUESTS_PER_IP = 16
    concurrent_request_per_domain = models.IntegerField(default=16, blank=True, null=True, verbose_name=_("Số request đồng thời theo DOMAIN"))
    concurrent_request_per_ip = models.IntegerField(default=16, blank=True, null=True, verbose_name=_("Số request đồng thời theo IP"))
    user_agent = models.TextField(blank=True, null=True, verbose_name=_("Danh sách USER_AGENT"))
    proxy_ip = models.TextField(blank=True, null=True, verbose_name=_("Danh sách PROXY IP "))
    request_header = models.TextField(blank=True, null=True, verbose_name=_("JSON request header"))
    is_bypassAI = models.BooleanField(default=False, verbose_name=_("Bỏ qua AI phân loại"))

    def __str__(self):
        if self.delay_time is None:
            return ""
        else:
            return str(self.delay_time)
    class Meta:
        verbose_name = verbose_name_plural = _('Cấu hình CRAWLER')


class EPS_DBAPIConfig(models.Model):
    type_db = models.CharField(max_length=255, blank=True, null=True, verbose_name=_("Loại DB (vd: Oracle, MSSQL, Postgres...)"))
    ip = models.GenericIPAddressField(blank=True, null=True, verbose_name=_("IP máy chủ DB"))
    port = models.IntegerField(blank=True, null=True, verbose_name=_("Cổng máy chủ DB"))
    name_db = models.CharField(max_length=255, blank=True, null=True, verbose_name=_("Tên DB"))
    username_db = models.CharField(max_length=255, blank=True, null=True, verbose_name=_("Tên username DB"))
    password_db = models.CharField(max_length=50, blank=True, null=True, verbose_name=_("Mật khẩu password DB"))

    url_signin = models.URLField(max_length=500, blank=True, null=True, verbose_name=_("URL đăng nhập API"))
    username_api = models.CharField(max_length=255, blank=True, null=True, verbose_name=_("Tên username API"))
    password_api = models.CharField(max_length=50, blank=True, null=True, verbose_name=_("Mật khẩu password API"))
    url = models.URLField(max_length=500, blank=True, null=True, verbose_name=_("URL cập nhật sản phẩm"))
    post_data = models.TextField(default="?", blank=True, null=True, verbose_name=_("Dữ liệu POST (dấu ? thay thế bới JSON sản phẩm)"))

    def __str__(self):
        if self.name_db is None and self.url is None:
            return ''
        else:
            return self.name_db + ' / ' + self.url
    class Meta:
        verbose_name = verbose_name_plural = _('Cấu hình cập nhật DB, API')


def upload_location(instance, filename):
	file_path = '{filename}.png'.format(
				filename=filename)
	return file_path


class EPS_AIModel(models.Model):
    name = models.CharField(max_length=255, blank=True, null=True, verbose_name=_("Tên Model"))
    filename = models.CharField(max_length=255, blank=True, null=True, verbose_name=_("Tên file Model"))
    result = models.CharField(max_length=3000, blank=True, null=True, verbose_name=_("Kết quả train"))
    image_plot = models.ImageField(upload_to=upload_location, null=True, blank=True)
    is_deactive = models.BooleanField(blank=True, null=True,  verbose_name=_("Model không hoạt động"))
    updated_at = models.DateTimeField(blank=True, null=True,  verbose_name=_("Ngày train"))

    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True,  verbose_name=_("Ngày tạo"))

    def __str__(self):
        if self.name is None:
            return ''
        else:
            return self.name
    class Meta:
        verbose_name = verbose_name_plural = _('Danh sách AI MODEL')
        ordering = ['-updated_at']


# def pre_save_ai_model_receiver(sender, instance, *args, **kwargs):
# 	if instance.image_plot is None:
# 		instance.image_plot = instance.name + ".png"


# pre_save.connect(pre_save_ai_model_receiver, sender=EPS_AIModel)


class EPS_AIConfig(models.Model):
    modelAI = models.ForeignKey('EPS_AIModel', on_delete=models.CASCADE, verbose_name=_("Tên model AI"))
    stopwords = models.TextField(verbose_name=_("Danh sách stopwords"))
    specification_characters = models.CharField(default='0123456789%@$.,=+-!;/()*"&^:#|\n\t\'', max_length=255, verbose_name=_("Danh sách ký tự đặc biệt"))
    dictination_json = models.TextField(verbose_name=_("Danh sách JSON từ điển AI tiếng Việt"))

    def __str__(self):
        if self.modelAI is None:
            return ''
        else:
            return self.modelAI.name
    class Meta:
        verbose_name = verbose_name_plural = _('Cấu hình AI phân loại sản phẩm')


class EPS_AITrain(models.Model):
    is_test_data = models.BooleanField(null=False, verbose_name=_("Là dữ liệu TEST"))
    category_name = models.ForeignKey('EPS_Category', on_delete=models.CASCADE, verbose_name=_("Tên danh mục sản phẩm"),default=1)
    content_train = models.TextField(blank=True, null=True, verbose_name=_("Nội dung sản phẩm mẫu"))
    url = models.URLField(max_length=500, blank=True, null=True, verbose_name=_("URL nguồn gốc"))

    is_trained = models.BooleanField(null=False, verbose_name=_("Đã trained"))
    is_deactive = models.BooleanField(blank=True, null=True, verbose_name=_("Không hoạt động"))

    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True, verbose_name=_("Ngày tạo"))
    updated_at = models.DateTimeField(blank=True, null=True, verbose_name=_("Ngày cập nhật"))

    def __str__(self):
        if self.category_name is None:
            return ''
        else:
            return self.category_name


    class Meta:
        verbose_name = verbose_name_plural = _('Danh sách dữ liệu mẫu')
        ordering = ['-created_at']

class EPS_Category(models.Model):
    category_name = models.CharField(max_length=255, blank=True, null=True, verbose_name=_("Tên Loại sản phẩm"))

    def __str__(self):
        if self.category_name is None:
            return ''
        else:
            return self.category_name
    class Meta:
        verbose_name = verbose_name_plural = _('Danh mục sản phẩm')

class EPS_CrawlerSpider2(models.Model):
    name = models.CharField(max_length=1000, blank=True, null=True, verbose_name=_("Tên Spider"))
    category_name = models.ForeignKey('EPS_Category', on_delete=models.CASCADE, verbose_name=_("Tên danh mục sản phẩm"),default=1)
    domain = models.CharField(max_length=100, blank=True, null=True, verbose_name=_("Tên domain (vd: www.btc.vn)"))
    domain_url = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("URL domain (vd: https://www.btc.vn/)"))

    home_url = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("URL trang chủ, tìm các url danh mục loại sp"))
    category_xpath_list_link = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("XPath tìm URL danh sách sp theo danh mục loại sp (vd: ul.homeproduct/li/a/@href)"))

    product_url = models.TextField(blank=True, null=True, verbose_name=_("URLs danh sách sản phẩm (1-n, xuống dòng)"))
    product_url_post_data = models.TextField(blank=True, null=True, verbose_name=_("Dữ liệu POST DATA theo URL sp (vd: 'pagesize':'30', 'catid':'?')"))
    product_url_category_id = models.TextField(blank=True, null=True, verbose_name=_("ID danh mục loại sp thay vào ? trong POST DATA (1-n, xuống dòng)"))
    product_xpath_list_link = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("XPath tìm URL chi tiết sp từ danh sách sản phẩm"))

    product_xpath_detail_name = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("XPath tìm tên sản phẩm trong trang chi tiết (vd: a/h3/text())"))
    product_xpath_detail_price = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("XPath tìm giá tiền sản phẩm (vd: a/div[@class=\"price\"]/strong/text())"))
    product_xpath_detail_category = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("XPath tìm tên loại sản phẩm (vd: .breadcum/a(1)/h3/text())"))
    product_xpath_detail_specification = models.TextField(max_length=500,blank=True, null=True, verbose_name=_("XPath tìm thông số kỹ thuật sản phẩm (1-n, xuống dòng)"))
    product_xpath_detail_description = models.TextField(max_length=500,blank=True, null=True, verbose_name=_("XPath tìm mô tả sản phẩm (1-n, xuống dòng)"))
    product_xpath_detail_image_link = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("XPath tìm URL ảnh sản phẩm (vd: img/@src)"))

    # selenium
    selenium_request = models.BooleanField(default=False)
    xpath_next_page = models.CharField(max_length=500, blank=True, null=True,
                                       )
    xpath_end_next_page = models.CharField(max_length=500, blank=True, null=True,
                                           )
    load_more_button = models.CharField(max_length=500, blank=True, null=True,
                                        )
    # end selenium

    is_deactive = models.BooleanField(blank=True, null=True, verbose_name=_("Spider không hoạt động"))
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True, verbose_name=_("Ngày tạo"))

    pid = models.CharField(max_length=100, blank=True, null=True, verbose_name=_("Process ID"))
    is_finished = models.BooleanField(default=False, verbose_name=_("Spider đã chạy xong"))
    status = models.TextField(blank=True, null=True, verbose_name=_("Trạng thái"))

    def __str__(self):
        if self.name is None:
            return ""
        else:
            return self.name
    class Meta:
        verbose_name = verbose_name_plural = _('Danh sách SPIDER lấy dữ liệu cho ai_training')
        ordering = ['name', 'id']


class EPS_SpiderField(models.Model):
    spider = models.ForeignKey('EPS_CrawlerSpider', on_delete=models.CASCADE, verbose_name=_("Spider"))
    name = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("Tên trường mô tả"))
    selector = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("Xpath hoặc css"))
    key_in_json = models.CharField(max_length=500, blank=True, null=True, verbose_name=_("Tên json"))
    is_inactive = models.BooleanField(default=False, verbose_name=_("Không hoạt động"))

    def __str__(self):
        if self.name is None:
            return ""
        else:
            return self.name
    class Meta:
        verbose_name = verbose_name_plural = _('Danh sách các trường cho Spider tương ứng')
        ordering = ['name', 'id']



class Product_Crawled(models.Model):
    link = models.CharField(max_length=2000, blank=True, null=True, verbose_name=_("Tên trường mô tả"))
    title = models.CharField(max_length=2000, blank=True, null=True, verbose_name=_("Tên trường mô tả"))
    price = models.CharField(max_length=2000, blank=True, null=True, verbose_name=_("Tên trường mô tả"))
    image_link = models.CharField(max_length=2000,blank=True, null=True, verbose_name=_("Tên trường mô tả"))
    description = models.TextField(blank=True, null=True, verbose_name=_("Tên trường mô tả"))
    specification = models.TextField(blank=True, null=True, verbose_name=_("Tên trường mô tả"))
    spider = models.ForeignKey('EPS_CrawlerSpider', on_delete=models.CASCADE, blank=True, null=True, verbose_name=_("Spider chạy"))
    process = models.ForeignKey('EPS_CrawlerProcess', on_delete=models.CASCADE, blank=True, null=True, verbose_name=_("Spider chạy"))
    category = models.ForeignKey('EPS_Category', default=1,on_delete=models.CASCADE, blank=True, null=True, verbose_name=_("danh muc"))
    khuyen_mai = models.CharField(max_length=2000, blank=True, null=True, verbose_name=_("Tên trường mô tả"))
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True, verbose_name=_("Ngày tạo"))
    is_approved = models.BooleanField(default=False, verbose_name=_("Đã phân loại"))
    fake_comparing = models.CharField(max_length=2000, blank=True, null=True, verbose_name=_("Fake so sanh "))

    def __str__(self):
        if self.link is None:
            return ""
        else:
            return self.link
    class Meta:
        verbose_name = verbose_name_plural = _('Danh sách Tivi')
        ordering = ['link', 'id']


