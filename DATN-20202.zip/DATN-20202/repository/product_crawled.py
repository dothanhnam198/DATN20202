from .models import *
from django.db.models import Q
def save_product_crawled(data):
    model = Product_Crawled.objects.update_or_create(
        title = data.get('title','null'),
        link = data.get('link','null'),
        price = data.get('price','null'),
        image_link = data.get('image_link','null'),
        description = data.get('description','null'),
        category = data.get('category','1'),
        defaults=data
    )
    return model

def get_noi_ban(title):
    list_noi_ban = Product_Crawled.objects.filter()