import django

django.setup()
from .models import *
from datetime import datetime


def insert(inser_data):
    new_spider = EPS_CrawlerSpider.objects.create()
    new_spider.name = inser_data['name']
    new_spider.domain = inser_data['domain']
    new_spider.domain_url = inser_data['domain_url']
    new_spider.home_url = inser_data['home_url']
    new_spider.category_xpath_list_link = inser_data['category_xpath_list_link']
    new_spider.product_url = inser_data['product_url']
    new_spider.product_url_post_data = inser_data['product_url_post_data']
    new_spider.product_url_category_id = inser_data['product_url_category_id']
    new_spider.product_xpath_list_link = inser_data['product_xpath_list_link']
    new_spider.product_xpath_detail_name = inser_data['product_xpath_detail_name']
    new_spider.product_xpath_detail_price = inser_data['product_xpath_detail_price']
    new_spider.product_xpath_detail_category = inser_data['product_xpath_detail_category']
    new_spider.product_xpath_detail_specification = inser_data['product_xpath_detail_specification']
    new_spider.product_xpath_detail_description = inser_data['product_xpath_detail_description']
    new_spider.product_xpath_detail_image_link = inser_data['product_xpath_detail_image_link']

    new_spider.save()
    return new_spider


def update(id, inser_data):
    spider = EPS_CrawlerSpider.objects.get(pk=id)
    spider.name = inser_data['name']
    spider.domain = inser_data['domain']
    spider.domain_url = inser_data['domain_url']
    spider.home_url = inser_data['home_url']
    spider.category_xpath_list_link = inser_data['category_xpath_list_link']
    spider.product_url = inser_data['product_url']
    spider.product_url_post_data = inser_data['product_url_post_data']
    spider.product_url_category_id = inser_data['product_url_category_id']
    spider.product_xpath_list_link = inser_data['product_xpath_list_link']
    spider.product_xpath_detail_name = inser_data['product_xpath_detail_name']
    spider.product_xpath_detail_price = inser_data['product_xpath_detail_price']
    spider.product_xpath_detail_category = inser_data['product_xpath_detail_category']
    spider.product_xpath_detail_specification = inser_data['product_xpath_detail_specification']
    spider.product_xpath_detail_description = inser_data['product_xpath_detail_description']
    spider.product_xpath_detail_image_link = inser_data['product_xpath_detail_image_link']
    spider.save()
    return spider


def get(id):
    return EPS_CrawlerSpider.objects.get(pk=id)


def get_with_xpath(id):
    spider = EPS_CrawlerSpider.objects.get(pk=id)
    xpath = EPS_CrawlerSpider.objects.filter(spider_id=id).first()
    if xpath:
        result = {
            "id": spider.id,
            "name": spider.name,
            "domain_url": spider.domain_url,
            "xpath": {
                "id": xpath.id,
                "product_xpath_list_link": xpath.product_xpath_list_link,
                "product_xpath_detail_name": xpath.product_xpath_detail_name,
                "product_xpath_detail_price": xpath.product_xpath_detail_price,
                "product_xpath_detail_category": xpath.product_xpath_detail_category,
                "product_xpath_detail_specification": xpath.product_xpath_detail_specification,
                "product_xpath_detail_description": xpath.product_xpath_detail_description,
                "product_xpath_detail_image_link": xpath.product_xpath_detail_image_link
            }
        }
    else:
        result = {
            "id": spider.id,
            "name": spider.name,
            "domain_url": spider.domain_url,
            "xpath": None
        }
    return result


