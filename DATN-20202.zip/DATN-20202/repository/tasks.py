from celery import shared_task
from multiprocessing import Process, Queue
import time
from django.conf import settings
from repository.models import EPS_CrawlerSpider
from spider_api.api import run_crawler
from repository import crawler_service

@shared_task(name='crawl_web')
def crawl(spider_id,spider_name):
    spider = EPS_CrawlerSpider.objects.get(id=spider_id)
    spider.status = ''
    spider.is_finished = False
    spider.save()
    timestamp = round(time.time())
    q = Queue()
    run_crawler(q,timestamp, spider, settings)

@shared_task
def add(x, y,*args):
    return x + y

@shared_task
def work():
    return print('work')


@shared_task
def mul(x, y):
    return x * y


@shared_task
def xsum(numbers):
    return sum(numbers)