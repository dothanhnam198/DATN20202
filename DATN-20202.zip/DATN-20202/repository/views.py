from django.shortcuts import render, redirect
from haystack import urls
# Create your views here.
from haystack.views import SearchView
#
#
# class MySearchView(SearchView):
#     """My custom search view."""
#
#     def get_queryset(self):
#         queryset = super(MySearchView, self).get_queryset()
#         # further filter queryset based on some set of criteria
#         return queryset.all()
#
#     def get_context_data(self, *args, **kwargs):
#         context = super(MySearchView, self).get_context_data(*args, **kwargs)
#         # do something
#         return context


