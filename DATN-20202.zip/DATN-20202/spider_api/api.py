from django.http import JsonResponse, HttpResponseForbidden
from twisted.internet import reactor
from scrapy.crawler import CrawlerRunner
from scrapy.settings import Settings
from multiprocessing import Process, Queue
import time
import os
import pyodbc
import signal
from repository import crawler_service, ai_service, dbapi_service
from repository.models import *
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated, AllowAny, IsAdminUser
from rest_framework.utils import json
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from repository.models import EPS_CrawlerSpider
from rest_framework.response import Response
from rest_framework import viewsets, status
from spider_api.serializers import *
from crawlers.crawlers.spiders.test import TestSpider
import requests
from lxml import etree
from django.conf import settings
from django.core import serializers
from common.excel_utils import handle_uploaded_file
import pyexcel
from common.db_utils import *

class CrawlerAPI(generics.RetrieveAPIView):
    #permission_classes = (IsAuthenticated,)
    # authentication_classes = [IsAuthenticated,]
    permission_classes = [AllowAny]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def get(self, request):
        # schedule()
        return JsonResponse({'done': 2, 'model': None})

    def post(self, request):
        cmd = request.query_params.get('cmd')
        print(cmd)

        if cmd == 'save_spider':
            id = request.query_params.get('id')
            spider_data = request.data
            insert_data = {
                'name': spider_data['name'],
                'domain': spider_data['domain'],
                'domain_url': spider_data['domain_url'],
                'home_url': spider_data['home_url'],
                'category_xpath_list_link': spider_data['category_xpath_list_link'],
                'product_url': spider_data['product_url'],
                'product_url_post_data': spider_data['product_url_post_data'],
                'product_url_category_id': spider_data['product_url_category_id'],
                'product_xpath_list_link': spider_data['product_xpath_list_link'],
                'product_xpath_detail_name': spider_data['product_xpath_detail_name'],
                'product_xpath_detail_price': spider_data['product_xpath_detail_price'],
                'product_xpath_detail_category': spider_data['product_xpath_detail_category'],
                'product_xpath_detail_specification': spider_data['product_xpath_detail_specification'],
                'product_xpath_detail_description': spider_data['product_xpath_detail_description'],
                'product_xpath_detail_image_link': spider_data['product_xpath_detail_image_link'],
                'interacting_page': spider_data['interacting_page'],
                'timeout_splash': spider_data['timeout_splash'],
                'splash_request': spider_data['splash_request'],
                'rendering_script': spider_data['rendering_script'],
                'day_of_week': spider_data['day_of_week'],
                'hour': spider_data['hour'],
                'minute': spider_data['minute'],
            }
            # name = spider_data['name']
            # domain = spider_data['domain']
            # domain_url = spider_data['domain_url']
            # home_url = spider_data['home_url']
            # category_xpath_list_link = spider_data['category_xpath_list_link']
            # product_url = spider_data['product_url']
            # product_url_post_data = spider_data['product_url_post_data']
            # product_url_category_id = spider_data['product_url_category_id']
            # product_xpath_list_link = spider_data['product_xpath_list_link']
            # product_xpath_detail_name = spider_data['product_xpath_detail_name']
            # product_xpath_detail_price = spider_data['product_xpath_detail_price']
            # product_xpath_detail_category = spider_data['product_xpath_detail_category']
            # product_xpath_detail_specification = spider_data['product_xpath_detail_specification']
            # product_xpath_detail_description = spider_data['product_xpath_detail_description']
            # product_xpath_detail_image_link = spider_data['product_xpath_detail_image_link']

            model = None
            if not id:
                model = crawler_service.insert_spider(insert_data)
            else:
                model = crawler_service.update_spider(id, insert_data)
            result = {
                "id": model.id,
                "name": model.name,
                "domain_url": model.domain_url
            }
            return JsonResponse({'done': 1, 'model': result})

        if cmd == 'get_spider':
            id = request.query_params.get('id')
            spider = crawler_service.get_spider(id)
            unique_fileds = crawler_service.get_unique_spiderfields(id)
            result = {
                "id": spider.id,
                "name": spider.name,
                "domain": spider.domain,
                "domain_url": spider.domain_url,
                "home_url": spider.home_url,
                "product_url": spider.product_url,
                "category_xpath_list_link": spider.category_xpath_list_link,
                "product_url_post_data": spider.product_url_post_data,
                "product_url_category_id": spider.product_url_category_id,
                "product_xpath_list_link": spider.product_xpath_list_link,
                "product_xpath_detail_name": spider.product_xpath_detail_name,
                "product_xpath_detail_price": spider.product_xpath_detail_price,
                "product_xpath_detail_category": spider.product_xpath_detail_category,
                "product_xpath_detail_specification": spider.product_xpath_detail_specification,
                "product_xpath_detail_description": spider.product_xpath_detail_description,
                "product_xpath_detail_image_link": spider.product_xpath_detail_image_link,
                "unique_fields": unique_fileds,
                "interacting_page":spider.interacting_page,
                'timeout_splash': spider.timeout_splash,
                'splash_request': spider.splash_request,
                'rendering_script': spider.rendering_script,
                'status': spider.status,
                'is_finished':spider.is_finished,
                'day_of_week': spider.day_of_week,
                'hour': spider.hour,
                'minute': spider.minute,

            }
            return JsonResponse({'done': 1, 'model': result})

        if cmd == 'get_all_spiders':
            total = EPS_CrawlerSpider.objects.all().order_by('created_at')
            count = total.count()

            # return JsonResponse({'models': total, fields=})
            return JsonResponse({'models': serializers.serialize('json',total),'totalCount':count})

        if cmd == 'get_all_product_crawled':
            records = Product_Crawled.objects.all()
            result=[]
            for item in records:
                data={}
                data['id'] = item.id
                data['title'] = item.title
                data['price'] = item.price
                data['khuyen_mai'] = item.khuyen_mai
                data['category'] = item.category.category_name
                data['created_at'] = item.created_at
                result.append(data)
            return JsonResponse({"data":result})

        if cmd == 'delete_spider':
            id = request.query_params.get('id')
            spider = EPS_CrawlerSpider.objects.get(id=id)
            if spider:
                spider.delete()
            return Response({'done': 1})

        if cmd == 'save_spider_field':
            id = request.query_params.get('id')
            spider_data = request.data
            insert_data = {
                'spider': spider_data['spider'],
                'name': spider_data['name'],
                'selector': spider_data['selector'],
                'key_in_json': spider_data['key_in_json'],
                'is_inactive': spider_data['is_inactive'],

            }
            model = None
            if not id:
                model = crawler_service.insert_spider_field(insert_data)
            else:
                model = crawler_service.update_spider_field(id, insert_data)
            result = {
                "name": model.name,
                "is_inactive": model.is_inactive,
                "spider": model.spider_id
            }
            return JsonResponse({'done': 1, 'model': result})

        if cmd == 'get_spider_field':
            id = request.query_params.get('id')
            spider_field = EPS_SpiderField.objects.get(id=id)
            result = {
                'spider': spider_field.spider_id,
                'name': spider_field.name,
                'selector': spider_field.selector,
                'key_in_json': spider_field.key_in_json,
                'is_inactive':spider_field.is_inactive

            }
            return Response({'done': 1, 'model': result})

        if cmd == 'delete_spider_field':
            id = request.query_params.get('id')
            spider = EPS_SpiderField.objects.get(id=id)
            if spider:
                spider.delete()
            return Response({'done': 1})


        if cmd == 'save_spider2':
            id = request.query_params.get('id')
            spider_data = request.data
            insert_data = {
                'name': spider_data['name'],
                'category_name': spider_data['category_name'],
                'category_id': spider_data['category_id'],
                'domain': spider_data['domain'],
                'domain_url': spider_data['domain_url'],
                'home_url': spider_data['home_url'],
                'category_xpath_list_link': spider_data['category_xpath_list_link'],
                'product_url': spider_data['product_url'],
                'product_url_post_data': spider_data['product_url_post_data'],
                'product_url_category_id': spider_data['product_url_category_id'],
                'product_xpath_list_link': spider_data['product_xpath_list_link'],
                'product_xpath_detail_name': spider_data['product_xpath_detail_name'],
                'product_xpath_detail_price': spider_data['product_xpath_detail_price'],
                'product_xpath_detail_category': spider_data['product_xpath_detail_category'],
                'product_xpath_detail_specification': spider_data['product_xpath_detail_specification'],
                'product_xpath_detail_description': spider_data['product_xpath_detail_description'],
                'product_xpath_detail_image_link': spider_data['product_xpath_detail_image_link']
            }
            # name = spider_data['name']
            # domain = spider_data['domain']
            # domain_url = spider_data['domain_url']
            # home_url = spider_data['home_url']
            # category_xpath_list_link = spider_data['category_xpath_list_link']
            # product_url = spider_data['product_url']
            # product_url_post_data = spider_data['product_url_post_data']
            # product_url_category_id = spider_data['product_url_category_id']
            # product_xpath_list_link = spider_data['product_xpath_list_link']
            # product_xpath_detail_name = spider_data['product_xpath_detail_name']
            # product_xpath_detail_price = spider_data['product_xpath_detail_price']
            # product_xpath_detail_category = spider_data['product_xpath_detail_category']
            # product_xpath_detail_specification = spider_data['product_xpath_detail_specification']
            # product_xpath_detail_description = spider_data['product_xpath_detail_description']
            # product_xpath_detail_image_link = spider_data['product_xpath_detail_image_link']

            model = None
            if not id:
                model = crawler_service.insert_spider2(insert_data)
            else:
                model = crawler_service.update_spider2(id, insert_data)
            result = {
                "id": model.id,
                "name": model.name,
                "domain_url": model.domain_url
            }
            return JsonResponse({'done': 1, 'model': result})

        if cmd == 'get_spider2':
            id = request.query_params.get('id')
            spider = crawler_service.get_spider2(id)
            result = {
                "id": spider.id,
                "name": spider.name,
                'category_name': spider.category_name,
                'category_id': spider.category_id,
                "domain": spider.domain,
                "domain_url": spider.domain_url,
                "home_url": spider.home_url,
                "product_url": spider.product_url,
                "category_xpath_list_link": spider.category_xpath_list_link,
                "product_url_post_data": spider.product_url_post_data,
                "product_url_category_id": spider.product_url_category_id,
                "product_xpath_list_link": spider.product_xpath_list_link,
                "product_xpath_detail_name": spider.product_xpath_detail_name,
                "product_xpath_detail_price": spider.product_xpath_detail_price,
                "product_xpath_detail_category": spider.product_xpath_detail_category,
                "product_xpath_detail_specification": spider.product_xpath_detail_specification,
                "product_xpath_detail_description": spider.product_xpath_detail_description,
                "product_xpath_detail_image_link": spider.product_xpath_detail_image_link,
            }
            return JsonResponse({'done': 1, 'model': result})

        if cmd == 'get_all_spiders2':
            total = EPS_CrawlerSpider2.objects.all().order_by('created_at')
            count = total.count()

            # return JsonResponse({'models': total, fields=})
            return JsonResponse({'models': serializers.serialize('json',total,fields=('name', 'domain', 'home_url', 'category_xpath_list_link', 'product_url', 'product_xpath_list_link', 'is_deactive', 'created_at', 'pid', 'is_finished', 'status')),'totalCount':count})

        if cmd == 'delete_spider2':
            id = request.query_params.get('id')
            spider = EPS_CrawlerSpider2.objects.get(id=id)
            if spider:
                spider.delete()
            return Response({'done': 1})


        if cmd == 'start_crawl2':
            spider_id = request.query_params.get('spider_id')
            spider = crawler_service.get_spider2(spider_id)

            spider.status = ''
            spider.is_finished = False
            spider.save()
            timestamp = round(time.time())
            q = Queue()
            p = Process(target=run_crawler2, args=(q, timestamp, spider))
            p.start()
            spider.pid = p.pid
            spider.save()
            crawler_service.insert2(timestamp, p.pid, spider)
            return JsonResponse({'done': '1', 'pid': p.pid, 'timestamp': timestamp})

        if cmd == 'stop_crawl2':
            pid = request.query_params.get('pid')
            spider = crawler_service.get_spider2(pid)
            spider.is_finished = True
            spider.save()
            pid = spider.pid
            timestamp = request.query_params.get('timestamp')
            try:
                os.kill(int(pid), signal.SIGTERM) # for linux
            except:
                pass
            try:
                os.system("c:\\windows\\system32\\taskkill  /F /pid " + pid) # for windows
            except:
                pass
            crawler_service.stop_process2(timestamp, spider)
            return JsonResponse({'done': '1', 'pid': pid, 'timestamp': timestamp})

        if cmd == 'get_crawler_config':
            config = EPS_CrawlerConfig.objects.filter(id=1).first()
            if config is not None:
                print(config)
                return JsonResponse({'done': 1, 'model': serializers.serialize('json', [config, ])})

        if cmd == 'save_crawler_config':
            id = request.query_params.get('id')
            request_data = request.data
            info = {
                'delay_time': request_data['delay_time'],
                'concurrent_request': request_data['concurrent_request'],
                'concurrent_request_per_domain': request_data['concurrent_request_per_domain'],
                'concurrent_request_per_ip': request_data['concurrent_request_per_ip'],
                'user_agent': request_data['user_agent'],
                'proxy_ip': request_data['proxy_ip'],
                'request_header': request_data['request_header'],
                'is_bypassAI': request_data['is_bypassAI'],
            }
            if id is not None:
                model = crawler_service.update_config(id, info)
                result = {
                    'delay_time': model.delay_time,
                    'concurrent_request': model.concurrent_request,
                    'concurrent_request_per_domain': model.concurrent_request_per_domain,
                    'concurrent_request_per_ip': model.concurrent_request_per_ip,
                    'is_bypassAI': model.is_bypassAI,
                }

                return JsonResponse({"done": 1, "result": result})

        if cmd == 'get_all_aimodel':
            all_aimodel = EPS_AIModel.objects.all()
            count = all_aimodel.count()
            return JsonResponse({"done": 2, "ai_model": serializers.serialize('json', all_aimodel,),"count": count})

        if cmd == 'get_ai_config':
            config = EPS_AIConfig.objects.get(id=1)
            print(config.modelAI.name)
            if config is not None:
                return Response({'done': config.modelAI.name, 'model': serializers.serialize('json', [config, ])})

        if cmd == 'save_ai_config':
            id = request.query_params.get('id')
            request_data = request.data
            info = {
                'modelAI_id': request_data['modelAI_id'],
                'stopwords': request_data['stopwords'],
                'specification_characters': request_data['specification_characters'],
                'dictination_json': request_data['dictination_json'],
            }
            if id is not None:
                model = ai_service.update_ai_config(id, info)
                result = {
                    'modelAI_id': request_data['modelAI_id'],
                    'stopwords': request_data['stopwords'],
                    'specification_characters': request_data['specification_characters'],
                    'dictination_json': request_data['dictination_json'],
                }

                return JsonResponse({"done": 1, "result": result})

        if cmd == 'get_all_ai_training':
            all_ai_train = EPS_AITrain.objects.all()
            ai_train_test = EPS_AITrain.objects.filter(is_trained=False).count()
            count = all_ai_train.count()
            return JsonResponse({"ai_model": serializers.serialize('json', all_ai_train,fields=('is_test_data','category_name','category_id','content_train','url','is_deactive','created_at')), "count": count,'test':ai_train_test})

        if cmd == 'get_all_ai_training':
            all_ai_train = EPS_AITrain.objects.all()
            ai_train_test = EPS_AITrain.objects.filter(is_trained=False).count()
            count = all_ai_train.count()
            return JsonResponse({"ai_model": serializers.serialize('json', all_ai_train,fields=('is_test_data','category_name','category_id','content_train','url','is_deactive','created_at')), "count": count,'test':ai_train_test})



        if cmd == 'get_dienthoai':
            dbapi_config = EPS_DBAPIConfig.objects.all().first()
            id = request.query_params.get('id')
            db = pyodbc.connect(
                'DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + dbapi_config.ip + ';DATABASE=' + dbapi_config.name_db + ';UID=' + dbapi_config.username_db + ';PWD=' + dbapi_config.password_db)
            cursor = db.cursor()
            cursor.execute("SELECT * FROM INTE_HANG_HOA_DICH_VU_AI WHERE ID = %s" % (int(id)))
            product_crawled = cursor.fetchall()
            result = {
                "title": product_crawled[0][1],
                "link": product_crawled[0][5],
                "specification": product_crawled[0][4],
                "price": product_crawled[0][2],
                "category_ai": product_crawled[0][3],
                "is_approved": product_crawled[0][6],
                "date": product_crawled[0][7],
                "domain": product_crawled[0][8],
                "date_crawl": product_crawled[0][9],
            }
            return JsonResponse({'done': 1, 'model': result})

        if cmd == 'save_dienthoai':
            id = request.query_params.get('id')
            request_data = request.data
            model = None
            dbapi_config = EPS_DBAPIConfig.objects.all().first()
            id = request.query_params.get('id')
            db = SQLServerUtils()
            db.open(dbapi_config.ip, dbapi_config.port, dbapi_config.name_db, dbapi_config.username_db,
                    dbapi_config.password_db)
            if not id:
                # insert_data = {
                #     "ten": request_data['ten'],
                #     "link": request_data['link'],
                #     "mo_ta": request_data['mo_ta'],
                #     "specification": request_data['specification'],
                #     "muc_gia": request_data['muc_gia'],
                #     "anh": request_data['anh'],
                #     "he_dieu_hanh": request_data['he_dieu_hanh'],
                #     "loai_man_hinh": request_data['loai_man_hinh'],
                #     "ram": request_data['ram'],
                #     "nhan_hieu": request_data['nhan_hieu'],
                #     "khuyen_mai": request_data['khuyen_mai'],
                #     "xuat_xu": request_data['xuat_xu'],
                #     "bao_hanh": request_data['bao_hanh'],
                #     "nam_san_xuat": request_data['nam_san_xuat'],
                #     "model": request_data['model'],
                # }
                db.execute(
                            "insert into INTE_HANG_HOA_DICH_VU_AI values ((SELECT MAX(ID)+1FROM INTE_HANG_HOA_DICH_VU_AI), N'%s',N'%s',N'%s',N'%s',N'%s',%s,getdate(),N'%s',N'%s')"
                            % (request_data['title'],
                               request_data['price'],
                               request_data['category_ai'],
                               request_data['specification'],
                               request_data['link'],
                               request_data['is_approved'],
                               request_data['link'].split('/')[2],
                               request_data['date_crawl']
                               ))
            else:
                # update_data = {
                #     "ten": request_data['ten'],
                #     "link": request_data['link'],
                #     "mo_ta": request_data['mo_ta'],
                #     "muc_gia": request_data['muc_gia'],
                #     "specification": request_data['specification'],
                #     "anh": request_data['anh'],
                #     "he_dieu_hanh": request_data['he_dieu_hanh'],
                #     "loai_man_hinh": request_data['loai_man_hinh'],
                #     "ram": request_data['ram'],
                #     "nhan_hieu": request_data['nhan_hieu'],
                #     "khuyen_mai": request_data['khuyen_mai'],
                #     "xuat_xu": request_data['xuat_xu'],
                #     "bao_hanh": request_data['bao_hanh'],
                #     "nam_san_xuat": request_data['nam_san_xuat'],
                #     "model": request_data['model'],
                # }
                if request_data['is_approved'] == False:
                    request_data['is_approved'] = 0
                else:
                    request_data['is_approved'] = 1
                db.execute(
                    "UPDATE INTE_HANG_HOA_DICH_VU_AI SET TEN = N'%s', DON_GIA=N'%s', PHAN_LOAI=N'%s',THONG_SO_KY_THUAT= N'%s', LINK_SAN_PHAM=N'%s',DA_DUYET=%s, NGAY_TAO=getdate(),NGUON_THONG_TIN=N'%s'  WHERE ID=%s"
                    % (request_data['title'],
                       request_data['price'],
                       request_data['category_ai'],
                       request_data['specification'],
                       request_data['link'],
                       request_data['is_approved'],
                       request_data['domain'],
                       int(id)))
            # result = {
            #         "ten": model.title,
            #         "link": model.link,
            #         "mo_ta": model.description,
            #         "muc_gia": model.price,
            #         "anh": model.image_link,
            #         "he_dieu_hanh": model.he_dieu_hanh,
            #         "loai_man_hinh": model.loai_man_hinh,
            #         "ram": model.ram,
            #         "nhan_hieu": model.category,
            #         "khuyen_mai": model.khuyen_mai,
            #         "xuat_xu": model.xuat_xu,
            #         "bao_hanh": model.bao_hanh,
            #         "nam_san_xuat": model.nam_san_xuat,
            #         "specification": model.specification,
            #         "model": model.model,
            # }
            return JsonResponse({'done': 2})

        if cmd == 'delete_dienthoai':
            id = request.query_params.get('id')
            dbapi_config = EPS_DBAPIConfig.objects.all().first()
            db = SQLServerUtils()
            db.open(dbapi_config.ip, dbapi_config.port, dbapi_config.name_db, dbapi_config.username_db,
                    dbapi_config.password_db)
            db.execute("DELETE FROM INTE_HANG_HOA_DICH_VU_AI WHERE ID = %s" %(int(id)))
            return Response({'done': 1})


        if cmd == 'save_ai_training':
            id = request.query_params.get('id')
            request_data = request.data
            model = None

            if not id:
                insert_data = {
                    'is_test_data': request_data['is_test_data'],
                    'category_name': request_data['category_name'],
                    'category_id': request_data['category_id'],
                    'content_train': request_data['content_train'],
                    'url': request_data['url'],
                    'is_trained': request_data['is_trained'],
                    'is_deactive': request_data['is_deactive'],
                    'created_at': request_data['created_at'],
                    'updated_at': request_data['updated_at'],
                }
                model = ai_service.insert_ai_train(insert_data)
            else:
                update_data = {
                    'is_test_data': request_data['is_test_data'],
                    'category_name': request_data['category_name'],
                    'category_id': request_data['category_id'],
                    'content_train': request_data['content_train'],
                    'url': request_data['url'],
                    'is_trained': request_data['is_trained'],
                    'is_deactive': request_data['is_deactive'],
                    'updated_at': request_data['updated_at'],
                }
                model = ai_service.update_ai_train(id, update_data)
            result = {
                'is_test_data': model.is_test_data,
                'category_name': model.category_name,
                'category_id': model.category_id,
                'content_train': model.content_train,
                'url': model.url,
                'is_trained': model.is_trained,
                'is_deactive': model.is_deactive,
                'created_at': model.created_at,
                'updated_at': model.updated_at,
            }
            return JsonResponse({'done': 2, 'model': result})

        if cmd == 'get_ai_training':
            id = request.query_params.get('id')
            pattern = ai_service.get_ai_train(id)
            result = {
                "is_test_data": pattern.is_test_data,
                "category_name": pattern.category_name,
                "category_id": pattern.category_id,
                "content_train": pattern.content_train,
                "url": pattern.url,
                "is_deactive": pattern.is_deactive,
                "is_trained": pattern.is_trained,
            }
            return JsonResponse({'done': 1, 'model': result})

        if cmd == 'delete_ai_training':
            id = request.query_params.get('id')
            ai_training = EPS_AITrain.objects.get(id=id)
            if ai_training:
                ai_training.delete()
            return Response({'done': 1})


        if cmd == 'get_spider_with_xpath':
            id = request.query_params.get('id')
            result = crawler_service.get_spider_with_xpath(id)
            return JsonResponse({'done': 1, 'model': result})

        if cmd == 'start_crawl':
            spider_id = request.query_params.get('spider_id')
            spider = crawler_service.get_spider(spider_id)

            spider.status = ''
            spider.is_finished = False
            spider.save()
            timestamp = round(time.time())
            if spider.selenium_request is True:
                driver = crawler_service.get_browser()
                driver.set_window_size(1804, 2896)
                driver.maximize_window()
                spider.status = '<u>Bắt đầu CRAWL lúc ' + datetime.datetime.now().strftime(
                    '%d/%m/%Y %H:%M:%S') + '</u>'
                spider.save()
                data_crawled = crawler_service.crawlPage_by_selenium(driver,spider)
                return JsonResponse({'data':data_crawled})
            else:
                q = Queue()
                p = Process(target=run_crawler, args=(q, timestamp, spider, settings))
                p.start()
                spider.pid = p.pid
                spider.save()
                crawler_service.insert(timestamp, p.pid, spider)
            return JsonResponse({'done': spider.is_finished, 'pid': p.pid, 'timestamp': timestamp})

        if cmd == 'stop_crawl':
            pid = request.query_params.get('pid')
            spider = crawler_service.get_spider(pid)
            spider.is_finished = True
            spider.save()
            pid = spider.pid
            timestamp = request.query_params.get('timestamp')
            try:
                os.kill(int(pid), signal.SIGTERM) # for linux
            except:
                pass
            try:
                os.system("c:\\windows\\system32\\taskkill  /F /pid " + pid) # for windows
            except:
                pass
            crawler_service.stop_process(timestamp, spider)
            return JsonResponse({'done': '1', 'pid': pid, 'timestamp': timestamp})

        if cmd == 'training_ai_model':
            request_data = request.data
            product_train = request_data['product_train']
            id = request_data['ai_model']
            data_train = []
            for spider in product_train:
                obj = EPS_AITrain.objects.get(pk=spider['pk'])
                obj.is_trained = True
                obj.save()
                data_train.append({
                    "category_name": spider['fields']['category_name'],
                    "content_train": spider['fields']['content_train']
                })
            start_training = ai_service.train_ai_classifier_product(data_train, id)
            return JsonResponse({'done': 1})

        if cmd == 'training_all':
            request_data = request.data
            product_train = request_data['product_train']
            data_train = []
            for spider in product_train:
                obj = EPS_AITrain.objects.get(pk=spider['pk'])
                obj.is_trained = True
                obj.save()
                data_train.append({
                    "category_name": spider['fields']['category_name'],
                    "content_train": spider['fields']['content_train']
                })
            start_training = ai_service.training_all(data_train)
            return JsonResponse({'done': 1})

        if cmd == 'import_file':
            file = request.FILES['file']
            handle_uploaded_file(file)
            upload_file = 'uploads/' + str(file.name)
            file_transcoding = str(file.name).split('.')[0]
            file_transcoding = 'uploads/' + str(file_transcoding) + '.xls'
            pyexcel.save_as(file_name=upload_file,dest_file_name=file_transcoding)
            records = pyexcel.get_records(file_name=file_transcoding)
            for record in records:
                ai_train = EPS_AITrain()
                ai_train.is_test_data = False
                ai_train.category_name = record['Tên danh mục']
                ai_train.category_id = record['Id danh mục']
                ai_train.content_train = record['Nội dung sản phẩm']
                ai_train.url = record['Địa chỉ gốc']
                ai_train.is_trained = False
                ai_train.is_deactive = False
                ai_train.save()

            return JsonResponse({'done':1})


class CrawlerUnauthorizedAPI(generics.RetrieveAPIView):
    def get(self, request):
        return HttpResponseForbidden()


def run_crawler(q,timestamp, spider, gia2_settings):
    print('run_crawler')
    bypassAI = False

    try:
        settings = Settings(values={
            'TELNETCONSOLE_ENABLED': False,
            'ITEM_PIPELINES': {
                'crawlers.crawlers.pipelines.CrawlersPipeline': 300,
            },
            'DOWNLOAD_DELAY': 0.25,
            'RANDOMIZE_DOWNLOAD_DELAY': True,
            'USER_AGENT': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)',
            # 'LOG_ENABLED': False,
            'SPLASH_URL': gia2_settings.SPLASH_URL,
            'DUPEFILTER_CLASS': gia2_settings.DUPEFILTER_CLASS,
            'HTTPCACHE_STORAGE': gia2_settings.HTTPCACHE_STORAGE,
            'COOKIES_ENABLED': gia2_settings.COOKIES_ENABLED,
            'SPLASH_COOKIES_DEBUG': gia2_settings.SPLASH_COOKIES_DEBUG,
            'SPIDER_MIDDLEWARES': gia2_settings.SPIDER_MIDDLEWARES,
            'DOWNLOADER_MIDDLEWARES': gia2_settings.DOWNLOADER_MIDDLEWARES,
        })

        crawlerConfig = EPS_CrawlerConfig.objects.all().first()
        if crawlerConfig is not None:
            settings['DOWNLOAD_DELAY'] = crawlerConfig.delay_time
            settings['CONCURRENT_REQUEST'] = crawlerConfig.concurrent_request
            settings['CONCURRENT_REQUESTS_PER_DOMAIN'] = crawlerConfig.concurrent_request_per_domain
            settings['CONCURRENT_REQUESTS_PER_IP'] = crawlerConfig.concurrent_request_per_ip
            if crawlerConfig.user_agent and str(crawlerConfig.user_agent) != '':
                import random
                settings['USER_AGENT'] = random.choice(crawlerConfig.user_agent.split('\r\n'))
                pass
            if crawlerConfig.proxy_ip:
                pass
            if crawlerConfig.request_header: #cookies={}, headers=
                pass
            if crawlerConfig.is_bypassAI:
                bypassAI = crawlerConfig.is_bypassAI

            BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            uploadFolder = os.path.join(BASE_DIR, 'uploads')
            file_json = os.path.join(uploadFolder, str(spider.id) + '.' + spider.domain + '.json')
            crawler = CrawlerRunner(settings)
            d = crawler.crawl(TestSpider, key=timestamp, spider_info=spider, file_json=file_json)
            d.addBoth(lambda _: stop_crawler(timestamp, spider, bypassAI, file_json))
            reactor.run()
    except Exception as e:
        import traceback
        print('traceback.format_exc()')
        print(traceback.format_exc())
        return None
    return crawler


def stop_crawler(timestamp, spider, bypassAI, file_json):
    # when finish crawling, this function is invoked
    try:
        print('reactor.stop luon la loi spider hoac pipeline, bat debug crawler ')
        crawler_service.stop_process(timestamp, spider)
        # start AI with file json
        print(bypassAI)
        # ai_service.train_ai_classifier_product(None, None)
        with open(file_json, 'r', encoding='utf8') as f:
            products = json.loads(f.read())
            print(len(products))
            if bypassAI != True:
                ai_service.update_product(products, spider)
                pass
            # dbapi_service.update_product(products, spider)

    except Exception as e:
        import traceback
        print('stop_crawler')
        print(traceback.format_exc())

    reactor.stop()

def run_crawler2(q, timestamp, spider):
    print('run_crawler')
    bypassAI = False
    settings = Settings(values={
        'TELNETCONSOLE_ENABLED': False,
        'ITEM_PIPELINES': {
            'crawlers.crawlers.pipelines.CrawlersPipeline': 300,
        },
        'DOWNLOAD_DELAY': 0.25,
        'RANDOMIZE_DOWNLOAD_DELAY': True,
        'USER_AGENT': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)',
        #'LOG_ENABLED': False,
    })
    #settings['ITEM_PIPELINES'] = {'__main__.MyPipeline': 1}
    try:
        crawlerConfig = EPS_CrawlerConfig.objects.all().first()
        if crawlerConfig is not None:
            settings['DOWNLOAD_DELAY'] = crawlerConfig.delay_time
            settings['CONCURRENT_REQUEST'] = crawlerConfig.concurrent_request
            settings['CONCURRENT_REQUESTS_PER_DOMAIN'] = crawlerConfig.concurrent_request_per_domain
            settings['CONCURRENT_REQUESTS_PER_IP'] = crawlerConfig.concurrent_request_per_ip
            if crawlerConfig.user_agent and str(crawlerConfig.user_agent) != '':
                import random
                settings['USER_AGENT'] = random.choice(crawlerConfig.user_agent.split('\r\n'))
                pass
            if crawlerConfig.proxy_ip:
                pass
            if crawlerConfig.request_header: #cookies={}, headers=
                pass
            if crawlerConfig.is_bypassAI:
                bypassAI = crawlerConfig.is_bypassAI

            BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            uploadFolder = os.path.join(BASE_DIR, 'uploads')
            file_json = os.path.join(uploadFolder, str(spider.id) + '.' + spider.domain + '.json')
            crawler = CrawlerRunner(settings)
            d = crawler.crawl(TestSpider, key=timestamp, spider_info=spider, file_json=file_json)
            d.addBoth(lambda _: stop_crawler2(timestamp, spider, bypassAI, file_json))
            reactor.run()
    except Exception as e:
        import traceback
        print('traceback.format_exc()')
        print(traceback.format_exc())
        return None
    return crawler


def stop_crawler2(timestamp, spider, bypassAI, file_json):
    # when finish crawling, this function is invoked
    try:
        print('reactor.stop luon la loi spider hoac pipeline, bat debug crawler ')
        crawler_service.stop_process2(timestamp, spider)
        # start AI with file json
        print(bypassAI)
        # ai_service.train_ai_classifier_product(None, None)
        with open(file_json, 'r', encoding='utf8') as f:
            products = json.loads(f.read())
            print(len(products))
            if type(spider) == EPS_CrawlerSpider2:
                pass
            else:
                if bypassAI != True:
                    ai_service.update_product(products, spider)
                    pass
                    dbapi_service.update_product(products, spider)

    except Exception as e:
        import traceback
        print('stop_crawler')
        print(traceback.format_exc())

    reactor.stop()

class SpiderViewSet(viewsets.ModelViewSet):
    queryset = EPS_CrawlerSpider.objects.all()
    serializer_class = SpiderSerializer

    def list(self, request, **kwargs):
        try:
            spider = EPS_CrawlerSpider.objects.all()
            serializer = SpiderSerializer(spider, many=True)
            result = {}
            result['data'] = serializer.data

            return Response(result, status=status.HTTP_200_OK, template_name=None, content_type=None)

        except Exception as e:
            return Response(e.message, status=status.HTTP_404_NOT_FOUND, template_name=None, content_type=None)

class SpiderViewSet2(viewsets.ModelViewSet):
    queryset = EPS_CrawlerSpider2.objects.all()
    serializer_class = SpiderSerializer2

    def list(self, request, **kwargs):
        try:
            spider = EPS_CrawlerSpider2.objects.all()
            serializer = SpiderSerializer2(spider, many=True)
            result = {}
            result['data'] = serializer.data

            return Response(result, status=status.HTTP_200_OK, template_name=None, content_type=None)

        except Exception as e:
            return Response(e.message, status=status.HTTP_404_NOT_FOUND, template_name=None, content_type=None)


class AITrainingViewSet(viewsets.ModelViewSet):
    queryset = EPS_AITrain.objects.all()
    serializer_class = AITrainingSerializer

    def list(self, request, **kwargs):
        try:
            ai_training = EPS_AITrain.objects.all().order_by('created_at')
            serializer = AITrainingSerializer(ai_training, many=True)
            result = {}
            result['data'] = serializer.data

            return Response(serializer.data, status=status.HTTP_200_OK, template_name=None, content_type=None)

        except Exception as e:
            return Response(e.message, status=status.HTTP_404_NOT_FOUND, template_name=None, content_type=None)


class CrawlerProcessViewSet(viewsets.ModelViewSet):
    queryset = EPS_CrawlerProcess.objects.all()
    serializer_class = EPS_CrawlerProcessSerializer

    def list(self, request, **kwargs):
        try:
            ai_training = EPS_CrawlerProcess.objects.all()
            serializer = EPS_CrawlerProcessSerializer(ai_training, many=True)
            result = serializer.data

            return Response(result, status=status.HTTP_200_OK, template_name=None, content_type=None)

        except Exception as e:
            return Response(e.message, status=status.HTTP_404_NOT_FOUND, template_name=None, content_type=None)


class SpiderFieldsViewSet(viewsets.ModelViewSet):
    queryset = EPS_SpiderField.objects.all()
    serializer_class = EPS_SpiderFieldsSerializer

    def list(self, request, **kwargs):
        try:
            fields = EPS_SpiderField.objects.all()
            serializer = EPS_SpiderFieldsSerializer(fields, many=True)
            result = serializer.data

            return Response(result, status=status.HTTP_200_OK, template_name=None, content_type=None)

        except Exception as e:
            return Response(e.message, status=status.HTTP_404_NOT_FOUND, template_name=None, content_type=None)
