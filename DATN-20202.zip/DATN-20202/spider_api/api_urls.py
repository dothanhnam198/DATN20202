from django.urls import path, include
from .api import *
from django.views.decorators.csrf import csrf_exempt

urlpatterns = [
    path('', csrf_exempt(CrawlerAPI.as_view())),
    #path('unauthorized', CrawlerUnauthorizedAPI.as_view()),
]