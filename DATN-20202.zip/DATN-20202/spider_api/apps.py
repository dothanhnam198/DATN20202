from django.apps import AppConfig

class SpiderAPIConfig(AppConfig):
    name = 'spider_api'
