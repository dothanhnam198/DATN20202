from django.shortcuts import redirect
from django.conf import settings


class SpiderAuthMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        # One-time configuration and initialization.

    def __call__(self, request):
        # Code to be executed for each request before
        # the view (and later middleware) are called.

        response = self.get_response(request)
        if request.path.startswith('/api/spider') and not request.path.startswith('/api/spider/unauthorized'):
            if "HTTP_AUTHORIZATION" not in request.META:
                return redirect('/api/spider/unauthorized')
            token = request.META['HTTP_AUTHORIZATION']
            if token:
                return response
            return redirect('/api/spider/unauthorized')
        # Code to be executed for each request/response after
        # the view is called.

        return response