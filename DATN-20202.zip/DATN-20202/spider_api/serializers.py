from django.conf import settings
from rest_framework import serializers

from repository.models import *


class SpiderSerializer(serializers.ModelSerializer):

    class Meta:
        model = EPS_CrawlerSpider
        fields = ('id', 'name', 'domain', 'home_url', 'category_xpath_list_link', 'product_url', 'product_xpath_list_link', 'is_deactive', 'created_at', 'pid', 'is_finished', 'status')

class SpiderSerializer2(serializers.ModelSerializer):

    class Meta:
        model = EPS_CrawlerSpider2
        fields = ('id', 'name', 'category_name', 'category_id', 'domain', 'home_url', 'category_xpath_list_link', 'product_url', 'product_xpath_list_link', 'is_deactive', 'created_at', 'pid', 'is_finished', 'status')

class AITrainingSerializer(serializers.ModelSerializer):

    class Meta:
        model = EPS_AITrain
        fields = ('id', 'is_test_data', 'category_name', 'category_id', 'content_train', 'url', 'is_trained', 'is_deactive', 'created_at', 'updated_at')


class EPS_CrawlerProcessSerializer(serializers.ModelSerializer):

    class Meta:
        model = EPS_CrawlerProcess
        fields = ('timestamp', 'created_at', 'finished_at', 'total_runtime', 'pid', 'is_running', 'status', 'spider')


class EPS_SpiderFieldsSerializer(serializers.ModelSerializer):

    class Meta:
        model = EPS_SpiderField
        fields = ('id', 'spider_id', 'name', 'selector','key_in_json','is_inactive')

