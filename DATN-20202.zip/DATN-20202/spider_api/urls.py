from django.urls import path, include

from spider_api.api import CrawlerAPI
from spider_api.views import create_spider_view, SpiderEditView, SpiderListView, save_spider_xpath_view
urlpatterns = [
    path('create', create_spider_view),
    path('', SpiderListView.as_view()),
    # path('save_xpath', create_spider_xpath_view),
    path('save_xpath/<int:pk>', save_spider_xpath_view),

]


