var ocrService = function () {
    var api_url = '/api/config/';
    return {
        createConfig: function (config) {
            debugger
            return request('POST', api_url + '?cmd=insert_config', config);
        },
        getConfig: function () {
            debugger
            return request('POST', api_url + '?cmd=get_dpapi_config');
        },
    }
}
