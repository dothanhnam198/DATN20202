var spiderService = function () {
    var api_url = '/api/spider/';
    return {
        saveSpider: function (config) {
            debugger
            return request('POST', api_url + '?cmd=save_spider' , config);
        },
        editSpider: function (id, config) {
            debugger
            return request('POST', api_url + '?cmd=save_spider&id=' + id , config);
        },
        getSpidernoicon: function (id) {
            debugger
            return noIconRequest('POST', api_url + '?cmd=get_spider&id=' + id );
        },
        getSpider: function (id) {
            return request('POST', api_url + '?cmd=get_spider&id=' + id );
        },
        deleteSpider: function (id) {
            debugger
            return request('POST', api_url + '?cmd=delete_spider&id=' + id);
        },
         getAllSpiders: function () {
            return request('POST', api_url + '?cmd=get_all_spiders');
        },
        saveSpiderField: function (config) {
            debugger
            return request('POST', api_url + '?cmd=save_spider_field' , config);
        },
        editSpiderField: function (id, config) {
            debugger
            return request('POST', api_url + '?cmd=save_spider_field&id=' + id , config);
        },
        getSpiderField: function (id) {
            debugger
            return request('POST', api_url + '?cmd=get_spider_field&id=' + id );
        },
        deleteSpiderField: function (id) {
            debugger
            return request('POST', api_url + '?cmd=delete_spider_field&id=' + id);
        },
        saveSpider2: function (config) {
            debugger
            return request('POST', api_url + '?cmd=save_spider2' , config);
        },
        editSpider2: function (id, config) {
            debugger
            return request('POST', api_url + '?cmd=save_spider2&id=' + id , config);
        },
        getSpider2: function (id) {
            debugger
            return request('POST', api_url + '?cmd=get_spider2&id=' + id );
        },
        deleteSpider2: function (id) {
            debugger
            return request('POST', api_url + '?cmd=delete_spider2&id=' + id);
        },
         getAllSpiders2: function () {
            return request('POST', api_url + '?cmd=get_all_spiders2');
        },
        startCrawl2: function (id, config) {
            debugger
            return request('POST', api_url + '?cmd=start_crawl2&spider_id=' + id , config);
        },
        stopCrawl2: function (pid, timestamp) {
            debugger
            return request('POST', api_url + '?cmd=stop_crawl2&pid=' + pid + '&timestamp=' + timestamp);
        },
        createXpath: function (config) {
            debugger
            return request('POST', api_url + '?cmd=save_spider_xpath&id=' , config);
        },
        saveXpath: function (spider_id, config) {
            debugger
            return request('POST', api_url + '?cmd=save_spider_xpath&id=' + spider_id , config);
        },
        startCrawl: function (id, config) {
            debugger
            return request('POST', api_url + '?cmd=start_crawl&spider_id=' + id , config);
        },
        stopCrawl: function (pid, timestamp) {
            debugger
            return request('POST', api_url + '?cmd=stop_crawl&pid=' + pid + '&timestamp=' + timestamp);
        },
        getCrawlerConfig: function () {
            return request('POST', api_url + '?cmd=get_crawler_config');
        },
        saveCrawlerConfig: function (id, config) {
            return request('POST', api_url + '?cmd=save_crawler_config&id='+ id , config);
        },
        getAIConfig: function () {
            return request('POST', api_url + '?cmd=get_ai_config');
        },
        saveAIConfig: function (id, config) {
            return request('POST', api_url + '?cmd=save_ai_config&id='+ id , config);
        },
        getAllaimodel: function () {

            return request('POST', api_url + '?cmd=get_all_aimodel');
        },
	    createAITraining: function ( config) {
            return request('POST', api_url + '?cmd=save_ai_training' , config);
        },
        saveAITraining: function (id, config) {
            return request('POST', api_url + '?cmd=save_ai_training&id='+ id , config);
        },
        getAllDienThoai: function () {
            return request('POST', api_url + '?cmd=get_all_dien_thoai');
        },
        getAllDauThau: function () {
            return request('POST', api_url + '?cmd=get_all_dauthau');
        },
        getDienThoai: function (id) {
            return request('POST', api_url + '?cmd=get_dienthoai&id='+ id );
        },
        saveDienThoai: function (id, config) {
            return request('POST', api_url + '?cmd=save_dienthoai&id='+ id , config);
        },
        deleteDienThoai: function (id) {
            debugger
            return request('POST', api_url + '?cmd=delete_dienthoai&id=' + id);
        },
        getTivi: function (id) {
            return request('POST', api_url + '?cmd=get_tivi&id='+ id );
        },
        saveTivi: function (id, config) {
            return request('POST', api_url + '?cmd=save_tivi&id='+ id , config);
        },
        deleteTivi: function (id) {
            debugger
            return request('POST', api_url + '?cmd=delete_tivi&id=' + id);
        },
        getTuLanh: function (id) {
            return request('POST', api_url + '?cmd=get_tulanh&id='+ id );
        },
        saveTuLanh: function (id, config) {
            return request('POST', api_url + '?cmd=save_tulanh&id='+ id , config);
        },
        deleteTuLanh: function (id) {
            debugger
            return request('POST', api_url + '?cmd=delete_tulanh&id=' + id);
        },
        getNhaRieng: function (id) {
            return request('POST', api_url + '?cmd=get_nharieng&id='+ id );
        },
        saveNhaRieng: function (id, config) {
            return request('POST', api_url + '?cmd=save_nharieng&id='+ id , config);
        },
        deleteNhaRieng: function (id) {
            debugger
            return request('POST', api_url + '?cmd=delete_nharieng&id=' + id);
        },
        getChungCu: function (id) {
            return request('POST', api_url + '?cmd=get_chungcu&id='+ id );
        },
        saveChungCu: function (id, config) {
            return request('POST', api_url + '?cmd=save_chungcu&id='+ id , config);
        },
        deleteChungCu: function (id) {
            debugger
            return request('POST', api_url + '?cmd=delete_chungcu&id=' + id);
        },
        getAITraining: function (id) {
            return request('POST', api_url + '?cmd=get_ai_training&id='+ id );
        },
        getAllAiTraining: function () {

            return request('POST', api_url + '?cmd=get_all_ai_training');
        },
        deleteAITraining: function (id) {
            debugger
            return request('POST', api_url + '?cmd=delete_ai_training&id=' + id);
        },
        startTraining: function (config) {
            debugger
            return request('POST', api_url + '?cmd=training_ai_model', config);
        },
        TrainingAll: function (config) {
            debugger
            return request('POST', api_url + '?cmd=training_all', config);
        },
        ImportFile: function (file) {
            debugger
            var data = new FormData();
            data.append('file', file);
            $.post({
                url: api_url + "?cmd=import_file",
                data: data,
                cache: false,
                contentType: false,
                processData: false
            }).done(function (data) {
                console.log(data)
            }).fail(function (jqXHR) {
                console.log(jqXHR);
                alert('Loi')
            });
        },

    }
}
